﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue.FormClasses.Dgv
{
    public class DgvColumn
    {
        private string header;
        private bool visible;
        private bool readOnly;
        private double widthPerc;
        private Type dataType;
        private string numFormat;
        private DataGridViewContentAlignment alignment;
        private Color backColor;
        private Color foreColor;
        private bool allowSort;

        public DgvColumn(string header, bool visible, bool readOnly, double widthPerc, Type dataType, string numFormat, bool allowSort,
            DataGridViewContentAlignment alignment, Color backColor, Color foreColor)
        {
            this.header = header;
            this.visible = visible;
            this.readOnly = readOnly;
            this.widthPerc = widthPerc;
            this.dataType = dataType;
            this.numFormat = numFormat;
            this.allowSort = allowSort;
            this.alignment = alignment;
            this.backColor = backColor;
            this.foreColor = foreColor;
        }

        public void initializeFormat(DataGridViewColumn col, int headerVerticalPadding)
        {
            col.ReadOnly = readOnly;
            col.DefaultCellStyle.BackColor = backColor;
            col.DefaultCellStyle.ForeColor = foreColor;
            col.DefaultCellStyle.Alignment = alignment;
            col.HeaderCell.Style.Alignment = alignment;
            if (alignment == DataGridViewContentAlignment.MiddleLeft)
            {
                col.DefaultCellStyle.Padding = new Padding(5, 1, 1, 1);
                col.HeaderCell.Style.Padding = new Padding(0, headerVerticalPadding, 0, headerVerticalPadding);
            }
            else if (alignment == DataGridViewContentAlignment.MiddleRight)
            {
                col.DefaultCellStyle.Padding = new Padding(1, 1, 5, 1);
                col.HeaderCell.Style.Padding = new Padding(0, headerVerticalPadding, 0, headerVerticalPadding);
            }
            if (numFormat != String.Empty)
            {
                col.DefaultCellStyle.Format = numFormat;
            }
            if (allowSort) { col.SortMode = DataGridViewColumnSortMode.Automatic; }
            else { col.SortMode = DataGridViewColumnSortMode.NotSortable; }
        }

        // SETTERS
        // GETTERS
        public bool getVisible() { return this.visible; }
        public double getWidthPerc() { return this.widthPerc; }
        public string getHeader() { return this.header; }
        public Type getDataType() { return this.dataType; }

    }

}
