﻿using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue
{
    static class Program
    {
        public static SueForm sueForm;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args == null) { sueForm = new SueForm(); }
            else if (args.Length == 0) { sueForm = new SueForm(); }
            else { sueForm = new SueForm(args[0]); }
            Application.Run(sueForm);
            //Application.Run(new SeSue.Forms.Visualization.Visualization());
        }
    }
}
