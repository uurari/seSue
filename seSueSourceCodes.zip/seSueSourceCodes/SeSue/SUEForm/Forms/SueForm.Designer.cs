﻿namespace SeSue.Forms
{
    partial class SueForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSave = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graphStatisticsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nodesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.linkCostsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkSUEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.oDPairsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pathsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mSASolutionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pathGenerationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yensKShortestPathAlgorithmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dialsAlgorithmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkPenaltyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkEliminationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkPenaltyLinkEliminationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkEliminationLinkPenaltyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.choiceModelWizardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.weibitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mDMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mDMWithNormalMDsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.networkVisualizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sensitivityAnalysisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perturbODDemandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabGraph = new System.Windows.Forms.TabPage();
            this.splitGraph1 = new System.Windows.Forms.SplitContainer();
            this.tabNodes = new System.Windows.Forms.TabPage();
            this.tabLinks = new System.Windows.Forms.TabPage();
            this.tab2 = new System.Windows.Forms.TabControl();
            this.tabLinkCost = new System.Windows.Forms.TabPage();
            this.tabLinkSue = new System.Windows.Forms.TabPage();
            this.tabOd = new System.Windows.Forms.TabPage();
            this.tabPaths = new System.Windows.Forms.TabPage();
            this.splitPaths = new System.Windows.Forms.SplitContainer();
            this.splitPaths2 = new System.Windows.Forms.SplitContainer();
            this.splitPaths2a = new System.Windows.Forms.SplitContainer();
            this.splitPaths2a1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.cbPaths_OdPairs = new System.Windows.Forms.ComboBox();
            this.splitPaths2a2 = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.tbPaths_Nodes = new System.Windows.Forms.TextBox();
            this.splitPaths2b = new System.Windows.Forms.SplitContainer();
            this.splitPaths2b1 = new System.Windows.Forms.SplitContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPaths_Links = new System.Windows.Forms.TextBox();
            this.splitPaths2b2 = new System.Windows.Forms.SplitContainer();
            this.btnPathsFilter = new System.Windows.Forms.Button();
            this.tabMsa = new System.Windows.Forms.TabPage();
            this.splitMsa = new System.Windows.Forms.SplitContainer();
            this.splitMsaButtons = new System.Windows.Forms.SplitContainer();
            this.btnMsaProps = new System.Windows.Forms.Button();
            this.btnMsaRun = new System.Windows.Forms.Button();
            this.bgwRead = new System.ComponentModel.BackgroundWorker();
            this.bgwMsa = new System.ComponentModel.BackgroundWorker();
            this.bgwSave = new System.ComponentModel.BackgroundWorker();
            this.bgwExport = new System.ComponentModel.BackgroundWorker();
            this.bgwExportPath = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabGraph.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitGraph1)).BeginInit();
            this.splitGraph1.SuspendLayout();
            this.tabLinks.SuspendLayout();
            this.tab2.SuspendLayout();
            this.tabPaths.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths)).BeginInit();
            this.splitPaths.Panel1.SuspendLayout();
            this.splitPaths.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2)).BeginInit();
            this.splitPaths2.Panel1.SuspendLayout();
            this.splitPaths2.Panel2.SuspendLayout();
            this.splitPaths2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a)).BeginInit();
            this.splitPaths2a.Panel1.SuspendLayout();
            this.splitPaths2a.Panel2.SuspendLayout();
            this.splitPaths2a.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a1)).BeginInit();
            this.splitPaths2a1.Panel1.SuspendLayout();
            this.splitPaths2a1.Panel2.SuspendLayout();
            this.splitPaths2a1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a2)).BeginInit();
            this.splitPaths2a2.Panel1.SuspendLayout();
            this.splitPaths2a2.Panel2.SuspendLayout();
            this.splitPaths2a2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b)).BeginInit();
            this.splitPaths2b.Panel1.SuspendLayout();
            this.splitPaths2b.Panel2.SuspendLayout();
            this.splitPaths2b.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b1)).BeginInit();
            this.splitPaths2b1.Panel1.SuspendLayout();
            this.splitPaths2b1.Panel2.SuspendLayout();
            this.splitPaths2b1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b2)).BeginInit();
            this.splitPaths2b2.Panel2.SuspendLayout();
            this.splitPaths2b2.SuspendLayout();
            this.tabMsa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMsa)).BeginInit();
            this.splitMsa.Panel1.SuspendLayout();
            this.splitMsa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMsaButtons)).BeginInit();
            this.splitMsaButtons.Panel1.SuspendLayout();
            this.splitMsaButtons.Panel2.SuspendLayout();
            this.splitMsaButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Symbol", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.dataToolStripMenuItem,
            this.pathGenerationToolStripMenuItem,
            this.choiceModelWizardToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.sensitivityAnalysisToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(9, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(0, 8, 0, 16);
            this.menuStrip1.Size = new System.Drawing.Size(1038, 43);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuOpen,
            this.menuSave,
            this.menuSaveAs});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 19);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // menuOpen
            // 
            this.menuOpen.Image = global::SeSue.Properties.Resources.cmn_open;
            this.menuOpen.Name = "menuOpen";
            this.menuOpen.ShortcutKeyDisplayString = "Ctrl + O";
            this.menuOpen.Size = new System.Drawing.Size(177, 22);
            this.menuOpen.Text = "Open";
            this.menuOpen.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.menuOpen.Click += new System.EventHandler(this.menuOpen_Click);
            // 
            // menuSave
            // 
            this.menuSave.Image = global::SeSue.Properties.Resources.cmn_save11;
            this.menuSave.Name = "menuSave";
            this.menuSave.ShortcutKeyDisplayString = "Ctrl + S";
            this.menuSave.Size = new System.Drawing.Size(177, 22);
            this.menuSave.Text = "Save";
            this.menuSave.Click += new System.EventHandler(this.menuSave_Click);
            // 
            // menuSaveAs
            // 
            this.menuSaveAs.Image = global::SeSue.Properties.Resources.cmn_saveas11;
            this.menuSaveAs.Name = "menuSaveAs";
            this.menuSaveAs.ShortcutKeyDisplayString = "Ctrl+Alt+S";
            this.menuSaveAs.Size = new System.Drawing.Size(177, 22);
            this.menuSaveAs.Text = "Save As";
            this.menuSaveAs.Click += new System.EventHandler(this.menuSaveAs_Click);
            // 
            // dataToolStripMenuItem
            // 
            this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.graphStatisticsToolStripMenuItem1,
            this.nodesToolStripMenuItem1,
            this.linkCostsToolStripMenuItem,
            this.linkSUEToolStripMenuItem1,
            this.oDPairsToolStripMenuItem1,
            this.pathsToolStripMenuItem1,
            this.mSASolutionToolStripMenuItem});
            this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
            this.dataToolStripMenuItem.Size = new System.Drawing.Size(52, 19);
            this.dataToolStripMenuItem.Text = "&Export";
            // 
            // graphStatisticsToolStripMenuItem1
            // 
            this.graphStatisticsToolStripMenuItem1.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.graphStatisticsToolStripMenuItem1.Name = "graphStatisticsToolStripMenuItem1";
            this.graphStatisticsToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.graphStatisticsToolStripMenuItem1.Text = "Graph Statistics";
            this.graphStatisticsToolStripMenuItem1.Click += new System.EventHandler(this.graphStatisticsToolStripMenuItem1_Click);
            // 
            // nodesToolStripMenuItem1
            // 
            this.nodesToolStripMenuItem1.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.nodesToolStripMenuItem1.Name = "nodesToolStripMenuItem1";
            this.nodesToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.nodesToolStripMenuItem1.Text = "Nodes";
            this.nodesToolStripMenuItem1.Click += new System.EventHandler(this.nodesToolStripMenuItem1_Click);
            // 
            // linkCostsToolStripMenuItem
            // 
            this.linkCostsToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.linkCostsToolStripMenuItem.Name = "linkCostsToolStripMenuItem";
            this.linkCostsToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.linkCostsToolStripMenuItem.Text = "Link Costs";
            this.linkCostsToolStripMenuItem.Click += new System.EventHandler(this.linkCostsToolStripMenuItem_Click);
            // 
            // linkSUEToolStripMenuItem1
            // 
            this.linkSUEToolStripMenuItem1.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.linkSUEToolStripMenuItem1.Name = "linkSUEToolStripMenuItem1";
            this.linkSUEToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.linkSUEToolStripMenuItem1.Text = "Link SUE";
            this.linkSUEToolStripMenuItem1.Click += new System.EventHandler(this.linkSUEToolStripMenuItem1_Click);
            // 
            // oDPairsToolStripMenuItem1
            // 
            this.oDPairsToolStripMenuItem1.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.oDPairsToolStripMenuItem1.Name = "oDPairsToolStripMenuItem1";
            this.oDPairsToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.oDPairsToolStripMenuItem1.Text = "OD Pairs";
            this.oDPairsToolStripMenuItem1.Click += new System.EventHandler(this.oDPairsToolStripMenuItem1_Click);
            // 
            // pathsToolStripMenuItem1
            // 
            this.pathsToolStripMenuItem1.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.pathsToolStripMenuItem1.Name = "pathsToolStripMenuItem1";
            this.pathsToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.pathsToolStripMenuItem1.Text = "Paths";
            this.pathsToolStripMenuItem1.Click += new System.EventHandler(this.pathsToolStripMenuItem1_Click);
            // 
            // mSASolutionToolStripMenuItem
            // 
            this.mSASolutionToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_export1;
            this.mSASolutionToolStripMenuItem.Name = "mSASolutionToolStripMenuItem";
            this.mSASolutionToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.mSASolutionToolStripMenuItem.Text = "MSA Solution";
            this.mSASolutionToolStripMenuItem.Click += new System.EventHandler(this.mSASolutionToolStripMenuItem_Click);
            // 
            // pathGenerationToolStripMenuItem
            // 
            this.pathGenerationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yensKShortestPathAlgorithmToolStripMenuItem,
            this.dialsAlgorithmToolStripMenuItem,
            this.linkPenaltyToolStripMenuItem,
            this.linkEliminationToolStripMenuItem,
            this.linkPenaltyLinkEliminationToolStripMenuItem,
            this.linkEliminationLinkPenaltyToolStripMenuItem});
            this.pathGenerationToolStripMenuItem.Name = "pathGenerationToolStripMenuItem";
            this.pathGenerationToolStripMenuItem.Size = new System.Drawing.Size(104, 19);
            this.pathGenerationToolStripMenuItem.Text = "&Path Generation";
            // 
            // yensKShortestPathAlgorithmToolStripMenuItem
            // 
            this.yensKShortestPathAlgorithmToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.yensKShortestPathAlgorithmToolStripMenuItem.Name = "yensKShortestPathAlgorithmToolStripMenuItem";
            this.yensKShortestPathAlgorithmToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.yensKShortestPathAlgorithmToolStripMenuItem.Text = "Yen\'s Algorithm";
            this.yensKShortestPathAlgorithmToolStripMenuItem.ToolTipText = "Yen, J.Y. (1971)";
            this.yensKShortestPathAlgorithmToolStripMenuItem.Click += new System.EventHandler(this.yensKShortestPathAlgorithmToolStripMenuItem_Click);
            // 
            // dialsAlgorithmToolStripMenuItem
            // 
            this.dialsAlgorithmToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.dialsAlgorithmToolStripMenuItem.Name = "dialsAlgorithmToolStripMenuItem";
            this.dialsAlgorithmToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.dialsAlgorithmToolStripMenuItem.Text = "Dial\'s Algorithm";
            this.dialsAlgorithmToolStripMenuItem.ToolTipText = "Dial, R.B. (1971)";
            this.dialsAlgorithmToolStripMenuItem.Click += new System.EventHandler(this.dialsAlgorithmToolStripMenuItem_Click);
            // 
            // linkPenaltyToolStripMenuItem
            // 
            this.linkPenaltyToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.linkPenaltyToolStripMenuItem.Name = "linkPenaltyToolStripMenuItem";
            this.linkPenaltyToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.linkPenaltyToolStripMenuItem.Text = "Link Penalty";
            this.linkPenaltyToolStripMenuItem.ToolTipText = "De La Barra, T. et al. (1993)";
            this.linkPenaltyToolStripMenuItem.Click += new System.EventHandler(this.linkPenaltyToolStripMenuItem_Click);
            // 
            // linkEliminationToolStripMenuItem
            // 
            this.linkEliminationToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.linkEliminationToolStripMenuItem.Name = "linkEliminationToolStripMenuItem";
            this.linkEliminationToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.linkEliminationToolStripMenuItem.Text = "Link Elimination";
            this.linkEliminationToolStripMenuItem.ToolTipText = "Azevedo, J.A. et al. (1993)";
            this.linkEliminationToolStripMenuItem.Click += new System.EventHandler(this.linkEliminationToolStripMenuItem_Click);
            // 
            // linkPenaltyLinkEliminationToolStripMenuItem
            // 
            this.linkPenaltyLinkEliminationToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.linkPenaltyLinkEliminationToolStripMenuItem.Name = "linkPenaltyLinkEliminationToolStripMenuItem";
            this.linkPenaltyLinkEliminationToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.linkPenaltyLinkEliminationToolStripMenuItem.Text = "Link Penalty > Link Elimination";
            this.linkPenaltyLinkEliminationToolStripMenuItem.Click += new System.EventHandler(this.linkPenaltyLinkEliminationToolStripMenuItem_Click);
            // 
            // linkEliminationLinkPenaltyToolStripMenuItem
            // 
            this.linkEliminationLinkPenaltyToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.linkEliminationLinkPenaltyToolStripMenuItem.Name = "linkEliminationLinkPenaltyToolStripMenuItem";
            this.linkEliminationLinkPenaltyToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.linkEliminationLinkPenaltyToolStripMenuItem.Text = "Link Elimination > Link Penalty";
            this.linkEliminationLinkPenaltyToolStripMenuItem.Click += new System.EventHandler(this.linkEliminationLinkPenaltyToolStripMenuItem_Click);
            // 
            // choiceModelWizardToolStripMenuItem
            // 
            this.choiceModelWizardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logitToolStripMenuItem,
            this.weibitToolStripMenuItem,
            this.mDMToolStripMenuItem,
            this.mDMWithNormalMDsToolStripMenuItem});
            this.choiceModelWizardToolStripMenuItem.Name = "choiceModelWizardToolStripMenuItem";
            this.choiceModelWizardToolStripMenuItem.Size = new System.Drawing.Size(132, 19);
            this.choiceModelWizardToolStripMenuItem.Text = "&Choice Model Wizard";
            // 
            // logitToolStripMenuItem
            // 
            this.logitToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_wizard;
            this.logitToolStripMenuItem.Name = "logitToolStripMenuItem";
            this.logitToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.logitToolStripMenuItem.Text = "Logit";
            this.logitToolStripMenuItem.Click += new System.EventHandler(this.logitToolStripMenuItem_Click);
            // 
            // weibitToolStripMenuItem
            // 
            this.weibitToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_wizard;
            this.weibitToolStripMenuItem.Name = "weibitToolStripMenuItem";
            this.weibitToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.weibitToolStripMenuItem.Text = "Weibit";
            this.weibitToolStripMenuItem.Click += new System.EventHandler(this.weibitToolStripMenuItem_Click);
            // 
            // mDMToolStripMenuItem
            // 
            this.mDMToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_wizard;
            this.mDMToolStripMenuItem.Name = "mDMToolStripMenuItem";
            this.mDMToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.mDMToolStripMenuItem.Text = "MDM with Exponential MDs";
            this.mDMToolStripMenuItem.Click += new System.EventHandler(this.mDMToolStripMenuItem_Click);
            // 
            // mDMWithNormalMDsToolStripMenuItem
            // 
            this.mDMWithNormalMDsToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_wizard;
            this.mDMWithNormalMDsToolStripMenuItem.Name = "mDMWithNormalMDsToolStripMenuItem";
            this.mDMWithNormalMDsToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.mDMWithNormalMDsToolStripMenuItem.Text = "MDM with Normal MDs";
            this.mDMWithNormalMDsToolStripMenuItem.Click += new System.EventHandler(this.mDMWithNormalMDsToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.networkVisualizationToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 19);
            this.reportToolStripMenuItem.Text = "&Report";
            // 
            // networkVisualizationToolStripMenuItem
            // 
            this.networkVisualizationToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_network;
            this.networkVisualizationToolStripMenuItem.Name = "networkVisualizationToolStripMenuItem";
            this.networkVisualizationToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.networkVisualizationToolStripMenuItem.Text = "Network Visualization";
            this.networkVisualizationToolStripMenuItem.Click += new System.EventHandler(this.networkVisualizationToolStripMenuItem_Click);
            // 
            // sensitivityAnalysisToolStripMenuItem
            // 
            this.sensitivityAnalysisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.perturbODDemandToolStripMenuItem,
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem});
            this.sensitivityAnalysisToolStripMenuItem.Name = "sensitivityAnalysisToolStripMenuItem";
            this.sensitivityAnalysisToolStripMenuItem.Size = new System.Drawing.Size(118, 19);
            this.sensitivityAnalysisToolStripMenuItem.Text = "&Sensitivity Analysis";
            // 
            // perturbODDemandToolStripMenuItem
            // 
            this.perturbODDemandToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.perturbODDemandToolStripMenuItem.Name = "perturbODDemandToolStripMenuItem";
            this.perturbODDemandToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.perturbODDemandToolStripMenuItem.Text = "Perturb OD Demand";
            this.perturbODDemandToolStripMenuItem.Click += new System.EventHandler(this.perturbODDemandToolStripMenuItem_Click);
            // 
            // perturbLinkFreeFlowTravelTimeToolStripMenuItem
            // 
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem.Image = global::SeSue.Properties.Resources.cmn_execution;
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem.Name = "perturbLinkFreeFlowTravelTimeToolStripMenuItem";
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem.Text = "Perturb Link Free Flow Travel Time";
            this.perturbLinkFreeFlowTravelTimeToolStripMenuItem.Click += new System.EventHandler(this.perturbLinkFreeFlowTravelTimeToolStripMenuItem_Click);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabGraph);
            this.tabMain.Controls.Add(this.tabNodes);
            this.tabMain.Controls.Add(this.tabLinks);
            this.tabMain.Controls.Add(this.tabOd);
            this.tabMain.Controls.Add(this.tabPaths);
            this.tabMain.Controls.Add(this.tabMsa);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.ItemSize = new System.Drawing.Size(96, 25);
            this.tabMain.Location = new System.Drawing.Point(9, 43);
            this.tabMain.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabMain.Multiline = true;
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1038, 645);
            this.tabMain.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabMain.TabIndex = 1;
            // 
            // tabGraph
            // 
            this.tabGraph.Controls.Add(this.splitGraph1);
            this.tabGraph.Location = new System.Drawing.Point(4, 29);
            this.tabGraph.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabGraph.Name = "tabGraph";
            this.tabGraph.Padding = new System.Windows.Forms.Padding(12, 10, 12, 10);
            this.tabGraph.Size = new System.Drawing.Size(1030, 612);
            this.tabGraph.TabIndex = 0;
            this.tabGraph.Text = "    Graph    ";
            this.tabGraph.UseVisualStyleBackColor = true;
            // 
            // splitGraph1
            // 
            this.splitGraph1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitGraph1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitGraph1.IsSplitterFixed = true;
            this.splitGraph1.Location = new System.Drawing.Point(12, 10);
            this.splitGraph1.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitGraph1.Name = "splitGraph1";
            this.splitGraph1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitGraph1.Panel1
            // 
            this.splitGraph1.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.splitGraph1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitGraph1.Panel2
            // 
            this.splitGraph1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitGraph1.Size = new System.Drawing.Size(1006, 592);
            this.splitGraph1.SplitterDistance = 213;
            this.splitGraph1.SplitterWidth = 6;
            this.splitGraph1.TabIndex = 2;
            this.splitGraph1.TabStop = false;
            // 
            // tabNodes
            // 
            this.tabNodes.Location = new System.Drawing.Point(4, 29);
            this.tabNodes.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabNodes.Name = "tabNodes";
            this.tabNodes.Padding = new System.Windows.Forms.Padding(7);
            this.tabNodes.Size = new System.Drawing.Size(898, 522);
            this.tabNodes.TabIndex = 1;
            this.tabNodes.Text = "    Nodes    ";
            this.tabNodes.UseVisualStyleBackColor = true;
            // 
            // tabLinks
            // 
            this.tabLinks.Controls.Add(this.tab2);
            this.tabLinks.Location = new System.Drawing.Point(4, 29);
            this.tabLinks.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabLinks.Name = "tabLinks";
            this.tabLinks.Padding = new System.Windows.Forms.Padding(0, 7, 0, 0);
            this.tabLinks.Size = new System.Drawing.Size(898, 522);
            this.tabLinks.TabIndex = 2;
            this.tabLinks.Text = "    Links    ";
            this.tabLinks.UseVisualStyleBackColor = true;
            // 
            // tab2
            // 
            this.tab2.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tab2.Controls.Add(this.tabLinkCost);
            this.tab2.Controls.Add(this.tabLinkSue);
            this.tab2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab2.ItemSize = new System.Drawing.Size(100, 25);
            this.tab2.Location = new System.Drawing.Point(0, 7);
            this.tab2.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tab2.Multiline = true;
            this.tab2.Name = "tab2";
            this.tab2.SelectedIndex = 0;
            this.tab2.Size = new System.Drawing.Size(898, 515);
            this.tab2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tab2.TabIndex = 0;
            // 
            // tabLinkCost
            // 
            this.tabLinkCost.Location = new System.Drawing.Point(29, 4);
            this.tabLinkCost.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabLinkCost.Name = "tabLinkCost";
            this.tabLinkCost.Padding = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabLinkCost.Size = new System.Drawing.Size(865, 507);
            this.tabLinkCost.TabIndex = 0;
            this.tabLinkCost.Text = "Cost View";
            this.tabLinkCost.UseVisualStyleBackColor = true;
            // 
            // tabLinkSue
            // 
            this.tabLinkSue.Location = new System.Drawing.Point(29, 4);
            this.tabLinkSue.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabLinkSue.Name = "tabLinkSue";
            this.tabLinkSue.Padding = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabLinkSue.Size = new System.Drawing.Size(865, 507);
            this.tabLinkSue.TabIndex = 1;
            this.tabLinkSue.Text = "SUE View";
            this.tabLinkSue.UseVisualStyleBackColor = true;
            // 
            // tabOd
            // 
            this.tabOd.Location = new System.Drawing.Point(4, 29);
            this.tabOd.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabOd.Name = "tabOd";
            this.tabOd.Padding = new System.Windows.Forms.Padding(7);
            this.tabOd.Size = new System.Drawing.Size(898, 522);
            this.tabOd.TabIndex = 3;
            this.tabOd.Text = "    OD Pairs    ";
            this.tabOd.UseVisualStyleBackColor = true;
            // 
            // tabPaths
            // 
            this.tabPaths.Controls.Add(this.splitPaths);
            this.tabPaths.Location = new System.Drawing.Point(4, 29);
            this.tabPaths.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabPaths.Name = "tabPaths";
            this.tabPaths.Padding = new System.Windows.Forms.Padding(7);
            this.tabPaths.Size = new System.Drawing.Size(898, 522);
            this.tabPaths.TabIndex = 4;
            this.tabPaths.Text = "    Paths    ";
            this.tabPaths.UseVisualStyleBackColor = true;
            // 
            // splitPaths
            // 
            this.splitPaths.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitPaths.IsSplitterFixed = true;
            this.splitPaths.Location = new System.Drawing.Point(7, 7);
            this.splitPaths.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths.Name = "splitPaths";
            this.splitPaths.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths.Panel1
            // 
            this.splitPaths.Panel1.Controls.Add(this.splitPaths2);
            this.splitPaths.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths.Panel2
            // 
            this.splitPaths.Panel2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.splitPaths.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths.Size = new System.Drawing.Size(884, 508);
            this.splitPaths.SplitterDistance = 56;
            this.splitPaths.SplitterWidth = 6;
            this.splitPaths.TabIndex = 0;
            this.splitPaths.TabStop = false;
            // 
            // splitPaths2
            // 
            this.splitPaths2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2.Name = "splitPaths2";
            // 
            // splitPaths2.Panel1
            // 
            this.splitPaths2.Panel1.Controls.Add(this.splitPaths2a);
            this.splitPaths2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2.Panel2
            // 
            this.splitPaths2.Panel2.Controls.Add(this.splitPaths2b);
            this.splitPaths2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2.Size = new System.Drawing.Size(884, 56);
            this.splitPaths2.SplitterDistance = 444;
            this.splitPaths2.SplitterWidth = 5;
            this.splitPaths2.TabIndex = 0;
            this.splitPaths2.TabStop = false;
            // 
            // splitPaths2a
            // 
            this.splitPaths2a.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a.IsSplitterFixed = true;
            this.splitPaths2a.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2a.Name = "splitPaths2a";
            // 
            // splitPaths2a.Panel1
            // 
            this.splitPaths2a.Panel1.Controls.Add(this.splitPaths2a1);
            this.splitPaths2a.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2a.Panel2
            // 
            this.splitPaths2a.Panel2.Controls.Add(this.splitPaths2a2);
            this.splitPaths2a.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2a.Size = new System.Drawing.Size(444, 56);
            this.splitPaths2a.SplitterDistance = 220;
            this.splitPaths2a.SplitterWidth = 5;
            this.splitPaths2a.TabIndex = 0;
            this.splitPaths2a.TabStop = false;
            // 
            // splitPaths2a1
            // 
            this.splitPaths2a1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a1.IsSplitterFixed = true;
            this.splitPaths2a1.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a1.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2a1.Name = "splitPaths2a1";
            this.splitPaths2a1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2a1.Panel1
            // 
            this.splitPaths2a1.Panel1.Controls.Add(this.label1);
            this.splitPaths2a1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2a1.Panel2
            // 
            this.splitPaths2a1.Panel2.Controls.Add(this.cbPaths_OdPairs);
            this.splitPaths2a1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2a1.Size = new System.Drawing.Size(220, 56);
            this.splitPaths2a1.SplitterDistance = 25;
            this.splitPaths2a1.SplitterWidth = 6;
            this.splitPaths2a1.TabIndex = 0;
            this.splitPaths2a1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "OD Pair";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // cbPaths_OdPairs
            // 
            this.cbPaths_OdPairs.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbPaths_OdPairs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbPaths_OdPairs.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cbPaths_OdPairs.FormattingEnabled = true;
            this.cbPaths_OdPairs.Location = new System.Drawing.Point(0, 2);
            this.cbPaths_OdPairs.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.cbPaths_OdPairs.Name = "cbPaths_OdPairs";
            this.cbPaths_OdPairs.Size = new System.Drawing.Size(220, 23);
            this.cbPaths_OdPairs.TabIndex = 0;
            // 
            // splitPaths2a2
            // 
            this.splitPaths2a2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a2.IsSplitterFixed = true;
            this.splitPaths2a2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a2.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2a2.Name = "splitPaths2a2";
            this.splitPaths2a2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2a2.Panel1
            // 
            this.splitPaths2a2.Panel1.Controls.Add(this.label2);
            this.splitPaths2a2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2a2.Panel2
            // 
            this.splitPaths2a2.Panel2.Controls.Add(this.tbPaths_Nodes);
            this.splitPaths2a2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2a2.Size = new System.Drawing.Size(219, 56);
            this.splitPaths2a2.SplitterDistance = 25;
            this.splitPaths2a2.SplitterWidth = 6;
            this.splitPaths2a2.TabIndex = 0;
            this.splitPaths2a2.TabStop = false;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Location = new System.Drawing.Point(0, 8);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Included Nodes";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tbPaths_Nodes
            // 
            this.tbPaths_Nodes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbPaths_Nodes.Location = new System.Drawing.Point(0, 2);
            this.tbPaths_Nodes.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tbPaths_Nodes.Name = "tbPaths_Nodes";
            this.tbPaths_Nodes.Size = new System.Drawing.Size(219, 23);
            this.tbPaths_Nodes.TabIndex = 0;
            this.tbPaths_Nodes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitPaths2b
            // 
            this.splitPaths2b.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b.IsSplitterFixed = true;
            this.splitPaths2b.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2b.Name = "splitPaths2b";
            // 
            // splitPaths2b.Panel1
            // 
            this.splitPaths2b.Panel1.Controls.Add(this.splitPaths2b1);
            this.splitPaths2b.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2b.Panel2
            // 
            this.splitPaths2b.Panel2.Controls.Add(this.splitPaths2b2);
            this.splitPaths2b.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2b.Size = new System.Drawing.Size(435, 56);
            this.splitPaths2b.SplitterDistance = 219;
            this.splitPaths2b.SplitterWidth = 5;
            this.splitPaths2b.TabIndex = 0;
            this.splitPaths2b.TabStop = false;
            // 
            // splitPaths2b1
            // 
            this.splitPaths2b1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b1.IsSplitterFixed = true;
            this.splitPaths2b1.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b1.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2b1.Name = "splitPaths2b1";
            this.splitPaths2b1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2b1.Panel1
            // 
            this.splitPaths2b1.Panel1.Controls.Add(this.label3);
            this.splitPaths2b1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2b1.Panel2
            // 
            this.splitPaths2b1.Panel2.Controls.Add(this.tbPaths_Links);
            this.splitPaths2b1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2b1.Size = new System.Drawing.Size(219, 56);
            this.splitPaths2b1.SplitterDistance = 25;
            this.splitPaths2b1.SplitterWidth = 6;
            this.splitPaths2b1.TabIndex = 0;
            this.splitPaths2b1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Location = new System.Drawing.Point(0, 8);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(219, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Included Links";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tbPaths_Links
            // 
            this.tbPaths_Links.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbPaths_Links.Location = new System.Drawing.Point(0, 2);
            this.tbPaths_Links.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tbPaths_Links.Name = "tbPaths_Links";
            this.tbPaths_Links.Size = new System.Drawing.Size(219, 23);
            this.tbPaths_Links.TabIndex = 0;
            this.tbPaths_Links.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitPaths2b2
            // 
            this.splitPaths2b2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b2.IsSplitterFixed = true;
            this.splitPaths2b2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b2.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitPaths2b2.Name = "splitPaths2b2";
            this.splitPaths2b2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2b2.Panel1
            // 
            this.splitPaths2b2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitPaths2b2.Panel2
            // 
            this.splitPaths2b2.Panel2.Controls.Add(this.btnPathsFilter);
            this.splitPaths2b2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitPaths2b2.Size = new System.Drawing.Size(211, 56);
            this.splitPaths2b2.SplitterDistance = 25;
            this.splitPaths2b2.SplitterWidth = 6;
            this.splitPaths2b2.TabIndex = 0;
            this.splitPaths2b2.TabStop = false;
            // 
            // btnPathsFilter
            // 
            this.btnPathsFilter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnPathsFilter.Location = new System.Drawing.Point(0, 0);
            this.btnPathsFilter.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnPathsFilter.Name = "btnPathsFilter";
            this.btnPathsFilter.Size = new System.Drawing.Size(211, 25);
            this.btnPathsFilter.TabIndex = 0;
            this.btnPathsFilter.Text = "Filter";
            this.btnPathsFilter.UseVisualStyleBackColor = true;
            this.btnPathsFilter.Click += new System.EventHandler(this.btnPathsFilter_Click);
            // 
            // tabMsa
            // 
            this.tabMsa.Controls.Add(this.splitMsa);
            this.tabMsa.Location = new System.Drawing.Point(4, 29);
            this.tabMsa.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.tabMsa.Name = "tabMsa";
            this.tabMsa.Padding = new System.Windows.Forms.Padding(7);
            this.tabMsa.Size = new System.Drawing.Size(898, 522);
            this.tabMsa.TabIndex = 5;
            this.tabMsa.Text = "    MSA    ";
            this.tabMsa.UseVisualStyleBackColor = true;
            // 
            // splitMsa
            // 
            this.splitMsa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMsa.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitMsa.IsSplitterFixed = true;
            this.splitMsa.Location = new System.Drawing.Point(7, 7);
            this.splitMsa.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitMsa.Name = "splitMsa";
            this.splitMsa.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitMsa.Panel1
            // 
            this.splitMsa.Panel1.BackColor = System.Drawing.Color.White;
            this.splitMsa.Panel1.Controls.Add(this.splitMsaButtons);
            this.splitMsa.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitMsa.Panel2
            // 
            this.splitMsa.Panel2.BackColor = System.Drawing.Color.Transparent;
            this.splitMsa.Panel2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.splitMsa.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitMsa.Size = new System.Drawing.Size(884, 508);
            this.splitMsa.SplitterDistance = 34;
            this.splitMsa.SplitterWidth = 6;
            this.splitMsa.TabIndex = 3;
            this.splitMsa.TabStop = false;
            // 
            // splitMsaButtons
            // 
            this.splitMsaButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMsaButtons.Location = new System.Drawing.Point(0, 0);
            this.splitMsaButtons.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.splitMsaButtons.Name = "splitMsaButtons";
            // 
            // splitMsaButtons.Panel1
            // 
            this.splitMsaButtons.Panel1.Controls.Add(this.btnMsaProps);
            this.splitMsaButtons.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitMsaButtons.Panel2
            // 
            this.splitMsaButtons.Panel2.Controls.Add(this.btnMsaRun);
            this.splitMsaButtons.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitMsaButtons.Size = new System.Drawing.Size(884, 34);
            this.splitMsaButtons.SplitterDistance = 683;
            this.splitMsaButtons.SplitterWidth = 5;
            this.splitMsaButtons.TabIndex = 0;
            // 
            // btnMsaProps
            // 
            this.btnMsaProps.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnMsaProps.Location = new System.Drawing.Point(0, 4);
            this.btnMsaProps.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnMsaProps.Name = "btnMsaProps";
            this.btnMsaProps.Size = new System.Drawing.Size(683, 30);
            this.btnMsaProps.TabIndex = 1;
            this.btnMsaProps.Text = "Props";
            this.btnMsaProps.UseVisualStyleBackColor = true;
            this.btnMsaProps.Click += new System.EventHandler(this.btnMsaProps_Click);
            // 
            // btnMsaRun
            // 
            this.btnMsaRun.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnMsaRun.Location = new System.Drawing.Point(0, 4);
            this.btnMsaRun.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.btnMsaRun.Name = "btnMsaRun";
            this.btnMsaRun.Size = new System.Drawing.Size(196, 30);
            this.btnMsaRun.TabIndex = 0;
            this.btnMsaRun.Text = "Run";
            this.btnMsaRun.UseVisualStyleBackColor = true;
            this.btnMsaRun.Click += new System.EventHandler(this.btnMsaRun_Click);
            // 
            // bgwRead
            // 
            this.bgwRead.WorkerReportsProgress = true;
            this.bgwRead.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwRead_DoWork);
            this.bgwRead.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwRead_RunWorkerCompleted);
            // 
            // bgwMsa
            // 
            this.bgwMsa.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwMsa_DoWork);
            this.bgwMsa.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwMsa_RunWorkerCompleted);
            // 
            // bgwSave
            // 
            this.bgwSave.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwSave_DoWork);
            this.bgwSave.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwSave_RunWorkerCompleted);
            // 
            // bgwExport
            // 
            this.bgwExport.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwExport_DoWork);
            this.bgwExport.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwExport_RunWorkerCompleted);
            // 
            // bgwExportPath
            // 
            this.bgwExportPath.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwExportPath_DoWork);
            this.bgwExportPath.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwExportPath_RunWorkerCompleted);
            // 
            // SueForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1056, 695);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            this.Name = "SueForm";
            this.Padding = new System.Windows.Forms.Padding(9, 0, 9, 7);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SueForm";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SueForm_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabMain.ResumeLayout(false);
            this.tabGraph.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitGraph1)).EndInit();
            this.splitGraph1.ResumeLayout(false);
            this.tabLinks.ResumeLayout(false);
            this.tab2.ResumeLayout(false);
            this.tabPaths.ResumeLayout(false);
            this.splitPaths.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths)).EndInit();
            this.splitPaths.ResumeLayout(false);
            this.splitPaths2.Panel1.ResumeLayout(false);
            this.splitPaths2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2)).EndInit();
            this.splitPaths2.ResumeLayout(false);
            this.splitPaths2a.Panel1.ResumeLayout(false);
            this.splitPaths2a.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a)).EndInit();
            this.splitPaths2a.ResumeLayout(false);
            this.splitPaths2a1.Panel1.ResumeLayout(false);
            this.splitPaths2a1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a1)).EndInit();
            this.splitPaths2a1.ResumeLayout(false);
            this.splitPaths2a2.Panel1.ResumeLayout(false);
            this.splitPaths2a2.Panel2.ResumeLayout(false);
            this.splitPaths2a2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a2)).EndInit();
            this.splitPaths2a2.ResumeLayout(false);
            this.splitPaths2b.Panel1.ResumeLayout(false);
            this.splitPaths2b.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b)).EndInit();
            this.splitPaths2b.ResumeLayout(false);
            this.splitPaths2b1.Panel1.ResumeLayout(false);
            this.splitPaths2b1.Panel2.ResumeLayout(false);
            this.splitPaths2b1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b1)).EndInit();
            this.splitPaths2b1.ResumeLayout(false);
            this.splitPaths2b2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b2)).EndInit();
            this.splitPaths2b2.ResumeLayout(false);
            this.tabMsa.ResumeLayout(false);
            this.splitMsa.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitMsa)).EndInit();
            this.splitMsa.ResumeLayout(false);
            this.splitMsaButtons.Panel1.ResumeLayout(false);
            this.splitMsaButtons.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitMsaButtons)).EndInit();
            this.splitMsaButtons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabGraph;
        private System.Windows.Forms.SplitContainer splitGraph1;
        private System.Windows.Forms.TabPage tabNodes;
        private System.Windows.Forms.TabPage tabLinks;
        private System.Windows.Forms.TabPage tabOd;
        private System.Windows.Forms.TabPage tabPaths;
        private System.Windows.Forms.TabPage tabMsa;
        private System.Windows.Forms.TabControl tab2;
        private System.Windows.Forms.TabPage tabLinkCost;
        private System.Windows.Forms.TabPage tabLinkSue;
        private System.Windows.Forms.SplitContainer splitMsa;
        private System.Windows.Forms.SplitContainer splitMsaButtons;
        private System.Windows.Forms.Button btnMsaRun;
        private System.Windows.Forms.ToolStripMenuItem menuOpen;
        private System.Windows.Forms.ToolStripMenuItem menuSave;
        private System.Windows.Forms.ToolStripMenuItem menuSaveAs;
        private System.Windows.Forms.ToolStripMenuItem choiceModelWizardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem weibitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mDMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mDMWithNormalMDsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pathGenerationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yensKShortestPathAlgorithmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dialsAlgorithmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkPenaltyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkEliminationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkPenaltyLinkEliminationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkEliminationLinkPenaltyToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker bgwRead;
        private System.ComponentModel.BackgroundWorker bgwMsa;
        private System.Windows.Forms.SplitContainer splitPaths;
        private System.Windows.Forms.SplitContainer splitPaths2;
        private System.Windows.Forms.SplitContainer splitPaths2a;
        private System.Windows.Forms.SplitContainer splitPaths2b;
        private System.Windows.Forms.SplitContainer splitPaths2a1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitPaths2a2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitPaths2b1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.SplitContainer splitPaths2b2;
        private System.Windows.Forms.Button btnPathsFilter;
        public System.Windows.Forms.TextBox tbPaths_Nodes;
        public System.Windows.Forms.TextBox tbPaths_Links;
        public System.Windows.Forms.ComboBox cbPaths_OdPairs;
        private System.ComponentModel.BackgroundWorker bgwSave;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker bgwExport;
        private System.ComponentModel.BackgroundWorker bgwExportPath;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem networkVisualizationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sensitivityAnalysisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem perturbODDemandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem perturbLinkFreeFlowTravelTimeToolStripMenuItem;
        public System.Windows.Forms.Button btnMsaProps;
        private System.Windows.Forms.ToolStripMenuItem graphStatisticsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nodesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem linkCostsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkSUEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem oDPairsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pathsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mSASolutionToolStripMenuItem;
    }
}