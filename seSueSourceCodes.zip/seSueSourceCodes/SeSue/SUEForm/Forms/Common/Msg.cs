﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue.Forms.Common
{
    public partial class Msg : Form
    {
        public Msg(string title, string message, Form parent)
        {
            InitializeComponent();
            //this.Text = title;
            this.label.Text = message;
            this.Icon = SeSue.Properties.Resources.message;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        public static void show(string title, string message, Form parent)
        {
            Msg f = new Msg(title, message, parent);
            f.ShowDialog(parent);
        }

        
    }
}
