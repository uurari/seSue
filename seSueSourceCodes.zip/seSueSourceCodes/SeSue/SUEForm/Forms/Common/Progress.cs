﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue.Forms.Common
{
    public class Progress
    {
        private static Processing processing = new Processing();


        public static void show(Form parent) { processing.ShowDialog(parent); }

        public static void hide() { processing.Hide(); }

        public static void setText(string txt) { processing.label.Text = txt; }
        

    }
}
