﻿using SeSue.Forms.PathGeneration;
using SeSue.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;
using U.SUE.Algorithms;

namespace SeSue.Forms.Common
{
    public partial class MsaForm : Form
    {
        //public static MSA msa;
        //public static bool newMsa;

        private int originalTypeIndex;
        private MSA originalMsa;
        private TbAndLabel iterLim;
        private TbAndLabel threshold;
        private TbAndLabel arg1;
        private TbAndLabel arg2;

        public static MSA newMsa;
        public static bool newMsaCreated;


        public MsaForm(MSA msa, int w, int h)
        {
            InitializeComponent();

            this.Icon = Resources.logo;
            if (w < this.Width) { this.Width = w; }
            if (h < this.Height) { this.Height = h; }

            originalMsa = msa;
            newMsaCreated = false;

            iterLim = new TbAndLabel("iterLim", "Maximum number of MSA iterations.", msa.getMaxNbIterations().ToString(), HorizontalAlignment.Right, typeof(int), TbAndLabel.NumberCondition.Positive);
            splitContainer3.Panel1.Controls.Add(iterLim);

            threshold = new TbAndLabel("threshold", "RMSE threshold: MSA stops whenever total root mean square error of link flows of the last two MSA iterations drops below this threshold.", msa.getRmseThreshold().ToString(), HorizontalAlignment.Right, typeof(double), TbAndLabel.NumberCondition.Nonnegative);
            threshold.label.Dock = DockStyle.Fill;
            splitContainer3.Panel2.Controls.Add(threshold);

            arg1 = new TbAndLabel("arg1", String.Empty, "1", HorizontalAlignment.Right, typeof(double), TbAndLabel.NumberCondition.Nonnegative);
            arg2 = new TbAndLabel("arg2", String.Empty, "0", HorizontalAlignment.Right, typeof(double), TbAndLabel.NumberCondition.Nonnegative);
            arg1.Dock = DockStyle.Top; arg1.label.TextAlign = ContentAlignment.BottomCenter;
            arg2.Dock = DockStyle.Top; arg2.label.TextAlign = ContentAlignment.BottomCenter;
            splitContainer6.Panel1.Controls.Add(arg1);
            splitContainer6.Panel2.Controls.Add(arg2);

            int selected = 0;
            if (msa.getStepSize().GetType() == typeof(StepSizeLiu2009)) { selected = 1; }
            if (msa.getStepSize().GetType() == typeof(StepSizeNagurney1996)) { selected = 2; }
            if (msa.getStepSize().GetType() == typeof(StepSizePolyak1990)) { selected = 3; }
            originalTypeIndex = selected;
            cbStepsize.SelectedIndex = selected;
        }



        #region EVENTS
        private void cbStepsize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbStepsize.SelectedIndex == 0)
            {
                arg1.Visible = true;
                arg2.Visible = true;
                arg1.label.Text = "k1";
                arg2.label.Text = "k2";
                if (originalTypeIndex == 0)
                {
                    StepSizeStandard ss = (StepSizeStandard)originalMsa.getStepSize();
                    arg1.textBox.Text = ss.getK1().ToString();
                    arg2.textBox.Text = ss.getK2().ToString();
                }
                else
                {
                    arg1.textBox.Text = "1";
                    arg2.textBox.Text = "0";
                }
                pictureBox1.Image = Resources.SsStandard;
            }
            else if (cbStepsize.SelectedIndex == 1)
            {
                arg1.Visible = true;
                arg2.Visible = false;
                arg1.label.Text = "d";
                if (originalTypeIndex == 1)
                {
                    StepSizeLiu2009 ss = (StepSizeLiu2009)originalMsa.getStepSize();
                    arg1.textBox.Text = ss.getD().ToString();
                }
                else
                {
                    arg1.textBox.Text = "1";
                }
                pictureBox1.Image = Resources.SsLiu;
            }
            else
            {
                arg1.Visible = false;
                arg2.Visible = false;
                if (cbStepsize.SelectedIndex == 2)
                {
                    pictureBox1.Image = Resources.SsNagurney;
                }
                else if (cbStepsize.SelectedIndex == 3)
                {
                    pictureBox1.Image = Resources.SsPolyak;
                }
            }
        } 
        #endregion



        #region MSA GENERATION
        private void btnSave_Click(object sender, EventArgs e) { setMsa(); }
        public void setMsa()
        {
            StepSize stepSize;
            if (cbStepsize.SelectedIndex == 0) { stepSize = new StepSizeStandard(Str.toDouble(arg1.getText()), Str.toDouble(arg2.getText())); }
            else if (cbStepsize.SelectedIndex == 1) { stepSize = new StepSizeLiu2009(Str.toDouble(arg1.getText())); }
            else if (cbStepsize.SelectedIndex == 2) { stepSize = new StepSizeNagurney1996(); }
            else { stepSize = new StepSizePolyak1990(); }
            newMsa = new MSA(stepSize, Convert.ToInt64(iterLim.getText()), Str.toDouble(threshold.getText()));
            newMsaCreated = true;
            this.Close();
        }
        #endregion

    }
}
