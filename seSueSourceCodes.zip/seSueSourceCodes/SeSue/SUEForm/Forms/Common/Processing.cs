﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue.Forms.Common
{
    public partial class Processing : Form
    {
        public Processing()
        {
            InitializeComponent();
            this.pictureBox.Image = Properties.Resources.processing;
            this.Icon = Properties.Resources.logo;
        }
    }
}
