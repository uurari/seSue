﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue
{
    public partial class StringForm : Form
    {
        private string str;
        private bool okClicked;

        public StringForm(string title, string buttonText, string tbText)
        {
            InitializeComponent();
            this.Icon = SeSue.Properties.Resources.text;
            this.ShowInTaskbar = false;
            this.button.Text = buttonText;
            this.textBox.Text = tbText;
            this.Text = title;
            this.okClicked = false;
            if (buttonText == String.Empty) { this.button.Visible = false; }
        }

        public string getStr() { return this.str; }
        public bool isOkClicked() { return okClicked; }


        private void button_Click(object sender, EventArgs e)
        {
            this.str = this.textBox.Text;
            this.okClicked = true;
            this.Close();
        }

        private void resize()
        {
            splitContainer1.SplitterDistance = splitContainer1.Height - 45;
            int w = textBox.Parent.Width - 2 * 10;
            int h = textBox.Parent.Height - 1 * 10;
            textBox.Left = 10;
            textBox.Top = 10;
            textBox.Width = w;
            textBox.Height = h;
            button.Left = 10;
            button.Top = 0;
            button.Width = w;
            button.Height = button.Parent.Height - 10;
        }

        private void StringForm_Load(object sender, EventArgs e) { resize(); }

        private void StringForm_Resize(object sender, EventArgs e) { resize(); }





    }
}
