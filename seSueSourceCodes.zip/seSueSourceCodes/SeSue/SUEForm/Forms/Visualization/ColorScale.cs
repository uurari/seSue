﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace SeSue.Forms.Visualization
{
    public partial class ColorScale : UserControl
    {
        private Color colorMin = Color.FromArgb(0, 255, 0);
        private Color colorMax = Color.FromArgb(255, 0, 0);
        public static byte minR = 0;
        public static byte maxR = 255;
        public static byte minG = 255;
        public static byte maxG = 0;
        public static byte minB = 0;
        public static byte maxB = 0;

        private Bitmap colorSliderBitmap;
        private Rectangle rectangle;
        



        public ColorScale(List<string> items)
        {
            InitializeComponent();
            updateBrush();
            this.comboBox1.Items.Clear();
            foreach (string item in items) { this.comboBox1.Items.Add(item); }
            this.comboBox1.SelectedIndex = 0;
        }

        private void updateBrush()
        {
            minR = colorMin.R;
            maxR = colorMax.R;
            minG = colorMin.G;
            maxG = colorMax.G;
            minB = colorMin.B;
            maxB = colorMax.B;
            colorSliderBitmap = new Bitmap(pictureBox1.Width, 35);
            Graphics g = Graphics.FromImage(colorSliderBitmap);
            rectangle = new Rectangle(0, 0, pictureBox1.Width, 35);

            LinearGradientMode mode = LinearGradientMode.Horizontal;
            using (LinearGradientBrush lgb = new LinearGradientBrush(rectangle, colorMin, colorMax, mode))
            {
                g.FillRectangle(lgb, rectangle);
            }
            this.pictureBox1.Image = colorSliderBitmap;
        }

        private void labelMin_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = colorMin;
            DialogResult result = colorDialog1.ShowDialog();
            if (result == DialogResult.OK) { colorMin = colorDialog1.Color; }
            updateBrush();
        }
        private void labelMax_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = colorMax;
            DialogResult result = colorDialog1.ShowDialog();
            if (result == DialogResult.OK) { colorMax = colorDialog1.Color; }
            updateBrush();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.labelMin.Text = "Minimum" + Environment.NewLine + comboBox1.Text + Environment.NewLine + "Color";
            this.labelMax.Text = "Maximum" + Environment.NewLine + comboBox1.Text + Environment.NewLine + "Color";
        }


        #region PUBLIC
        public void onResize() { updateBrush(); }
        public List<byte> getMinRGB() { return new List<byte>() { minR, minG, minB }; }
        public List<byte> getMaxRGB() { return new List<byte>() { maxR, maxG, maxB }; }
        public int cbSelectedIndex() { return this.comboBox1.SelectedIndex; }
        #endregion


    }
}
