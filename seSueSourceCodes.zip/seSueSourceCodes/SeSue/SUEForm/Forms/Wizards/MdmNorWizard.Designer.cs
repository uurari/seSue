﻿namespace SeSue.Forms.Wizards
{
    partial class MdmNorWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tab3 = new System.Windows.Forms.TabPage();
            this.splitTab3a = new System.Windows.Forms.SplitContainer();
            this.splitPaths = new System.Windows.Forms.SplitContainer();
            this.splitPaths2 = new System.Windows.Forms.SplitContainer();
            this.splitPaths2a = new System.Windows.Forms.SplitContainer();
            this.splitPaths2a1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.cbPaths_OdPairs = new System.Windows.Forms.ComboBox();
            this.splitPaths2a2 = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.tbPaths_Nodes = new System.Windows.Forms.TextBox();
            this.splitPaths2b = new System.Windows.Forms.SplitContainer();
            this.splitPaths2b1 = new System.Windows.Forms.SplitContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPaths_Links = new System.Windows.Forms.TextBox();
            this.splitPaths2b2 = new System.Windows.Forms.SplitContainer();
            this.btnPathsFilter = new System.Windows.Forms.Button();
            this.splitTab3b = new System.Windows.Forms.SplitContainer();
            this.btnBack3 = new System.Windows.Forms.Button();
            this.btnNext3 = new System.Windows.Forms.Button();
            this.tab2 = new System.Windows.Forms.TabPage();
            this.splitTab2a = new System.Windows.Forms.SplitContainer();
            this.splitTab2c = new System.Windows.Forms.SplitContainer();
            this.splitTab2d = new System.Windows.Forms.SplitContainer();
            this.cbScaling = new System.Windows.Forms.ComboBox();
            this.cbCorrection = new System.Windows.Forms.ComboBox();
            this.splitTab2e = new System.Windows.Forms.SplitContainer();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.splitTab2b = new System.Windows.Forms.SplitContainer();
            this.btnBack2 = new System.Windows.Forms.Button();
            this.btnNext2 = new System.Windows.Forms.Button();
            this.tab1 = new System.Windows.Forms.TabPage();
            this.splitTab1a = new System.Windows.Forms.SplitContainer();
            this.splitTab1b = new System.Windows.Forms.SplitContainer();
            this.btnNext1 = new System.Windows.Forms.Button();
            this.tab = new System.Windows.Forms.TabControl();
            this.tab3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab3a)).BeginInit();
            this.splitTab3a.Panel1.SuspendLayout();
            this.splitTab3a.Panel2.SuspendLayout();
            this.splitTab3a.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths)).BeginInit();
            this.splitPaths.Panel1.SuspendLayout();
            this.splitPaths.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2)).BeginInit();
            this.splitPaths2.Panel1.SuspendLayout();
            this.splitPaths2.Panel2.SuspendLayout();
            this.splitPaths2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a)).BeginInit();
            this.splitPaths2a.Panel1.SuspendLayout();
            this.splitPaths2a.Panel2.SuspendLayout();
            this.splitPaths2a.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a1)).BeginInit();
            this.splitPaths2a1.Panel1.SuspendLayout();
            this.splitPaths2a1.Panel2.SuspendLayout();
            this.splitPaths2a1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a2)).BeginInit();
            this.splitPaths2a2.Panel1.SuspendLayout();
            this.splitPaths2a2.Panel2.SuspendLayout();
            this.splitPaths2a2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b)).BeginInit();
            this.splitPaths2b.Panel1.SuspendLayout();
            this.splitPaths2b.Panel2.SuspendLayout();
            this.splitPaths2b.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b1)).BeginInit();
            this.splitPaths2b1.Panel1.SuspendLayout();
            this.splitPaths2b1.Panel2.SuspendLayout();
            this.splitPaths2b1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b2)).BeginInit();
            this.splitPaths2b2.Panel2.SuspendLayout();
            this.splitPaths2b2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab3b)).BeginInit();
            this.splitTab3b.Panel1.SuspendLayout();
            this.splitTab3b.Panel2.SuspendLayout();
            this.splitTab3b.SuspendLayout();
            this.tab2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2a)).BeginInit();
            this.splitTab2a.Panel1.SuspendLayout();
            this.splitTab2a.Panel2.SuspendLayout();
            this.splitTab2a.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2c)).BeginInit();
            this.splitTab2c.Panel1.SuspendLayout();
            this.splitTab2c.Panel2.SuspendLayout();
            this.splitTab2c.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2d)).BeginInit();
            this.splitTab2d.Panel1.SuspendLayout();
            this.splitTab2d.Panel2.SuspendLayout();
            this.splitTab2d.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2e)).BeginInit();
            this.splitTab2e.Panel2.SuspendLayout();
            this.splitTab2e.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2b)).BeginInit();
            this.splitTab2b.Panel1.SuspendLayout();
            this.splitTab2b.Panel2.SuspendLayout();
            this.splitTab2b.SuspendLayout();
            this.tab1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab1a)).BeginInit();
            this.splitTab1a.Panel2.SuspendLayout();
            this.splitTab1a.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitTab1b)).BeginInit();
            this.splitTab1b.Panel2.SuspendLayout();
            this.splitTab1b.SuspendLayout();
            this.tab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab3
            // 
            this.tab3.Controls.Add(this.splitTab3a);
            this.tab3.Location = new System.Drawing.Point(4, 24);
            this.tab3.Name = "tab3";
            this.tab3.Padding = new System.Windows.Forms.Padding(3);
            this.tab3.Size = new System.Drawing.Size(845, 579);
            this.tab3.TabIndex = 2;
            this.tab3.Text = "Normal Distribution Parameters";
            this.tab3.UseVisualStyleBackColor = true;
            // 
            // splitTab3a
            // 
            this.splitTab3a.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab3a.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitTab3a.IsSplitterFixed = true;
            this.splitTab3a.Location = new System.Drawing.Point(3, 3);
            this.splitTab3a.Name = "splitTab3a";
            this.splitTab3a.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitTab3a.Panel1
            // 
            this.splitTab3a.Panel1.Controls.Add(this.splitPaths);
            // 
            // splitTab3a.Panel2
            // 
            this.splitTab3a.Panel2.Controls.Add(this.splitTab3b);
            this.splitTab3a.Size = new System.Drawing.Size(839, 573);
            this.splitTab3a.SplitterDistance = 540;
            this.splitTab3a.TabIndex = 0;
            this.splitTab3a.TabStop = false;
            // 
            // splitPaths
            // 
            this.splitPaths.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitPaths.IsSplitterFixed = true;
            this.splitPaths.Location = new System.Drawing.Point(0, 0);
            this.splitPaths.Name = "splitPaths";
            this.splitPaths.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths.Panel1
            // 
            this.splitPaths.Panel1.Controls.Add(this.splitPaths2);
            this.splitPaths.Size = new System.Drawing.Size(839, 540);
            this.splitPaths.SplitterDistance = 60;
            this.splitPaths.TabIndex = 3;
            this.splitPaths.TabStop = false;
            // 
            // splitPaths2
            // 
            this.splitPaths2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2.Name = "splitPaths2";
            // 
            // splitPaths2.Panel1
            // 
            this.splitPaths2.Panel1.Controls.Add(this.splitPaths2a);
            // 
            // splitPaths2.Panel2
            // 
            this.splitPaths2.Panel2.Controls.Add(this.splitPaths2b);
            this.splitPaths2.Size = new System.Drawing.Size(839, 60);
            this.splitPaths2.SplitterDistance = 417;
            this.splitPaths2.TabIndex = 0;
            this.splitPaths2.TabStop = false;
            // 
            // splitPaths2a
            // 
            this.splitPaths2a.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a.IsSplitterFixed = true;
            this.splitPaths2a.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a.Name = "splitPaths2a";
            // 
            // splitPaths2a.Panel1
            // 
            this.splitPaths2a.Panel1.Controls.Add(this.splitPaths2a1);
            // 
            // splitPaths2a.Panel2
            // 
            this.splitPaths2a.Panel2.Controls.Add(this.splitPaths2a2);
            this.splitPaths2a.Size = new System.Drawing.Size(417, 60);
            this.splitPaths2a.SplitterDistance = 207;
            this.splitPaths2a.TabIndex = 0;
            this.splitPaths2a.TabStop = false;
            // 
            // splitPaths2a1
            // 
            this.splitPaths2a1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a1.IsSplitterFixed = true;
            this.splitPaths2a1.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a1.Name = "splitPaths2a1";
            this.splitPaths2a1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2a1.Panel1
            // 
            this.splitPaths2a1.Panel1.Controls.Add(this.label1);
            // 
            // splitPaths2a1.Panel2
            // 
            this.splitPaths2a1.Panel2.Controls.Add(this.cbPaths_OdPairs);
            this.splitPaths2a1.Size = new System.Drawing.Size(207, 60);
            this.splitPaths2a1.SplitterDistance = 25;
            this.splitPaths2a1.TabIndex = 0;
            this.splitPaths2a1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "OD Pair";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbPaths_OdPairs
            // 
            this.cbPaths_OdPairs.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbPaths_OdPairs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbPaths_OdPairs.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbPaths_OdPairs.FormattingEnabled = true;
            this.cbPaths_OdPairs.Location = new System.Drawing.Point(0, 0);
            this.cbPaths_OdPairs.Name = "cbPaths_OdPairs";
            this.cbPaths_OdPairs.Size = new System.Drawing.Size(207, 23);
            this.cbPaths_OdPairs.TabIndex = 0;
            // 
            // splitPaths2a2
            // 
            this.splitPaths2a2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2a2.IsSplitterFixed = true;
            this.splitPaths2a2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2a2.Name = "splitPaths2a2";
            this.splitPaths2a2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2a2.Panel1
            // 
            this.splitPaths2a2.Panel1.Controls.Add(this.label2);
            // 
            // splitPaths2a2.Panel2
            // 
            this.splitPaths2a2.Panel2.Controls.Add(this.tbPaths_Nodes);
            this.splitPaths2a2.Size = new System.Drawing.Size(206, 60);
            this.splitPaths2a2.SplitterDistance = 25;
            this.splitPaths2a2.TabIndex = 0;
            this.splitPaths2a2.TabStop = false;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Location = new System.Drawing.Point(0, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Included Nodes";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbPaths_Nodes
            // 
            this.tbPaths_Nodes.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbPaths_Nodes.Location = new System.Drawing.Point(0, 0);
            this.tbPaths_Nodes.Name = "tbPaths_Nodes";
            this.tbPaths_Nodes.Size = new System.Drawing.Size(206, 23);
            this.tbPaths_Nodes.TabIndex = 0;
            this.tbPaths_Nodes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitPaths2b
            // 
            this.splitPaths2b.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b.IsSplitterFixed = true;
            this.splitPaths2b.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b.Name = "splitPaths2b";
            // 
            // splitPaths2b.Panel1
            // 
            this.splitPaths2b.Panel1.Controls.Add(this.splitPaths2b1);
            // 
            // splitPaths2b.Panel2
            // 
            this.splitPaths2b.Panel2.Controls.Add(this.splitPaths2b2);
            this.splitPaths2b.Size = new System.Drawing.Size(418, 60);
            this.splitPaths2b.SplitterDistance = 207;
            this.splitPaths2b.TabIndex = 0;
            this.splitPaths2b.TabStop = false;
            // 
            // splitPaths2b1
            // 
            this.splitPaths2b1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b1.IsSplitterFixed = true;
            this.splitPaths2b1.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b1.Name = "splitPaths2b1";
            this.splitPaths2b1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2b1.Panel1
            // 
            this.splitPaths2b1.Panel1.Controls.Add(this.label3);
            // 
            // splitPaths2b1.Panel2
            // 
            this.splitPaths2b1.Panel2.Controls.Add(this.tbPaths_Links);
            this.splitPaths2b1.Size = new System.Drawing.Size(207, 60);
            this.splitPaths2b1.SplitterDistance = 25;
            this.splitPaths2b1.TabIndex = 0;
            this.splitPaths2b1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Location = new System.Drawing.Point(0, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Included Links";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbPaths_Links
            // 
            this.tbPaths_Links.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbPaths_Links.Location = new System.Drawing.Point(0, 0);
            this.tbPaths_Links.Name = "tbPaths_Links";
            this.tbPaths_Links.Size = new System.Drawing.Size(207, 23);
            this.tbPaths_Links.TabIndex = 0;
            this.tbPaths_Links.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitPaths2b2
            // 
            this.splitPaths2b2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitPaths2b2.IsSplitterFixed = true;
            this.splitPaths2b2.Location = new System.Drawing.Point(0, 0);
            this.splitPaths2b2.Name = "splitPaths2b2";
            this.splitPaths2b2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitPaths2b2.Panel2
            // 
            this.splitPaths2b2.Panel2.Controls.Add(this.btnPathsFilter);
            this.splitPaths2b2.Size = new System.Drawing.Size(207, 60);
            this.splitPaths2b2.SplitterDistance = 25;
            this.splitPaths2b2.TabIndex = 0;
            this.splitPaths2b2.TabStop = false;
            // 
            // btnPathsFilter
            // 
            this.btnPathsFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPathsFilter.Location = new System.Drawing.Point(0, 0);
            this.btnPathsFilter.Name = "btnPathsFilter";
            this.btnPathsFilter.Size = new System.Drawing.Size(207, 25);
            this.btnPathsFilter.TabIndex = 0;
            this.btnPathsFilter.Text = "Filter";
            this.btnPathsFilter.UseVisualStyleBackColor = true;
            this.btnPathsFilter.Click += new System.EventHandler(this.btnPathsFilter_Click);
            // 
            // splitTab3b
            // 
            this.splitTab3b.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab3b.IsSplitterFixed = true;
            this.splitTab3b.Location = new System.Drawing.Point(0, 0);
            this.splitTab3b.Name = "splitTab3b";
            // 
            // splitTab3b.Panel1
            // 
            this.splitTab3b.Panel1.Controls.Add(this.btnBack3);
            // 
            // splitTab3b.Panel2
            // 
            this.splitTab3b.Panel2.Controls.Add(this.btnNext3);
            this.splitTab3b.Size = new System.Drawing.Size(839, 29);
            this.splitTab3b.SplitterDistance = 419;
            this.splitTab3b.TabIndex = 0;
            this.splitTab3b.TabStop = false;
            // 
            // btnBack3
            // 
            this.btnBack3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnBack3.Location = new System.Drawing.Point(0, -1);
            this.btnBack3.Name = "btnBack3";
            this.btnBack3.Size = new System.Drawing.Size(419, 30);
            this.btnBack3.TabIndex = 2;
            this.btnBack3.Text = "Back";
            this.btnBack3.UseVisualStyleBackColor = true;
            this.btnBack3.Click += new System.EventHandler(this.btnBack3_Click);
            // 
            // btnNext3
            // 
            this.btnNext3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnNext3.Location = new System.Drawing.Point(0, -1);
            this.btnNext3.Name = "btnNext3";
            this.btnNext3.Size = new System.Drawing.Size(416, 30);
            this.btnNext3.TabIndex = 2;
            this.btnNext3.Text = "Finish";
            this.btnNext3.UseVisualStyleBackColor = true;
            this.btnNext3.Click += new System.EventHandler(this.btnNext3_Click);
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.splitTab2a);
            this.tab2.Location = new System.Drawing.Point(4, 24);
            this.tab2.Name = "tab2";
            this.tab2.Padding = new System.Windows.Forms.Padding(3);
            this.tab2.Size = new System.Drawing.Size(845, 579);
            this.tab2.TabIndex = 1;
            this.tab2.Text = "Settings";
            this.tab2.UseVisualStyleBackColor = true;
            // 
            // splitTab2a
            // 
            this.splitTab2a.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab2a.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitTab2a.IsSplitterFixed = true;
            this.splitTab2a.Location = new System.Drawing.Point(3, 3);
            this.splitTab2a.Name = "splitTab2a";
            this.splitTab2a.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitTab2a.Panel1
            // 
            this.splitTab2a.Panel1.Controls.Add(this.splitTab2c);
            // 
            // splitTab2a.Panel2
            // 
            this.splitTab2a.Panel2.Controls.Add(this.splitTab2b);
            this.splitTab2a.Size = new System.Drawing.Size(839, 573);
            this.splitTab2a.SplitterDistance = 540;
            this.splitTab2a.TabIndex = 1;
            this.splitTab2a.TabStop = false;
            // 
            // splitTab2c
            // 
            this.splitTab2c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab2c.IsSplitterFixed = true;
            this.splitTab2c.Location = new System.Drawing.Point(0, 0);
            this.splitTab2c.Name = "splitTab2c";
            this.splitTab2c.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitTab2c.Panel1
            // 
            this.splitTab2c.Panel1.Controls.Add(this.splitTab2d);
            // 
            // splitTab2c.Panel2
            // 
            this.splitTab2c.Panel2.Controls.Add(this.splitTab2e);
            this.splitTab2c.Size = new System.Drawing.Size(839, 540);
            this.splitTab2c.SplitterDistance = 31;
            this.splitTab2c.TabIndex = 0;
            this.splitTab2c.TabStop = false;
            // 
            // splitTab2d
            // 
            this.splitTab2d.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab2d.IsSplitterFixed = true;
            this.splitTab2d.Location = new System.Drawing.Point(0, 0);
            this.splitTab2d.Name = "splitTab2d";
            // 
            // splitTab2d.Panel1
            // 
            this.splitTab2d.Panel1.Controls.Add(this.cbScaling);
            // 
            // splitTab2d.Panel2
            // 
            this.splitTab2d.Panel2.Controls.Add(this.cbCorrection);
            this.splitTab2d.Size = new System.Drawing.Size(839, 31);
            this.splitTab2d.SplitterDistance = 419;
            this.splitTab2d.TabIndex = 0;
            this.splitTab2d.TabStop = false;
            // 
            // cbScaling
            // 
            this.cbScaling.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cbScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbScaling.FormattingEnabled = true;
            this.cbScaling.Items.AddRange(new object[] {
            "None (theta)",
            "OD-level scaling using Scaling Factor",
            "OD-level scaling using Coefficient of Variation",
            "Path-level scaling using Scaling Factor",
            "Path-level scaling using Coefficient of Variation"});
            this.cbScaling.Location = new System.Drawing.Point(0, 8);
            this.cbScaling.Name = "cbScaling";
            this.cbScaling.Size = new System.Drawing.Size(419, 23);
            this.cbScaling.TabIndex = 0;
            this.cbScaling.SelectedIndexChanged += new System.EventHandler(this.cbScaling_SelectedIndexChanged);
            // 
            // cbCorrection
            // 
            this.cbCorrection.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cbCorrection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCorrection.FormattingEnabled = true;
            this.cbCorrection.Items.AddRange(new object[] {
            "None (1)",
            "Using Path Size"});
            this.cbCorrection.Location = new System.Drawing.Point(0, 8);
            this.cbCorrection.Name = "cbCorrection";
            this.cbCorrection.Size = new System.Drawing.Size(416, 23);
            this.cbCorrection.TabIndex = 1;
            this.cbCorrection.SelectedIndexChanged += new System.EventHandler(this.cbCorrection_SelectedIndexChanged);
            // 
            // splitTab2e
            // 
            this.splitTab2e.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab2e.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitTab2e.IsSplitterFixed = true;
            this.splitTab2e.Location = new System.Drawing.Point(0, 0);
            this.splitTab2e.Name = "splitTab2e";
            this.splitTab2e.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitTab2e.Panel2
            // 
            this.splitTab2e.Panel2.Controls.Add(this.picBox);
            this.splitTab2e.Panel2.Padding = new System.Windows.Forms.Padding(10, 10, 10, 0);
            this.splitTab2e.Size = new System.Drawing.Size(839, 505);
            this.splitTab2e.SplitterDistance = 139;
            this.splitTab2e.TabIndex = 0;
            this.splitTab2e.TabStop = false;
            // 
            // picBox
            // 
            this.picBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picBox.Location = new System.Drawing.Point(10, 10);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(819, 352);
            this.picBox.TabIndex = 0;
            this.picBox.TabStop = false;
            // 
            // splitTab2b
            // 
            this.splitTab2b.BackColor = System.Drawing.Color.Transparent;
            this.splitTab2b.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab2b.IsSplitterFixed = true;
            this.splitTab2b.Location = new System.Drawing.Point(0, 0);
            this.splitTab2b.Name = "splitTab2b";
            // 
            // splitTab2b.Panel1
            // 
            this.splitTab2b.Panel1.Controls.Add(this.btnBack2);
            // 
            // splitTab2b.Panel2
            // 
            this.splitTab2b.Panel2.Controls.Add(this.btnNext2);
            this.splitTab2b.Size = new System.Drawing.Size(839, 29);
            this.splitTab2b.SplitterDistance = 419;
            this.splitTab2b.TabIndex = 0;
            this.splitTab2b.TabStop = false;
            // 
            // btnBack2
            // 
            this.btnBack2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnBack2.Location = new System.Drawing.Point(0, -1);
            this.btnBack2.Name = "btnBack2";
            this.btnBack2.Size = new System.Drawing.Size(419, 30);
            this.btnBack2.TabIndex = 1;
            this.btnBack2.Text = "Back";
            this.btnBack2.UseVisualStyleBackColor = true;
            this.btnBack2.Click += new System.EventHandler(this.btnBack2_Click);
            // 
            // btnNext2
            // 
            this.btnNext2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnNext2.Location = new System.Drawing.Point(0, -1);
            this.btnNext2.Name = "btnNext2";
            this.btnNext2.Size = new System.Drawing.Size(416, 30);
            this.btnNext2.TabIndex = 0;
            this.btnNext2.Text = "Next";
            this.btnNext2.UseVisualStyleBackColor = true;
            this.btnNext2.Click += new System.EventHandler(this.btnNext2_Click);
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.splitTab1a);
            this.tab1.Location = new System.Drawing.Point(4, 29);
            this.tab1.Name = "tab1";
            this.tab1.Padding = new System.Windows.Forms.Padding(3);
            this.tab1.Size = new System.Drawing.Size(845, 574);
            this.tab1.TabIndex = 0;
            this.tab1.Text = "Apply To";
            this.tab1.UseVisualStyleBackColor = true;
            // 
            // splitTab1a
            // 
            this.splitTab1a.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab1a.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitTab1a.IsSplitterFixed = true;
            this.splitTab1a.Location = new System.Drawing.Point(3, 3);
            this.splitTab1a.Name = "splitTab1a";
            this.splitTab1a.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitTab1a.Panel2
            // 
            this.splitTab1a.Panel2.Controls.Add(this.splitTab1b);
            this.splitTab1a.Size = new System.Drawing.Size(839, 568);
            this.splitTab1a.SplitterDistance = 535;
            this.splitTab1a.TabIndex = 0;
            this.splitTab1a.TabStop = false;
            // 
            // splitTab1b
            // 
            this.splitTab1b.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitTab1b.IsSplitterFixed = true;
            this.splitTab1b.Location = new System.Drawing.Point(0, 0);
            this.splitTab1b.Name = "splitTab1b";
            // 
            // splitTab1b.Panel2
            // 
            this.splitTab1b.Panel2.Controls.Add(this.btnNext1);
            this.splitTab1b.Size = new System.Drawing.Size(839, 29);
            this.splitTab1b.SplitterDistance = 419;
            this.splitTab1b.TabIndex = 0;
            this.splitTab1b.TabStop = false;
            // 
            // btnNext1
            // 
            this.btnNext1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnNext1.Location = new System.Drawing.Point(0, -1);
            this.btnNext1.Name = "btnNext1";
            this.btnNext1.Size = new System.Drawing.Size(416, 30);
            this.btnNext1.TabIndex = 0;
            this.btnNext1.Text = "Next";
            this.btnNext1.UseVisualStyleBackColor = true;
            this.btnNext1.Click += new System.EventHandler(this.btnNext1_Click);
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tab1);
            this.tab.Controls.Add(this.tab2);
            this.tab.Controls.Add(this.tab3);
            this.tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab.ItemSize = new System.Drawing.Size(190, 25);
            this.tab.Location = new System.Drawing.Point(10, 10);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(853, 607);
            this.tab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tab.TabIndex = 0;
            this.tab.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tab_Selecting);
            // 
            // MdmNorWizard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 627);
            this.Controls.Add(this.tab);
            this.Font = new System.Drawing.Font("Segoe UI Symbol", 9F);
            this.Name = "MdmNorWizard";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "MDM - Normal Wizard";
            this.tab3.ResumeLayout(false);
            this.splitTab3a.Panel1.ResumeLayout(false);
            this.splitTab3a.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab3a)).EndInit();
            this.splitTab3a.ResumeLayout(false);
            this.splitPaths.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths)).EndInit();
            this.splitPaths.ResumeLayout(false);
            this.splitPaths2.Panel1.ResumeLayout(false);
            this.splitPaths2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2)).EndInit();
            this.splitPaths2.ResumeLayout(false);
            this.splitPaths2a.Panel1.ResumeLayout(false);
            this.splitPaths2a.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a)).EndInit();
            this.splitPaths2a.ResumeLayout(false);
            this.splitPaths2a1.Panel1.ResumeLayout(false);
            this.splitPaths2a1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a1)).EndInit();
            this.splitPaths2a1.ResumeLayout(false);
            this.splitPaths2a2.Panel1.ResumeLayout(false);
            this.splitPaths2a2.Panel2.ResumeLayout(false);
            this.splitPaths2a2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2a2)).EndInit();
            this.splitPaths2a2.ResumeLayout(false);
            this.splitPaths2b.Panel1.ResumeLayout(false);
            this.splitPaths2b.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b)).EndInit();
            this.splitPaths2b.ResumeLayout(false);
            this.splitPaths2b1.Panel1.ResumeLayout(false);
            this.splitPaths2b1.Panel2.ResumeLayout(false);
            this.splitPaths2b1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b1)).EndInit();
            this.splitPaths2b1.ResumeLayout(false);
            this.splitPaths2b2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPaths2b2)).EndInit();
            this.splitPaths2b2.ResumeLayout(false);
            this.splitTab3b.Panel1.ResumeLayout(false);
            this.splitTab3b.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab3b)).EndInit();
            this.splitTab3b.ResumeLayout(false);
            this.tab2.ResumeLayout(false);
            this.splitTab2a.Panel1.ResumeLayout(false);
            this.splitTab2a.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2a)).EndInit();
            this.splitTab2a.ResumeLayout(false);
            this.splitTab2c.Panel1.ResumeLayout(false);
            this.splitTab2c.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2c)).EndInit();
            this.splitTab2c.ResumeLayout(false);
            this.splitTab2d.Panel1.ResumeLayout(false);
            this.splitTab2d.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2d)).EndInit();
            this.splitTab2d.ResumeLayout(false);
            this.splitTab2e.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2e)).EndInit();
            this.splitTab2e.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.splitTab2b.Panel1.ResumeLayout(false);
            this.splitTab2b.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab2b)).EndInit();
            this.splitTab2b.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.splitTab1a.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab1a)).EndInit();
            this.splitTab1a.ResumeLayout(false);
            this.splitTab1b.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitTab1b)).EndInit();
            this.splitTab1b.ResumeLayout(false);
            this.tab.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tab3;
        private System.Windows.Forms.SplitContainer splitTab3a;
        private System.Windows.Forms.SplitContainer splitTab3b;
        private System.Windows.Forms.Button btnBack3;
        private System.Windows.Forms.Button btnNext3;
        private System.Windows.Forms.TabPage tab2;
        private System.Windows.Forms.SplitContainer splitTab2a;
        private System.Windows.Forms.SplitContainer splitTab2c;
        private System.Windows.Forms.SplitContainer splitTab2d;
        private System.Windows.Forms.ComboBox cbScaling;
        private System.Windows.Forms.ComboBox cbCorrection;
        private System.Windows.Forms.SplitContainer splitTab2e;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.SplitContainer splitTab2b;
        private System.Windows.Forms.Button btnBack2;
        private System.Windows.Forms.Button btnNext2;
        private System.Windows.Forms.TabPage tab1;
        private System.Windows.Forms.SplitContainer splitTab1a;
        private System.Windows.Forms.SplitContainer splitTab1b;
        private System.Windows.Forms.Button btnNext1;
        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.SplitContainer splitPaths;
        private System.Windows.Forms.SplitContainer splitPaths2;
        private System.Windows.Forms.SplitContainer splitPaths2a;
        private System.Windows.Forms.SplitContainer splitPaths2a1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox cbPaths_OdPairs;
        private System.Windows.Forms.SplitContainer splitPaths2a2;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox tbPaths_Nodes;
        private System.Windows.Forms.SplitContainer splitPaths2b;
        private System.Windows.Forms.SplitContainer splitPaths2b1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox tbPaths_Links;
        private System.Windows.Forms.SplitContainer splitPaths2b2;
        private System.Windows.Forms.Button btnPathsFilter;

    }
}