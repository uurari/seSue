﻿using DiscreteChoiceModel;
using SeSue.DGVs;
using SeSue.DGVs.Wizard;
using SeSue.Forms.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.Forms.Wizards
{
    public partial class WeibitWizard : Form
    {
        private bool canChangeTabPage;
        private ApplyToDgv applyToDgv;
        private List<int> selectedOdIndices;
        private WeibitParamsDgv weibitParamsDgv;
        private List<double> betas;
        private List<double> xis;
        private WeibullParamsDgv weibullParamsDgv;
        private WeibitCorrectionDgv correctionDgv;
        private List<double[]> corrTerms;

        #region CONSTRUCTOR
        public WeibitWizard(int w, int h)
        {
            InitializeComponent();
            this.Icon = Properties.Resources.logo;
            this.canChangeTabPage = false;
            if (Program.sueForm.WindowState != FormWindowState.Maximized) { this.Width = w; this.Height = h; }
            this.applyToDgv = new ApplyToDgv(this.splitTab1a.Panel1);
        } 
        #endregion

        #region APPLY TO
        private void btnNext1_Click(object sender, EventArgs e)
        {
            this.selectedOdIndices = this.applyToDgv.getSelectedOdIndices();
            if (selectedOdIndices.Count == 0) { Msg.show("Error.", "At least one OD pair should be selected.", this); return; }
            cbPaths_OdPairs.Items.Clear();
            foreach (int w in this.selectedOdIndices) { cbPaths_OdPairs.Items.Add(SueForm.sue.graph.getOdPair(w).getLabel()); }
            this.weibitParamsDgv = new WeibitParamsDgv(splitTab2e.Panel1);
            canChangeTabPage = true; this.tab.SelectedIndex = 1; canChangeTabPage = false;
            if (this.cbCorrection.SelectedIndex == -1) { this.cbCorrection.SelectedIndex = 0; }
        }
        #endregion

        #region SETTINGS
        private void cbScaling_SelectedIndexChanged(object sender, EventArgs e) { cbChanged(); }
        private void cbCorrection_SelectedIndexChanged(object sender, EventArgs e) { cbChanged(); }
        private void cbChanged()
        {
            int ind2 = cbCorrection.SelectedIndex;
            if (ind2 == 0) { this.picBox.Image = Properties.Resources.weibit_0_0; return; }
            if (ind2 == 1) { this.picBox.Image = Properties.Resources.weibit_0_1; return; }
        }
        private void btnBack2_Click(object sender, EventArgs e) { canChangeTabPage = true; this.tab.SelectedIndex = 0; canChangeTabPage = false; }
        private void btnNext2_Click(object sender, EventArgs e)
        {
            this.weibullParamsDgv = new WeibullParamsDgv(splitTab3a.Panel1, this.selectedOdIndices);
            canChangeTabPage = true; this.tab.SelectedIndex = 2; canChangeTabPage = false;
        }
        #endregion

        #region DISPERSION
        private void btnBack3_Click(object sender, EventArgs e) { this.weibullParamsDgv.dgv.remove(); canChangeTabPage = true; this.tab.SelectedIndex = 1; canChangeTabPage = false; }
        private void btnNext3_Click(object sender, EventArgs e)
        {
            cbPaths_OdPairs.Text = SueForm.sue.graph.getOdPair(selectedOdIndices[0]).getLabel();
            tbPaths_Nodes.Text = String.Empty; tbPaths_Links.Text = String.Empty;
            this.betas = this.weibullParamsDgv.getBetas();
            this.xis = this.weibullParamsDgv.getXis();
            this.correctionDgv = new WeibitCorrectionDgv(splitPaths.Panel2, this.selectedOdIndices, this.betas, xis, cbCorrection.SelectedIndex);
            canChangeTabPage = true; this.tab.SelectedIndex = 3; canChangeTabPage = false;
        }
        #endregion

        #region CORRECTION
        private void btnBack4_Click(object sender, EventArgs e) { this.correctionDgv.dgv.remove(); canChangeTabPage = true; this.tab.SelectedIndex = 2; canChangeTabPage = false; }
        private void btnNext4_Click(object sender, EventArgs e)
        {
            this.corrTerms = this.correctionDgv.getCorrectionTerms();
            finalize();
            this.Close();
        }
        #endregion

        #region FINALIZATION
        private void finalize()
        {
            for (int iw = 0; iw < selectedOdIndices.Count; iw++)
            {
                int w = selectedOdIndices[iw];
                double beta = betas[iw];
                double xi = xis[iw];
                double[] ct = this.corrTerms[iw];
                Weibit weibit = new Weibit(xi, beta, ct);
                OdPair od = SueForm.sue.graph.getOdPair(w);
                od.setChoiceModel(weibit);
                SueForm.odDt.Rows[w][4] = weibit.ToString();
            }
            SueForm.odDgv.dgv.setDataTable(SueForm.odDt);
            SueForm.pathDgv.newSue(Program.sueForm.cbPaths_OdPairs.Text, Program.sueForm.tbPaths_Nodes.Text, Program.sueForm.tbPaths_Links.Text);
            SueForm.pathDgv.dgv.setDataTable(SueForm.pathDt);
        } 
        #endregion

        #region OTHER
        private void tab_Selecting(object sender, TabControlCancelEventArgs e) { e.Cancel = !canChangeTabPage; }
        private void btnPathsFilter_Click(object sender, EventArgs e) { this.correctionDgv.filter(cbPaths_OdPairs.Text, tbPaths_Nodes.Text, tbPaths_Links.Text); } 
        #endregion


    }
}
