﻿using DiscreteChoiceModel;
using SeSue.DGVs;
using SeSue.DGVs.Wizard;
using SeSue.Forms.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.Forms.Wizards
{
    public partial class LogitWizard : Form
    {
        private bool canChangeTabPage;
        private ApplyToDgv applyToDgv;
        private List<int> selectedOdIndices;
        private LogitParamsDgv logitParamsDgv;
        private List<double> odThetas;
        private LogitDispersionDgv logitDispersionDgv;
        private LogitCorrectionDgv correctionDgv;
        private List<double[]> corrTerms;

        #region CONSTRUCTOR
        public LogitWizard(int w, int h)
        {
            InitializeComponent();
            if (Program.sueForm.WindowState != FormWindowState.Maximized) { this.Width = w; this.Height = h; }
            this.Icon = Properties.Resources.logo;
            this.canChangeTabPage = false;
            this.applyToDgv = new ApplyToDgv(this.splitTab1a.Panel1);
        } 
        #endregion

        #region APPLY TO
        private void btnNext1_Click(object sender, EventArgs e)
        {
            this.selectedOdIndices = this.applyToDgv.getSelectedOdIndices();
            if (selectedOdIndices.Count == 0) { Msg.show("Error.", "At least one OD pair should be selected.", this); return; }
            cbPaths_OdPairs.Items.Clear();
            foreach (int w in this.selectedOdIndices) { cbPaths_OdPairs.Items.Add(SueForm.sue.graph.getOdPair(w).getLabel()); }
            this.logitParamsDgv = new LogitParamsDgv(splitTab2e.Panel1);
            canChangeTabPage = true; this.tab.SelectedIndex = 1; canChangeTabPage = false;
            if (this.cbScaling.SelectedIndex == -1) { this.cbScaling.SelectedIndex = 0; }
            if (this.cbCorrection.SelectedIndex == -1) { this.cbCorrection.SelectedIndex = 0; }
        } 
        #endregion

        #region SETTINGS
        private void cbScaling_SelectedIndexChanged(object sender, EventArgs e) { cbChanged(); }
        private void cbCorrection_SelectedIndexChanged(object sender, EventArgs e) { cbChanged(); }
        private void cbChanged()
        {
            int ind1 = cbScaling.SelectedIndex;
            int ind2 = cbCorrection.SelectedIndex;
            if (ind1 == 0 && ind2 == 0) { this.picBox.Image = Properties.Resources.logit_0_0; return; }
            if (ind1 == 0 && ind2 == 1) { this.picBox.Image = Properties.Resources.logit_0_1; return; }
            if (ind1 == 0 && ind2 == 2) { this.picBox.Image = Properties.Resources.logit_0_2; return; }
            if (ind1 == 1 && ind2 == 0) { this.picBox.Image = Properties.Resources.logit_1_0; return; }
            if (ind1 == 1 && ind2 == 1) { this.picBox.Image = Properties.Resources.logit_1_1; return; }
            if (ind1 == 1 && ind2 == 2) { this.picBox.Image = Properties.Resources.logit_1_2; return; }
            if (ind1 == 2 && ind2 == 0) { this.picBox.Image = Properties.Resources.logit_2_0; return; }
            if (ind1 == 2 && ind2 == 1) { this.picBox.Image = Properties.Resources.logit_2_1; return; }
            if (ind1 == 2 && ind2 == 2) { this.picBox.Image = Properties.Resources.logit_2_2; return; }
        }
        private void btnBack2_Click(object sender, EventArgs e) { canChangeTabPage = true; this.tab.SelectedIndex = 0; canChangeTabPage = false; }
        private void btnNext2_Click(object sender, EventArgs e)
        {
            this.logitDispersionDgv = new LogitDispersionDgv(splitTab3a.Panel1, this.selectedOdIndices, cbScaling.SelectedIndex);
            canChangeTabPage = true; this.tab.SelectedIndex = 2; canChangeTabPage = false;
        } 
        #endregion

        #region DISPERSION
        private void btnBack3_Click(object sender, EventArgs e) { this.logitDispersionDgv.dgv.remove(); canChangeTabPage = true; this.tab.SelectedIndex = 1; canChangeTabPage = false; }
        private void btnNext3_Click(object sender, EventArgs e)
        {
            cbPaths_OdPairs.Text = SueForm.sue.graph.getOdPair(selectedOdIndices[0]).getLabel(); tbPaths_Nodes.Text = String.Empty; tbPaths_Links.Text = String.Empty;
            this.odThetas = this.logitDispersionDgv.getOdThetas();
            this.correctionDgv = new LogitCorrectionDgv(splitPaths.Panel2, this.selectedOdIndices, this.odThetas, cbCorrection.SelectedIndex);
            canChangeTabPage = true; this.tab.SelectedIndex = 3; canChangeTabPage = false;
        } 
        #endregion

        #region CORRECTION
        private void btnBack4_Click(object sender, EventArgs e) { this.correctionDgv.dgv.remove(); canChangeTabPage = true; this.tab.SelectedIndex = 2; canChangeTabPage = false; }
        private void btnNext4_Click(object sender, EventArgs e)
        {
            this.corrTerms = this.correctionDgv.getCorrectionTerms();
            finalize();
            this.Close();
        } 
        #endregion

        #region FINALIZATION
        private void finalize()
        {
            for (int iw = 0; iw < selectedOdIndices.Count; iw++)
            {
                int w = selectedOdIndices[iw];
                double odTheta = odThetas[iw];
                double[] ct = this.corrTerms[iw];
                Logit logit = new Logit(odTheta, ct);
                OdPair od = SueForm.sue.graph.getOdPair(w);
                od.setChoiceModel(logit);
                SueForm.odDt.Rows[w][4] = logit.ToString();
            }
            SueForm.odDgv.dgv.setDataTable(SueForm.odDt);
            SueForm.pathDgv.newSue(Program.sueForm.cbPaths_OdPairs.Text, Program.sueForm.tbPaths_Nodes.Text, Program.sueForm.tbPaths_Links.Text);
            SueForm.pathDgv.dgv.setDataTable(SueForm.pathDt);
        }
        #endregion

        #region OTHER
        private void tab_Selecting(object sender, TabControlCancelEventArgs e) { e.Cancel = !canChangeTabPage; }
        private void btnPathsFilter_Click(object sender, EventArgs e) { this.correctionDgv.filter(cbPaths_OdPairs.Text, tbPaths_Nodes.Text, tbPaths_Links.Text); }
        #endregion


    }
}
