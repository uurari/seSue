﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeSue.Forms.PathGeneration
{
    public partial class CbAndLabel : UserControl
    {
        private List<string> labelTexts;

        public CbAndLabel(string name, List<string> cbItems, int selectedIndex, List<string> labelTexts)
        {
            InitializeComponent();
            this.Name = name;
            this.Dock = DockStyle.Fill;
            this.labelTexts = labelTexts;
            this.comboBox.Items.Clear();
            foreach (string item in cbItems) { this.comboBox.Items.Add(item); }
            this.comboBox.SelectedIndex = selectedIndex;
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.label.Text = labelTexts[this.comboBox.SelectedIndex];
        }

        public int selectedIndex() { return this.comboBox.SelectedIndex; }


    }
}
