﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;
using SeSue.Forms.Common;

namespace SeSue.Forms.PathGeneration
{
    public partial class TbAndLabel : UserControl
    {
        public enum NumberCondition { None, Positive, Negative, Nonzero, Nonnegative, Nonpositive }

        private Type dataType;
        private NumberCondition numberCondition;


        public TbAndLabel(string name, string labelText, string textBoxText, HorizontalAlignment textAlign, Type dataType, NumberCondition numberCondition)
        {
            InitializeComponent();
            this.Name = name;
            this.label.Text = labelText;
            this.label.TextAlign = ContentAlignment.BottomCenter;
            if (textAlign == HorizontalAlignment.Left) { this.label.TextAlign = ContentAlignment.BottomLeft; }
            if (textAlign == HorizontalAlignment.Right) { this.label.TextAlign = ContentAlignment.BottomRight; }
            this.textBox.Text = textBoxText;
            this.dataType = dataType;
            this.numberCondition = numberCondition;
            this.textBox.TextAlign = textAlign;
            this.Dock = DockStyle.Fill;
            
        }

        private void textBox_Validating(object sender, CancelEventArgs e)
        {
            Control control = (Control)sender;
            Form parent = control.FindForm();
            string s = textBox.Text;
            if (dataType == typeof(string)) { return; }
            if (dataType == typeof(double))
            {
                if (!Str.isNumeric(s)) { e.Cancel = true; Msg.show("Validation error.", "The value should be numeric.", parent); return; }
                switch (numberCondition)
                {
                    case NumberCondition.None: return;
                    case NumberCondition.Positive: if (Str.toDouble(s) <= 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be positive.", parent); } return;
                    case NumberCondition.Negative: if (Str.toDouble(s) >= 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be negative.", parent); } return;
                    case NumberCondition.Nonzero: if (Str.toDouble(s) == 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonzero.", parent); } return;
                    case NumberCondition.Nonnegative: if (Str.toDouble(s) < 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonnegative.", parent); } return;
                    case NumberCondition.Nonpositive: if (Str.toDouble(s) > 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonpositive.", parent); } return;
                }
            }
            if (dataType == typeof(int))
            {
                if (!Str.isInteger(s)) { e.Cancel = true; Msg.show("Validation error.", "The value should be integer.", parent); return; }
                switch (numberCondition)
                {
                    case NumberCondition.None: return;
                    case NumberCondition.Positive: if (Str.toDouble(s) <= 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be positive.", parent); } return;
                    case NumberCondition.Negative: if (Str.toDouble(s) >= 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be negative.", parent); } return;
                    case NumberCondition.Nonzero: if (Str.toDouble(s) == 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonzero.", parent); } return;
                    case NumberCondition.Nonnegative: if (Str.toDouble(s) < 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonnegative.", parent); } return;
                    case NumberCondition.Nonpositive: if (Str.toDouble(s) > 0) { e.Cancel = true; Msg.show("Validation error.", "The value should be nonpositive.", parent); } return;
                }
            }
        }

        #region PUBLIC
        public string getText() { return this.textBox.Text; }
        public void setType(Type dataType) { this.dataType = dataType; } 
        #endregion

    }
}
