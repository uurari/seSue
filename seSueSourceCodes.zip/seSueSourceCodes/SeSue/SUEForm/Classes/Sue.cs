﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;
using U.SUE;
using U.SUE.Algorithms;

namespace SeSue.Classes
{
    public class Sue
    {
        public Graph graph;
        public MSA msa;


        public Sue(Graph graph, MSA msa)
        {
            this.graph = graph;
            this.msa = msa;
        }


        public Sue(string strSue)
        {
            List<string> lst = Str.split(strSue, Str.Delimiter.Colon);
            this.graph = new Graph(lst);
            this.msa = new MSA(lst[4]);
        }

        public override string ToString()
        {
            return this.graph.toString() + ":" + Environment.NewLine + this.msa.toString();
        }
    }
}
