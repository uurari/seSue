﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.DGVs
{
    public class NodesDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;
        

        public NodesDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("i", true, true, 0.20, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.20, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("# Arcs", true, true, 0.20, typeof(int), "#,###,##0", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("# Leaving Arcs", true, true, 0.20, typeof(int), "#,###,##0", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("# Incoming Arcs", true, true, 0.20, typeof(int), "#,###,##0", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
        }


        public void newSue()
        {
            DataTable dt = this.dgv.getEmptyDatatable();
            if (SueForm.sue.graph != null)
            {
                for (int i = 0; i < SueForm.sue.graph.getNodes().Length; i++)
                {
                    Node node = SueForm.sue.graph.getNode(i);
                    DataRow dr = dt.NewRow();
                    dr[0] = i.ToString();
                    dr[1] = node.getLabel();
                    dr[2] = (node.getInArcIndices().Length + node.getOutArcIndices().Length).ToString();
                    dr[3] = node.getOutArcIndices().Length.ToString();
                    dr[4] = node.getInArcIndices().Length.ToString();
                    dt.Rows.Add(dr);
                }
            }
            SueForm.nodesDt = dt;
        }

    }
}
