﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;
using U.SUE;

namespace SeSue.DGVs.Wizard
{
    class LogitDispersionDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;

        public LogitDispersionDgv(Control container, List<int> selectedOdIndices, int scalingIndex)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                //new DgvColumn("i", false, true, 0.00, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.labelColor, SueForm.regularFontColor),
                new DgvColumn("w", true, true, 0.10, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.10, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Nb of Paths", true, true, 0.30, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("SP FFTT", true, true, 0.30, typeof(double), String.Empty, true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("theta", true, false, 0.30, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
            };
            this.dgv = new Dgv(container, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
            initialize(selectedOdIndices, scalingIndex);
            this.dgv.getDataGridView().CellValidating += new DataGridViewCellValidatingEventHandler(validating);
            this.dgv.getDataGridView().CellValueChanged += new DataGridViewCellEventHandler(valueChanged);
        }
        private void initialize(List<int> selectedOdIndices, int scalingIndex)
        {
            dgv.clearRows();
            for (int i = 0; i < selectedOdIndices.Count; i++)
            {
                int w = selectedOdIndices[i];
                OdPair od = SueForm.sue.graph.getOdPair(w);
                double spfftt = od.calcSpFFTT(SueForm.sue.graph);
                double odTheta = calcTheta(scalingIndex, SueForm.theta, spfftt, SueForm.eta, SueForm.nu);
                List<string> vals = new List<string>()
                {
                    //i.ToString(),
                    w.ToString(),
                    od.getLabel(),
                    od.getPathIndices().Length.ToString(),
                    spfftt.ToString(),
                    odTheta.ToString()
                };
                dgv.addRow(vals);
            }
        }
        private double calcTheta(int scalingIndex, double theta, double spFFTT, double eta, double nu)
        {
            if (scalingIndex == 0) { return theta; }
            if (scalingIndex == 1) { return theta * Math.PI / Math.Sqrt(6 * eta * spFFTT); }
            if (scalingIndex == 2) { return Math.PI / Math.Sqrt(6) / nu / spFFTT; }
            return -1;
        }

        // VALIDATING
        private void validating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c != 4) { return; }
            string header = "Dispersion parameter (theta)";
            if (!Str.isNumeric(e.FormattedValue.ToString())) { MessageBox.Show(header + " should be numeric.", "Validation Error!"); e.Cancel = true; return; }
            double val = Str.toDouble(e.FormattedValue.ToString());
            if (val <= 0) { MessageBox.Show(header + " should be positive.", "Validation Error!"); e.Cancel = true; return; }
        }
        private void valueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c != 4) { return; }
            int i = dgv.getCellValueInt(r, 0);
            string val = dgv.getCellValue(r, 5);
            dgv.setDtValue(i, 5, val);
        }
        

        public List<double> getOdThetas()
        {
            List<double> odThetas = new List<double>();
            for (int i = 0; i < dgv.getDataTable().Rows.Count; i++) { odThetas.Add(dgv.getDtValueDbl(i, 4)); }
            return odThetas;
        }
    }
}
