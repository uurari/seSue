﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.DGVs.Wizard
{
    class ApplyToDgv
    {
        private List<DgvColumn> dgvCols;
        private Dgv dgv;
        private bool selectAll;

        public ApplyToDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("w", true, true, 0.10, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.10, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Current Choice Model", true, true, 0.70, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Apply", true, false, 0.10, typeof(bool), String.Empty, true, DataGridViewContentAlignment.MiddleCenter, SueForm.editableColor, SueForm.regularFontColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
            this.dgv.getDataGridView().DoubleClick += new EventHandler(onDoubleClick);
            this.selectAll = true;
            initialize();
        }


        private void initialize()
        {
            this.dgv.clearRows();
            for (int w = 0; w < SueForm.sue.graph.getOdPairs().Length; w++)
            {
                OdPair od = SueForm.sue.graph.getOdPair(w);
                if (od.getPathIndices().Length > 0)
                {
                    bool noCm = (od.getChoiceModel() == null);
                    List<string> vals = new List<string>()
                    {
                        w.ToString(),
                        od.getLabel(),
                        "null",
                        noCm.ToString()
                    };
                    if (!noCm) { vals[2] = od.getChoiceModel().ToString(); }
                    dgv.addRow(vals);
                }
            }
        }

        public List<int> getSelectedOdIndices()
        {
            List<int> lst = new List<int>();
            for (int i = 0; i < dgv.getDataGridView().Rows.Count; i++)
            {
                bool selected = dgv.getCellValueBool(i, 3);
                if (selected) { lst.Add(dgv.getCellValueInt(i, 0)); }
            }
            return lst;
        }

        private void onDoubleClick(object sender, EventArgs e)
        {
            for (int i = 0; i < this.dgv.getDataGridView().Rows.Count; i++) { dgv.getDataGridView().Rows[i].Cells[3].Value = this.selectAll; }
            this.selectAll = !this.selectAll;
        }


    }
}
