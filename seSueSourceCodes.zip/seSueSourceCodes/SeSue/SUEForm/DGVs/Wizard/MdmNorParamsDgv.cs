﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;

namespace SeSue.DGVs.Wizard
{
    class MdmNorParamsDgv
    {
        private List<DgvColumn> dgvCols;
        private Dgv dgv;

        public MdmNorParamsDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("Parameter", true, true, 0.70, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Value", true, false, 0.30, typeof(double), String.Empty, true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.None, DockStyle.Fill);
            container.Controls.Add(dgv);
            initialize();
            this.dgv.getDataGridView().CellValidating += new DataGridViewCellValidatingEventHandler(validating);
            this.dgv.getDataGridView().CellValueChanged += new DataGridViewCellEventHandler(valueChanged);
        }

        private void initialize()
        {
            dgv.clearRows();
            List<List<string>> rows = new List<List<string>>()
            {
                new List<string>() { "Dispersion (theta)", SueForm.theta.ToString() },
                new List<string>() { "Proportionality Constant (eta)", SueForm.eta.ToString() },
                new List<string>() { "Coefficient of Variation (nu)", SueForm.nu.ToString() },
                new List<string>() { "MDM precision parameter (varepsilon)", SueForm.varEpsilon.ToString() },
            };
            dgv.addRows(rows);
        }

        // VALIDATING
        private void validating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c != 1) { return; }
            string header = this.dgv.getCellValue(r, 0);
            if (!Str.isNumeric(e.FormattedValue.ToString())) { MessageBox.Show(header + " should be numeric.", "Validation Error!"); e.Cancel = true; return; }
            double val = Str.toDouble(e.FormattedValue.ToString());
            if (val <= 0) { MessageBox.Show(header + " should be positive.", "Validation Error!"); e.Cancel = true; return; }
        }
        private void valueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int r = e.RowIndex;
            double val = dgv.getCellValueDbl(r, 1);
            if (r == 0) { SueForm.theta = val; return; }
            if (r == 1) { SueForm.eta = val; return; }
            if (r == 2) { SueForm.nu = val; return; }
            if (r == 3) { SueForm.varEpsilon = val; return; }
        }
    }
}
