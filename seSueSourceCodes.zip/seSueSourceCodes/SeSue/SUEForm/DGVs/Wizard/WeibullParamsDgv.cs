﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;
using U.SUE;

namespace SeSue.DGVs.Wizard
{
    class WeibullParamsDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;

        public WeibullParamsDgv(Control container, List<int> selectedOdIndices)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                //new DgvColumn("i", false, true, 0.00, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.labelColor, SueForm.regularFontColor),
                new DgvColumn("w", true, true, 0.10, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.10, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Nb of Paths", true, true, 0.30, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("beta", true, false, 0.30, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("xi", true, false, 0.30, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
            };
            this.dgv = new Dgv(container, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
            initialize(selectedOdIndices);
            this.dgv.getDataGridView().CellValidating += new DataGridViewCellValidatingEventHandler(validating);
            this.dgv.getDataGridView().CellValueChanged += new DataGridViewCellEventHandler(valueChanged);
        }

        private void initialize(List<int> selectedOdIndices)
        {
            dgv.clearRows();
            for (int i = 0; i < selectedOdIndices.Count; i++)
            {
                int w = selectedOdIndices[i];
                OdPair od = SueForm.sue.graph.getOdPair(w);
                List<string> vals = new List<string>()
                {
                    //i.ToString(),
                    w.ToString(),
                    od.getLabel(),
                    od.getPathIndices().Length.ToString(),
                    SueForm.beta.ToString(),
                    SueForm.xi.ToString()
                };
                dgv.addRow(vals);
            }
        }
        // VALIDATING
        private void validating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c != 3 || c != 4) { return; }
            string header = "Weibull shape parameter (beta)";
            if (c == 4) { header = "Weibull location parameter (xi)"; }
            if (!Str.isNumeric(e.FormattedValue.ToString())) { MessageBox.Show(header + " should be numeric.", "Validation Error!"); e.Cancel = true; return; }
            double val = Str.toDouble(e.FormattedValue.ToString());
            if (c == 3 && val <= 0) { MessageBox.Show(header + " should be positive.", "Validation Error!"); e.Cancel = true; return; }
            if (c == 4 && val < 0) { MessageBox.Show(header + " should be nonnegative.", "Validation Error!"); e.Cancel = true; return; }
        }
        private void valueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c != 3 || c != 4) { return; }
            int i = dgv.getCellValueInt(r, 0);
            string val = dgv.getCellValue(r, c);
            dgv.setDtValue(i, c, val);
        }



        public List<double> getBetas()
        {
            List<double> lst = new List<double>();
            DataTable dt = dgv.getDataTable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double val = Convert.ToDouble(dt.Rows[i][3].ToString());
                lst.Add(val);
            }
            return lst;
        }
        public List<double> getXis()
        {
            List<double> lst = new List<double>();
            DataTable dt = dgv.getDataTable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double val = Convert.ToDouble(dt.Rows[i][4].ToString());
                lst.Add(val);
            }
            return lst;
        }
    }
}
