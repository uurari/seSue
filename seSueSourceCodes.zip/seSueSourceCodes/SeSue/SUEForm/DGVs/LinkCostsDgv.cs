﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.ListOperations;
using U.StringOperations;
using U.SUE;

namespace SeSue.DGVs
{
    public class LinkCostsDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;
        
        public LinkCostsDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("a", true, true, 0.04, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.06, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("FFTT", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("B", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Capacity", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Power", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Toll", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Toll Factor", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Length", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Distance Factor", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Exp. Coefficient", true, false, 0.075, typeof(double), "#,###,##0.0000", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("Flow", true, false, 0.075, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.regularFontColor),
                new DgvColumn("BPR (Add)", true, true, 0.075, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("BPR (Mul)", true, true, 0.075, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
            this.dgv.getDataGridView().CellValidating += new DataGridViewCellValidatingEventHandler(validating);
            this.dgv.getDataGridView().CellValueChanged += new DataGridViewCellEventHandler(valueChanged);
        }

        public void newSue()
        {
            DataTable dt = this.dgv.getEmptyDatatable();
            if (SueForm.sue.graph != null)
            {
                for (int a = 0; a < SueForm.sue.graph.getLinks().Length; a++)
                {
                    Link link = SueForm.sue.graph.getLink(a);
                    DataRow dr = dt.NewRow();
                    dr[0] = a.ToString();
                    dr[1] = link.getLabel();
                    dr[2] = link.getLinkCost().getFreeFlowTravelTime().ToString();
                    dr[3] = link.getLinkCost().getB().ToString();
                    dr[4] = link.getLinkCost().getCapacity().ToString();
                    dr[5] = link.getLinkCost().getPower().ToString();
                    dr[6] = link.getLinkCost().getToll().ToString();
                    dr[7] = link.getLinkCost().getTollFactor().ToString();
                    dr[8] = link.getLinkCost().getLength().ToString();
                    dr[9] = link.getLinkCost().getDistanceFactor().ToString();
                    dr[10] = link.getLinkCost().getExponentialCoefficient().ToString();
                    dr[11] = link.getFlow().ToString();
                    dr[12] = link.getLinkCost().getBPRCost(link.getFlow()).ToString();
                    dr[13] = link.getLinkCost().getBPRCostExponential(link.getFlow()).ToString();
                    dt.Rows.Add(dr);
                }
            }
            SueForm.linkCostsDt = dt;
        }


        // VALIDATING
        private void validating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c <= 1 || c >= 12) { return; }
            string header = this.dgv.getDataGridView().Columns[c].HeaderText;
            if (!Str.isNumeric(e.FormattedValue.ToString())) { MessageBox.Show(header + " should be numeric.", "Validation Error!"); e.Cancel = true; return; }
            else
            {
                double val = Convert.ToDouble(e.FormattedValue);
                List<int> pos = new List<int>() { 4 };
                List<int> nonneg = new List<int>() { 2, 3, 5, 6, 7, 8, 9, 10, 11 };
                if (pos.IndexOf(c) != -1) { if (val <= 0) { MessageBox.Show(header + " should be positive.", "Validation Error!"); e.Cancel = true; return; } }
                else if (nonneg.IndexOf(c) != -1) { if (val < 0) { MessageBox.Show(header + " should be nonnegative.", "Validation Error!"); e.Cancel = true; return; } }
            }
        }
        private void valueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int a = dgv.getCellValueInt(e.RowIndex, 0);
            double fftt = dgv.getCellValueDbl(e.RowIndex, 2);
            double b = dgv.getCellValueDbl(e.RowIndex, 3);
            double cap = dgv.getCellValueDbl(e.RowIndex, 4);
            double pow = dgv.getCellValueDbl(e.RowIndex, 5);
            double toll = dgv.getCellValueDbl(e.RowIndex, 6);
            double tollFac = dgv.getCellValueDbl(e.RowIndex, 7);
            double len = dgv.getCellValueDbl(e.RowIndex, 8);
            double disFac = dgv.getCellValueDbl(e.RowIndex, 9);
            double expCoef = dgv.getCellValueDbl(e.RowIndex, 10);
            double flow = dgv.getCellValueDbl(e.RowIndex, 11);
            dgv.setCellValue(e.RowIndex, 12, LinkCost.calcBprCost(fftt, b, cap, pow, toll, tollFac, len, disFac, flow));
            dgv.setCellValue(e.RowIndex, 13, LinkCost.calcBprCostExponential(fftt, b, cap, pow, toll, tollFac, len, disFac, expCoef, flow));
            Link link = SueForm.sue.graph.getLink(a);
            LinkCost linkCost = new LinkCost(fftt, b, cap, pow, toll, tollFac, len, disFac, expCoef);
            link.setLinkCost(linkCost);
            SueForm.linkSueDgv.dgv.setDtValue(a, 2, fftt.ToString());
        }
        
    }
}
