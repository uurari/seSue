﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.StringOperations;
using U.SUE;
using U.SUE.Algorithms;

namespace SeSue.DGVs
{
    public class MsaDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;

        public MsaDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("Iteration", true, true, 0.10, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("RMSE", true, true, 0.10, typeof(double), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Link Flow Array", true, true, 0.80, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
        }



        public void afterRun()
        {
            DataTable dt = this.dgv.getEmptyDatatable();
            if (SueForm.sue.graph != null)
            {
                for (int a = 0; a < SueForm.sue.graph.getLinks().Length; a++)
                {
                    Link link = SueForm.sue.graph.getLink(a);
                    SueForm.linkSueDgv.dgv.setDtValue(a, 3, link.getCostAdd().ToString());
                    SueForm.linkSueDgv.dgv.setDtValue(a, 4, link.getCostMul().ToString());
                    SueForm.linkSueDgv.dgv.setDtValue(a, 5, link.getFlow().ToString());
                }
                List<double[]> flowMatrix = SueForm.sue.msa.getLinkFlows();
                List<double> rmseArr = SueForm.sue.msa.getRmse();
                for (int i = 0; i < flowMatrix.Count; i++)
                {
                    DataRow dr = dt.NewRow();
                    dr[0] = i.ToString();
                    dr[1] = rmseArr[i].ToString();
                    dr[2] = Str.combine(Str.toString(flowMatrix[i], "0.00"), Str.Delimiter.Comma);
                    dt.Rows.Add(dr);
                }
            }
            SueForm.msaDt = dt;
        }
    }
}
