﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.DGVs
{
    public class LinkSueDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;
        

        public LinkSueDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("a", true, true, 0.08, typeof(int), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Label", true, true, 0.20, typeof(string), String.Empty, true, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("FFTT", true, true, 0.18, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("SUE Cost (Add)", true, true, 0.18, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("SUE Cost (Mul)", true, true, 0.18, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("SUE Flow", true, true, 0.18, typeof(double), "#,###,##0.00", true, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.Vertical, DockStyle.Fill);
            container.Controls.Add(dgv);
        }

        public void newSue()
        {
            DataTable dt = this.dgv.getEmptyDatatable();
            if (SueForm.sue.graph != null)
            {
                for (int a = 0; a < SueForm.sue.graph.getLinks().Length; a++)
                {
                    Link link = SueForm.sue.graph.getLink(a);
                    DataRow dr = dt.NewRow();
                    dr[0] = a.ToString();
                    dr[1] = link.getLabel();
                    dr[2] = link.getLinkCost().getFreeFlowTravelTime().ToString();
                    dr[3] = link.getCostAdd().ToString();
                    dr[4] = link.getCostMul().ToString();
                    dr[5] = link.getFlow().ToString();
                    dt.Rows.Add(dr);
                }
            }
            SueForm.linkSueDt = dt;
        }

    }
}
