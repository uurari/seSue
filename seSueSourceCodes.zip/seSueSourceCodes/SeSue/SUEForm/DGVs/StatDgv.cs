﻿using SeSue.FormClasses.Dgv;
using SeSue.Forms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.SUE;

namespace SeSue.DGVs
{
    public class StatDgv
    {
        private List<DgvColumn> dgvCols;
        public Dgv dgv;

        public StatDgv(Control container)
        {
            this.dgvCols = new List<DgvColumn>()
            {
                new DgvColumn("Statistics", true, true, 0.7, typeof(string), String.Empty, false, DataGridViewContentAlignment.MiddleLeft, SueForm.editableColor, SueForm.labelColor),
                new DgvColumn("Value", true, true, 0.3, typeof(double), String.Empty, false, DataGridViewContentAlignment.MiddleRight, SueForm.editableColor, SueForm.labelColor),
            };
            this.dgv = new Dgv(null, dgvCols, SueForm.editableColor, SueForm.gridColor, true, false, SueForm.rowHeight, SueForm.headerVertPadding, false, false, false, true, false, true, DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText, DataGridViewSelectionMode.CellSelect, ScrollBars.None, DockStyle.Fill);
            container.Controls.Add(dgv);
        }


        public void newSue()
        {
            DataTable dt = this.dgv.getEmptyDatatable();
            if (SueForm.sue.graph != null)
            {
                int nbNodes = SueForm.sue.graph.getNodes().Length;
                int nbLinks = SueForm.sue.graph.getLinks().Length;
                int nbPaths = SueForm.sue.graph.getPaths().Length;
                int nbOds = SueForm.sue.graph.getOdPairs().Length;
                double avgNbPathsPerOd = Convert.ToDouble(nbPaths) / Convert.ToDouble(nbOds);
                int minNbPathsPerOd = int.MaxValue;
                int maxNbPathsPerOd = int.MinValue;
                foreach (OdPair od in SueForm.sue.graph.getOdPairs())
                {
                    minNbPathsPerOd = Math.Min(minNbPathsPerOd, od.getPathIndices().Length);
                    maxNbPathsPerOd = Math.Max(maxNbPathsPerOd, od.getPathIndices().Length);
                }
                DataRow dr0 = dt.NewRow();
                dr0[0] = "Number of nodes"; dr0[1] = nbNodes.ToString("#,###,###,###,##0"); dt.Rows.Add(dr0);
                DataRow dr1 = dt.NewRow();
                dr1[0] = "Number of links"; dr1[1] = nbLinks.ToString("#,###,###,###,##0"); dt.Rows.Add(dr1);
                DataRow dr2 = dt.NewRow();
                dr2[0] = "Number of paths"; dr2[1] = nbPaths.ToString("#,###,###,###,##0"); dt.Rows.Add(dr2);
                DataRow dr3 = dt.NewRow();
                dr3[0] = "Number of OD pairs"; dr3[1] = nbOds.ToString("#,###,###,###,##0"); dt.Rows.Add(dr3);
                DataRow dr4 = dt.NewRow();
                dr4[0] = "Average number of paths per OD pair"; dr4[1] = avgNbPathsPerOd.ToString("#,###,###,###,##0.00"); dt.Rows.Add(dr4);
                DataRow dr5 = dt.NewRow();
                dr5[0] = "Minimum number of paths per OD pair"; dr5[1] = minNbPathsPerOd.ToString("#,###,###,###,##0"); dt.Rows.Add(dr5);
                DataRow dr6 = dt.NewRow();
                dr6[0] = "Maximum number of paths per OD pair"; dr6[1] = maxNbPathsPerOd.ToString("#,###,###,###,##0"); dt.Rows.Add(dr6);
            }
            SueForm.statDt = dt;
        }

    }
}
