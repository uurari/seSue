﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public abstract class Algorithm
    {
        private Timer timer;

        public void startTimer() { timer = new Timer(); timer.start(); }
        public void stopTimer() { timer.stop(); }
        public double getSeconds() { return timer.getSeconds(); }
        public double getMiliseconds() { return timer.getMiliseconds(); }


    }
}
