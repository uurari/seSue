﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms
{
    public class Timer
    {
        private Stopwatch stopWatch;
        private double ElapsedMilliseconds;


        public Timer() { this.start(); }

        public void start() { stopWatch = new Stopwatch(); stopWatch.Start(); }
        public void stop() { stopWatch.Stop(); this.ElapsedMilliseconds = stopWatch.ElapsedMilliseconds; }
        public double getSeconds() { return this.stopWatch.Elapsed.Seconds; }
        public double getMiliseconds() { return this.ElapsedMilliseconds; }
    }
}
