﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;

namespace Algorithms.Nw.PathGeneration
{
    public class Yens : PathGenerationAlgorithm
    {
        private ShortestPathAlgorithm spa;
        public Yens(ShortestPathAlgorithm shortestPathAlgorithm) { this.spa = shortestPathAlgorithm; }


        public override void run(U.Graph.Graph graph, int oriIndex, int desIndex, int nbExistingPaths, int maxNbPaths, bool keepTime)
        {
            if (keepTime) { startTimer(); }
            base.lstNodeIndices = new List<List<int>>();
            if (nbExistingPaths >= maxNbPaths) { return; }

            KShortestPath.Yens yens = new KShortestPath.Yens();
            yens.run(graph, spa, oriIndex, desIndex, maxNbPaths, false);

            List<List<int>> ksp = yens.getKShortestPathsAsNodeIndices();
            int pathCount = 0;

            for (int i = 0; i < ksp.Count; i++)
            {
                List<int> sp = ksp[i];
                string str = Str.combine(sp, Str.Delimiter.Dash);
                if (!existingPathLabels.Contains(str))
                {
                    base.lstNodeIndices.Add(sp);
                    addToExisting(str);
                    pathCount += 1;
                    if (pathCount == maxNbPaths) { i = ksp.Count + 1; }
                }
            }
            if (keepTime) { stopTimer(); }
        }
    }
}
