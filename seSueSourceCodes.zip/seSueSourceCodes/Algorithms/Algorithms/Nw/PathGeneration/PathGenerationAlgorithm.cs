﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.Graph;
using U.StringOperations;

namespace Algorithms.Nw.PathGeneration
{
    public abstract class PathGenerationAlgorithm : Algorithm
    {
        internal List<List<int>> lstNodeIndices;
        internal List<string> existingPathLabels;

        
        public abstract void run(Graph graph, int oriIndex, int desIndex, int nbExistingPaths, int maxNbPaths, bool keepTime);



        #region PUBLIC
        public List<List<int>> getPathsAsNodeIndicesList() { return this.lstNodeIndices; }
        public void setExistingPathLabels(List<string> existingPathLabels) { this.existingPathLabels = existingPathLabels; }
        public void initializeExistingPathLabels(Graph graph)
        {
            existingPathLabels = new List<string>();
            foreach (Path path in graph.getPaths()) { existingPathLabels.Add(getPathIndicesLabel(graph, path)); }
        }
        private static string getPathIndicesLabel(Graph graph, Path path) { return Str.combine(path.getNodeIndices(graph), Str.Delimiter.Dash); }
        #endregion

        #region INTERNAL
        internal void addToExisting(string pathLabel) { existingPathLabels.Add(pathLabel); } 
        #endregion

    }
}
