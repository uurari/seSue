﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.Graph;

namespace Algorithms.Nw.KShortestPath
{
    public abstract class KShortestPathAlgorithm : Algorithm
    {
        internal List<PathAndCost> P;

        // ABSTRACT
        public abstract void run(Graph graph, ShortestPathAlgorithm shortestPathAlgorithm, int s, int t, int K, bool keepTime);


        // GETTERS
        public List<List<int>> getKShortestPathsAsNodeIndices()
        {
            List<List<int>> lst = new List<List<int>>();
            foreach (PathAndCost path in P) { lst.Add(path.nodeIndices); }
            return lst;
        }


    }
}
