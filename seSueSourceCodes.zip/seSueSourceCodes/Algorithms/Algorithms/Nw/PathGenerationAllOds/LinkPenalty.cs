﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;
using U.SUE;

namespace Algorithms.Nw.PathGenerationAllOds
{
    public class LinkPenalty : PathGenerationAllOdsAlgorithm
    {
        private ShortestPathAlgorithm spa;
        private double penalty; // if 0.05 means that fftt of 100 will be 105
        private long iterLim;
        private double[] originalCosts;


        public LinkPenalty(ShortestPathAlgorithm shortestPathAlgorithm, double penalty, long iterationLimit)
        {
            this.spa = shortestPathAlgorithm;
            this.penalty = penalty;
            this.iterLim = iterationLimit;
        }


        public override void run(Graph graph, int maxNbPaths, bool keepTime)
        {
            if (keepTime) { base.startTimer(); }

            base.odLstNodeIndices = new List<List<List<int>>>();
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                base.odLstNodeIndices.Add(new List<List<int>>());
                OdPair od = graph.getOdPair(w);
                int nbExistingPaths = od.getPathIndices().Length;
                if (maxNbPaths > nbExistingPaths)
                {
                    PathGeneration.LinkPenalty alg = new PathGeneration.LinkPenalty(spa, penalty, iterLim);
                    alg.setExistingPathLabels(base.getExistingPathLabelsForOd(graph, w));
                    alg.run(graph, od.getOriIndex(), od.getDesIndex(), nbExistingPaths, maxNbPaths, false);
                    base.odLstNodeIndices[w] = alg.getPathsAsNodeIndicesList();
                }
            }
            if (keepTime) { base.stopTimer(); }
        }

    }
}
