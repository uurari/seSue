﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;
using U.SUE;

namespace Algorithms.Nw.PathGenerationAllOds
{
    public class Yens : PathGenerationAllOdsAlgorithm
    {
        private ShortestPathAlgorithm spa;
        public Yens(ShortestPathAlgorithm shortestPathAlgorithm) { this.spa = shortestPathAlgorithm; }


        public override void run(Graph graph, int maxNbPaths, bool keepTime)
        {
            if (keepTime) { base.startTimer(); }

            base.odLstNodeIndices = new List<List<List<int>>>();
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                base.odLstNodeIndices.Add(new List<List<int>>());
                OdPair od = graph.getOdPair(w);
                int nbExistingPaths = od.getPathIndices().Length;
                if (maxNbPaths > nbExistingPaths)
                {
                    PathGeneration.Yens alg = new PathGeneration.Yens(spa);
                    alg.setExistingPathLabels(base.getExistingPathLabelsForOd(graph, w));
                    alg.run(graph, od.getOriIndex(), od.getDesIndex(), nbExistingPaths, maxNbPaths, false);
                    base.odLstNodeIndices[w] = alg.getPathsAsNodeIndicesList();
                }
            }
            if (keepTime) { base.stopTimer(); }
        }
    }
}
