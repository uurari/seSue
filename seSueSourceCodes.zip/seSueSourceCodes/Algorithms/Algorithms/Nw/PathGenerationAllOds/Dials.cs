﻿using Algorithms.Nw.ShortestPathAllPairs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;
using U.StringOperations;
using U.SUE;

namespace Algorithms.Nw.PathGenerationAllOds
{
    public class Dials : PathGenerationAllOdsAlgorithm
    {
        public enum Criteria { NoCriteria, SingleCriterion, DoubleCriteria };

        private Criteria criteria;
        private ShortestPathAllPairsAlgorithm asp;
        private int maxNbArcs;

        public Dials(Criteria condition, ShortestPathAllPairsAlgorithm shortestPathAllPairsAlgorithm, int maxNbArcsForUnconditioned)
        {
            this.criteria = condition;
            this.asp = shortestPathAllPairsAlgorithm;
            this.maxNbArcs = maxNbArcsForUnconditioned;
        }


        public override void run(Graph graph, int maxNbPaths, bool keepTime)
        {
            if (keepTime) { base.startTimer(); }
            PathGeneration.Dials.Criteria cr = PathGeneration.Dials.Criteria.NoCriteria; if (criteria == Criteria.SingleCriterion) { cr = PathGeneration.Dials.Criteria.DoubleCriteria; } if (criteria == Criteria.DoubleCriteria) { cr = PathGeneration.Dials.Criteria.SingleCriterion; }

            base.odLstNodeIndices = new List<List<List<int>>>();
            asp.run(graph, false);
            double[,] D = asp.getDistanceMatrix();
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                base.odLstNodeIndices.Add(new List<List<int>>());
                OdPair od = graph.getOdPair(w);
                int nbExistingPaths = od.getPathIndices().Length;
                if (maxNbPaths > nbExistingPaths)
                {
                    PathGeneration.Dials alg = new PathGeneration.Dials(cr, D, maxNbArcs);
                    alg.setExistingPathLabels(base.getExistingPathLabelsForOd(graph, w));
                    alg.run(graph, od.getOriIndex(), od.getDesIndex(), nbExistingPaths, maxNbPaths, false);
                    base.odLstNodeIndices[w] = alg.getPathsAsNodeIndicesList();
                }
            }
            if (keepTime) { base.stopTimer(); }
        }

    }
}
