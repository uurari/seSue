﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;
using U.SUE;

namespace Algorithms.Nw.PathGenerationAllOds
{
    public abstract class PathGenerationAllOdsAlgorithm : Algorithm
    {
        internal List<List<List<int>>> odLstNodeIndices;

        // to delete
        internal List<string> existingPathLabels;


        public abstract void run(Graph graph, int maxNbPaths, bool keepTime);





        #region INTERNAL
        internal List<string> getExistingPathLabelsForOd(Graph graph, int w)
        {
            List<string> lst = new List<string>();
            OdPair od = graph.getOdPair(w);
            foreach (int k in od.getPathIndices()) { lst.Add(graph.getPath(k).getLabel()); }
            return lst;
        } 
        #endregion










        internal void initializeExistingPathLabels(Graph graph)
        {
            this.existingPathLabels = new List<string>();
            foreach (Path path in graph.getPaths()) { existingPathLabels.Add(getPathIndicesLabel(graph, path)); }
        }
        private string getPathIndicesLabel(Graph graph, Path path) { return Str.combine(path.getNodeIndices(graph), Str.Delimiter.Dash); }

    }
}
