﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.Graph;
using U.ListOperations;

namespace Algorithms.Nw.ShortestPathAllPairs
{
    public class DijkstraAllOrigins : ShortestPathAllPairsAlgorithm
    {
        public override void run(Graph graph, bool keepTime)
        {
            U.SUE.Graph g = (U.SUE.Graph)graph;
            if (keepTime) { base.startTimer(); }
            int N = g.getNbNodes();
            int[] originIndices = getAllOriginIndices(g);
            base.D = UArray.sameValues<double>(double.MaxValue, N, N);
            base.P = UArray.sameValues<int>(-1, N, N);
            Dijkstra dijkstra = new Dijkstra();
            foreach (int oriIndex in originIndices)
            {
                dijkstra.run(g, null, oriIndex, -1, false);
                base.setRowForSource(dijkstra, oriIndex, N);
            }
            if (keepTime) { base.stopTimer(); }
            dijkstra.dispose();
        }


        private int[] getAllOriginIndices(U.SUE.Graph g)
        {
            List<int> origins = new List<int>();
            foreach (U.SUE.OdPair od in g.getOdPairs()) { origins.Add(od.getOriIndex()); }
            int[] arr = origins.Distinct().ToArray();
            origins.Clear(); origins = null;
            return arr;
        }
    }
}
