﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;
using U.Graph;
using Algorithms.Nw.ShortestPath;

namespace Algorithms.Nw.ShortestPathAllPairs
{
    public class DijkstraAllOdPairs : ShortestPathAllPairsAlgorithm
    {
        public override void run(Graph graph, bool keepTime)
        {
            U.SUE.Graph g = (U.SUE.Graph)graph;
            if (keepTime) { base.startTimer(); }
            int N = g.getNbNodes();
            base.D = UArray.sameValues<double>(double.MaxValue, N, N);
            base.P = UArray.sameValues<int>(-1, N, N);
            Dijkstra dijkstra = new Dijkstra();
            foreach (U.SUE.OdPair od in g.getOdPairs())
            {
                int s = od.getOriIndex();
                int t = od.getDesIndex();
                dijkstra.run(g, null, s, t, false);
                base.setRowForSource(dijkstra, s, N);
            }
            if (keepTime) { base.stopTimer(); }
            dijkstra.dispose();
        }
    }
}
