﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.Graph;
using U.ListOperations;

namespace Algorithms.Nw.ShortestPathAllPairs
{
    public class DijkstraAllPairs : ShortestPathAllPairsAlgorithm
    {
        public override void run(Graph graph, bool keepTime)
        {
            if (keepTime) { base.startTimer(); }
            int N = graph.getNbNodes();
            base.D = UArray.sameValues<double>(double.MaxValue, N, N);
            base.P = UArray.sameValues<int>(-1, N, N);
            Dijkstra dijkstra = new Dijkstra();
            for (int i = 0; i < N; i++)
            {
                dijkstra.run(graph, null, i, -1, false);
                base.setRowForSource(dijkstra, i, N);
            }
            if (keepTime) { base.stopTimer(); }
            dijkstra.dispose();
        }
    }
}
