﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.SUE;
using U.ListOperations;
using Algorithms.Nw.ShortestPath;

namespace Algorithms.Nw
{
    public class YenMethod : PathGenerationAlgorithm
    {
        private int K;
        private ShortestPathAlgorithm spa;

        public YenMethod(int K, ShortestPathAlgorithm shortestPathAlgorithm, bool keepExistingPaths)
            : base(keepExistingPaths)
        {
            this.K = K;
            this.spa = shortestPathAlgorithm;
        }


        public override void generate(Graph graph, bool keepTime, bool performPathAttributeCalculations)
        {
            /*
            if (keepTime) { base.startTimer(); }
            OdPair[] odPairs = graph.getOds().getArray();
            foreach (OdPair od in odPairs)
            {
                List<Path> pathList = new List<Path>();
                int s = od.getOriginIndex();
                int t = od.getDestIndex();
                    
                yen.calculate(graph, spa, s, t, K, false);
                List<List<int>> pathsAsEdgeList = yen.getShortestPathsAsEdgeList();
                foreach (List<int> edgeList in pathsAsEdgeList)
                {
                    Path path = new Path(UArray.toArray(edgeList), s, t);
                    pathList.Add(path);
                }
                Paths paths = new Paths(pathList.ToArray());
                od.setPaths(paths);
                pathList = null;
            }
            if (keepTime) { base.stopTimer(); }
            if (performPathAttributeCalculations) { graph.performPathAttributeCalculations(); }//*/
        }

    }
}
