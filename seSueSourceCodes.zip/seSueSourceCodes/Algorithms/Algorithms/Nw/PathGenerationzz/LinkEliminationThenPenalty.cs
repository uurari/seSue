﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.SUE;

namespace Algorithms.Nw
{
    public class LinkEliminationThenPenalty : PathGenerationAlgorithm
    {
        private int pathLimit;
        private ShortestPathAlgorithm spa;
        private double penalty; // if 0.05 means that fftt of 100 will be 105
        private int iterationPerOdLimit;
        private int pathLimitForFirstMethod;

        public LinkEliminationThenPenalty(int pathLimit, int pathLimitForFirstMethod, double penalty, int iterationPerOdLimit, ShortestPathAlgorithm shortestPathAlgorithm, bool keepExistingPaths)
            : base(keepExistingPaths)
        {
            this.pathLimit = pathLimit;
            this.iterationPerOdLimit = iterationPerOdLimit;
            this.spa = shortestPathAlgorithm;
            this.penalty = penalty;
            this.pathLimitForFirstMethod = pathLimitForFirstMethod;
        }

        public override void generate(Graph graph, bool keepTime, bool performPathAttributeCalculations)
        {
            /*
            if (pathLimit < 1) { return; }
            if (pathLimit < pathLimitForFirstMethod) { return; }
            if (keepTime) { base.startTimer(); }
            LinkElimination linkElimination = new LinkElimination(pathLimitForFirstMethod, spa, base.doKeepExistingPaths());
            linkElimination.generate(graph, false, false);
            LinkPenalty linkPenalty = new LinkPenalty(pathLimit, penalty, iterationPerOdLimit, spa, true);
            linkPenalty.generate(graph, false, false);
            if (keepTime) { base.stopTimer(); }
            if (performPathAttributeCalculations) { graph.performPathAttributeCalculations(); }
             * */
        }

    }
}
