﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.SUE;

namespace Algorithms.Nw
{
    public abstract class PathGenerationAlgorithm : Algorithm
    {
        private bool keepExistingPaths;


        // ABSTRACT
        public abstract void generate(Graph graph, bool keepTime, bool performPathAttributeCalculations);


        public PathGenerationAlgorithm(bool keepExistingPaths)
        {
            this.keepExistingPaths = keepExistingPaths;
        }

        public bool doKeepExistingPaths() { return this.keepExistingPaths; }
        
        
        
        
        /*
        public List<string> getExistingPathsStr()
        {
            return null;
        }
        //*/
    }
}
