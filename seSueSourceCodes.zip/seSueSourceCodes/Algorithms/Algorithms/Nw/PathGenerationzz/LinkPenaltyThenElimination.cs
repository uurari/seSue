﻿using Algorithms.Nw.ShortestPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.SUE;

namespace Algorithms.Nw
{
    public class LinkPenaltyThenElimination : PathGenerationAlgorithm
    {
        private int pathLimit;
        private ShortestPathAlgorithm spa;
        private double penalty; // if 0.05 means that fftt of 100 will be 105
        private int iterationPerOdLimit;
        private int pathLimitForFirstMethod;

        public LinkPenaltyThenElimination(int pathLimit, int pathLimitForFirstMethod, double penalty, int iterationPerOdLimit, ShortestPathAlgorithm shortestPathAlgorithm, bool keepExistingPaths)
            : base(keepExistingPaths)
        {
            this.pathLimit = pathLimit;
            this.iterationPerOdLimit = iterationPerOdLimit;
            this.spa = shortestPathAlgorithm;
            this.penalty = penalty;
            this.pathLimitForFirstMethod = pathLimitForFirstMethod;
        }

        public override void generate(Graph graph, bool keepTime, bool performPathAttributeCalculations)
        {/*
            if (pathLimit < 1) { return; }
            if (pathLimit < pathLimitForFirstMethod) { return; }
            if (keepTime) { base.startTimer(); }
            LinkPenalty linkPenalty = new LinkPenalty(pathLimitForFirstMethod, penalty, iterationPerOdLimit, spa, base.doKeepExistingPaths());
            linkPenalty.generate(graph, false, false);
            LinkElimination linkElimination = new LinkElimination(pathLimit, spa, true);
            linkElimination.generate(graph, false, false);
            if (keepTime) { base.stopTimer(); }
            if (performPathAttributeCalculations) { graph.performPathAttributeCalculations(); }//*/
        }

    }
}
