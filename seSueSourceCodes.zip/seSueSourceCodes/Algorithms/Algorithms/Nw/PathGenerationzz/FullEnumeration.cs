﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Nw
{
    class FullEnumeration
    {
        /*
        private static string fname = "AllPaths.txt";
        public static void generateAllPaths(Graph graph)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            OFile.create(fname);
            List<int> originIndices = graph.getOriginIndices();
            foreach (int originIndex in originIndices)
            {
                Vertex s = graph.getVertices().get(originIndex);
                List<Edge> edgeList = new List<Edge>();
                List<Vertex> vertexList = new List<Vertex>() { s };
                mainStep(graph, s, edgeList, vertexList, fname);
            }
            stopWatch.Stop();
            OFile.append(fname, stopWatch.ElapsedMilliseconds.ToString() + " miliseconds.");
        }

        private static void mainStep(Graph graph, Vertex i, List<Edge> edgeList, List<Vertex> vertexList, string fname)
        {
            List<int> outEdgeIndices = i.getOutEdgeIndices();
            foreach (int ijIndex in outEdgeIndices)
            {
                Edge ij = graph.getEdge(ijIndex);
                Vertex j = graph.getVertices().get(ij.getToIndex());
                if (!vertexList.Contains(j))
                {
                    vertexList.Add(j);
                    edgeList.Add(ij);
                    addPathIfReachedDestination(graph, edgeList, vertexList, fname);
                    mainStep(graph, j, edgeList, vertexList, fname);
                }
            }
            if (edgeList.Count > 0)
            {
                edgeList.RemoveAt(edgeList.Count - 1);
                vertexList.RemoveAt(vertexList.Count - 1);
            }
        }
        private static void addPathIfReachedDestination(Graph graph, List<Edge> edgeList, List<Vertex> vertexList, string fname)
        {
            Vertex s = vertexList[0];
            Vertex t = vertexList[vertexList.Count - 1];
            OdPair od = graph.getOd(s, t);
            if (od != null) { OFile.append(fname, getLine(graph, edgeList, od)); }
        }
        private static string getLine(Graph graph, List<Edge> edgeList, OdPair od)
        {
            EdgesOld edges = graph.getEdges();
            string line = od.ToString();
            foreach (Edge edge in edgeList) { line = Str.combine(line, edges.getId(edge).ToString(), Str.Delimiter.Tab); }
            return line;
        }
        //*/
    }
}
