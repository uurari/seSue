﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace U.IO
{
    public class ITextFile
    {
        // All Text
        public static string getAllTextFromFile(string path)
        {
            if (!OFile.exists(path)) { return null; }
            string line = String.Empty;
            using (StreamReader sr = new StreamReader(path)) { line = sr.ReadToEnd(); }
            return line;
        }
        public static string getAllText()
        {
            string filepath = IFileDialog.browseFilepath("Select text file.", IFileDialog.FileFilter.Text, true);
            if (filepath == String.Empty) { return null; }
            return getAllTextFromFile(filepath);
        }
        public static string[] getFilenameAndAllText()
        {
            string filepath = IFileDialog.browseFilepath("Select text file.", IFileDialog.FileFilter.Text, true);
            if (filepath == String.Empty) { return null; }
            string[] arr = new string[2];
            arr[0] = filepath;
            arr[1] = getAllTextFromFile(filepath);
            return arr;
        }


        // All Lines
        public static List<List<string>> getLinesFromFiles(List<string> paths)
        {
            List<List<string>> linesList = new List<List<string>>();
            foreach (string path in paths)
            {
                if (!OFile.exists(path)) { return null; }
                List<string> lines = new List<string>();
                using (StreamReader sr = new StreamReader(path)) { string line; while ((line = sr.ReadLine()) != null) { lines.Add(line); } }
                linesList.Add(lines);
            }
            return linesList;
        }
        public static List<string> getLinesFromFile(string path)
        {
            if (path == null) { return null; }
            return getLinesFromFiles(new List<string>() { path })[0];
        }


        public static List<string> getLines()
        {
            string filepath = IFileDialog.browseFilepath("Select text file.", IFileDialog.FileFilter.Text, true);
            if (filepath == String.Empty) { return null; }
            return getLinesFromFile(filepath);
        }
        public static List<List<string>> getLinesFromFiles()
        {
            List<string> paths = IFileDialog.browseFilepaths("Select text file.", IFileDialog.FileFilter.Text, true);
            if (paths == null) { return null; }
            if (paths.Count == 0) { return null; }
            return getLinesFromFiles(paths);
        }


        public static List<List<string>> getFilenameAndLines()
        {
            string filepath = IFileDialog.browseFilepath("Select text file.", IFileDialog.FileFilter.Text, true);
            if (filepath == String.Empty) { return null; }
            List<List<string>> lst = new List<List<string>>();
            lst.Add(new List<string>() { filepath });
            lst.Add(getLinesFromFile(filepath));
            return lst;
        }


        // First Line
        public static List<string> getFirstLinesFromFiles(List<string> paths)
        {
            List<string> firstLines = new List<string>();
            foreach (string path in paths)
            {
                if (!OFile.exists(path)) { return null; }
                string line = String.Empty;
                using (StreamReader sr = new StreamReader(path)) { bool cs = true; while (cs && (line = sr.ReadLine()) != null) { firstLines.Add(line); cs = false; } }
            }
            return firstLines;
        }
        public static string getFirstLine(string path) { return getFirstLinesFromFiles(new List<string>() { path })[0]; }

    }
}
