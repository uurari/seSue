﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using U.ListOperations;
using U.StringOperations;

namespace U.IO
{
    public class OFile
    {
        public static void create(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return; }
            string path = sfd.FileName;
            if (path == String.Empty || path == null) { return; }
            create(path, lines);
        }
        public static void create(string path) { File.Create(path).Close(); }
        public static void create(string path, string line) { create(path); append(path, line); }
        public static void create(string path, List<string> lines) { create(path); append(path, lines); }
        public static void create(string path, DataTable dt, Str.Delimiter delimiter)
        {
            create(path);
            List<List<string>> lst = UList.getDtRows(dt, true);
            List<string> lines = Str.combine(lst, delimiter);
            append(path, lines);
        }
        public static void create(string path, List<List<double>> values, Str.Delimiter delimiter)
        {
            create(path);
            List<string> lines = Str.combine(values, delimiter);
            append(path, lines);
        }


        public static string createAndGetFilename(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return String.Empty; }
            string path = sfd.FileName;
            if (path == String.Empty || path == null) { return String.Empty; }
            create(path, lines);
            return path;
        }



        public static void delete(string path) { File.Delete(path); }
        public static void append(string path, string line)
        {
            if (!File.Exists(path)) { create(path); }
            using (StreamWriter sw = File.AppendText(path)) { sw.WriteLine(line); }
        }
        public static void append(string path, List<string> lines)
        {
            if (!File.Exists(path)) { create(path); }
            using (StreamWriter sw = File.AppendText(path)){foreach (string line in lines){sw.WriteLine(line);}}
        }
        public static bool exists(string path) { return File.Exists(path); }

        public static void append<T>(string path, List<T> list, Str.Delimiter delimiter)
        {
            if (list == null) { return; }
            if (list.Count == 0) { return; }
            string str = Str.combine<T>(list, delimiter);
            append(path, str);
        }
        
    }
}
