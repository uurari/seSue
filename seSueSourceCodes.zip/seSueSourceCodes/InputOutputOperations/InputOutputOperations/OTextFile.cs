﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace U.IO
{
    public class OTextFile
    {
        public static void create(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files | *.txt";
            sfd.DefaultExt = "txt";
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return; }
            string path = sfd.FileName;
            OFile.create(path, lines);
        }


        public static string createAndGetFilename(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files | *.txt";
            sfd.DefaultExt = "txt";
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return String.Empty; }
            string path = sfd.FileName;
            OFile.create(path, lines);
            return path;
        }
    }
}
