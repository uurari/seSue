﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace U.IO
{
    public class IFileDialog
    {
        public enum FileFilter { None, Text, Sue };
        public static List<string> browseFilepaths(string title, FileFilter fileFilter, bool restoreDirectory)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = title;
            fdlg.Filter = getFilterText(fileFilter);
            fdlg.RestoreDirectory = restoreDirectory;
            fdlg.Multiselect = true;
            DialogResult dr = fdlg.ShowDialog();
            if (dr != DialogResult.OK) { fdlg.Dispose(); return null; }
            List<string> paths = new List<string>();
            foreach (string file in fdlg.FileNames) { paths.Add(file); }
            fdlg.Dispose();
            return paths;
        }
        public static string browseFilepath(string title, FileFilter fileFilter, bool restoreDirectory)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = title;
            fdlg.Filter = getFilterText(fileFilter);
            fdlg.RestoreDirectory = restoreDirectory;
            fdlg.Multiselect = false;
            DialogResult dr = fdlg.ShowDialog();
            if (dr != DialogResult.OK) { fdlg.Dispose(); return null; }
            string path = fdlg.FileName;
            fdlg.Dispose();
            return path;
        }


        private static string getFilterText(FileFilter fileFilter)
        {
            switch (fileFilter)
            {
                case FileFilter.None: return string.Empty;
                case FileFilter.Text: return "Text Files (.txt)|*.txt";
                case FileFilter.Sue: return "SUE Files (.sue)|*.sue";
                //case FileFilter.Text: return "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
                default: return string.Empty;
            }
        }
    }
}
