﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace U.IO
{
    public class SueFile
    {
        // All Text
        public static string getAllTextFromFile(string path)
        {
            if (!OFile.exists(path)) { return null; }
            string line = String.Empty;
            using (StreamReader sr = new StreamReader(path)) { line = sr.ReadToEnd(); }
            return line;
        }
        public static string getAllText()
        {
            string filepath = IFileDialog.browseFilepath("Select sue file.", IFileDialog.FileFilter.Sue, true);
            if (filepath == String.Empty) { return null; }
            return getAllTextFromFile(filepath);
        }
        public static string[] getFilenameAndAllText()
        {
            string filepath = IFileDialog.browseFilepath("Select sue file.", IFileDialog.FileFilter.Sue, true);
            if (filepath == String.Empty) { return null; }
            string[] arr = new string[2];
            arr[0] = filepath;
            arr[1] = getAllTextFromFile(filepath);
            return arr;
        }


        // Output
        public static void create(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "SUE Files (.sue)|*.sue";
            sfd.DefaultExt = "sue";
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return; }
            string path = sfd.FileName;
            OFile.create(path, lines);
        }
        public static string createAndGetFilename(List<string> lines)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "SUE Files (.sue)|*.sue";
            sfd.DefaultExt = "sue";
            DialogResult dr = sfd.ShowDialog();
            if (dr != DialogResult.OK) { sfd.Dispose(); return String.Empty; }
            string path = sfd.FileName;
            OFile.create(path, lines);
            return path;
        }

    }
}
