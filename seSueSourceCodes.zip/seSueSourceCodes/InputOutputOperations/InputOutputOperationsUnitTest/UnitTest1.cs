﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InputOutputOperationsUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void sampleTest()
        {
            string aa = "aa";
            bool actual = aa == "aa";
            const bool expected = true;
            Assert.AreEqual(expected, actual, "aa = aa");
        }
    }
}
