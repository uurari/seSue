﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscreteChoiceModel
{
    public abstract class ChoiceModel
    {
        public enum Type
        {
            Deterministic,
            Logit,
            Weibit,
            MDM
        };




        private Type type;
        // CONSTRUCTORS
        public ChoiceModel(Type type)
        {
            this.type = type;
        }
        public static ChoiceModel fromString(string choiceModelString) { return CMStr.fromString(choiceModelString); }



        // GETTERS
        public Type getType() { return this.type; }


        // OVERRIDE
        public abstract double[] calcProbabilities(double[] utilityFunctionParameters);
        public abstract ChoiceModel Clone();


    }
}
