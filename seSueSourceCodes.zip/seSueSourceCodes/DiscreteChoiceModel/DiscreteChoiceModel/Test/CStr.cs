﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscreteChoiceModel.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = String.Empty;
            ChoiceModel cm;
            int uur = 12;

            str = "logit(0.1212)";
            cm = ChoiceModel.fromString(str);
            uur = 12;


            str = "logit(00000.1212)";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "logit(0.1212,[12;12;15.7;12.5;16])";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "weibit(30.333,33)";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "WEIBIT(30.333,33,[12;12;15.7;12.5;16])";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "MDM(Add,0.00001)";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "MDM(mul,0.00001,[StaN;n(0.00,1.5);exp(4.3,10.1)])";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "MDM(Mul,1E-05,[StaN;N(0,1.5);Exp(4.3,10.1)])";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "MDM(Add,0.00001,-200,-5.0505)";
            cm = ChoiceModel.fromString(str);
            uur = 12;

            str = "MDM(Add,0.00001,-200,-5.0505,[StaN;N(0,1.5);Exp(4.3,10.1)])";
            cm = ChoiceModel.fromString(str);
            uur = 12;


        }
    }
}
