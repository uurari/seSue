﻿using StatisticalDistribution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscreteChoiceModel.MDMHelpers
{
    class Prob
    {
        public static double[] get(MDM mdm, double[] V)
        {
            if (V.Length == 1) { double[] P = new double[1]; P[0] = 1.0; return P; }
            double lambda;
            switch (mdm.getLambdaAlgorithm())
            {
                case MDM.LambdaAlgorithm.AddSta:
                    lambda = Lambda.get(mdm, V);
                    MDM.lambda = lambda;
                    return getAdd(mdm.getMarginalDistributions(), V, lambda);
                case MDM.LambdaAlgorithm.MulSta:
                    lambda = Lambda.get(mdm, V);
                    MDM.lambda = lambda;
                    return getMul(mdm.getMarginalDistributions(), V, lambda);
            }
            throw new NotImplementedException();
        }


        public static double[] getAdd(Distribution[] mds, double[] V, double lambda)
        {
            double[] P = new double[V.Length];
            for (int k = 0; k < V.Length; k++) { P[k] = 1.0 - mds[k].cdf(lambda - V[k]); }
            return P;
        }

        public static double[] getMul(Distribution[] mds, double[] V, double lambda)
        {
            double[] P = new double[V.Length];
            for (int k = 0; k < V.Length; k++) { P[k] = mds[k].cdf(lambda / V[k]); }
            return P;
        }
    }
}
