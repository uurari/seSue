﻿using StatisticalDistribution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscreteChoiceModel.MDMHelpers
{
    class DistBounds
    {
        public static double[] cdfInv(Distribution[] mds, double prob)
        {
            double[] cdfInv = new double[mds.Length];
            for (int k = 0; k < mds.Length; k++)
            {
                if (mds[k] != null) { cdfInv[k] = mds[k].cdfInv(prob); }
            }
            return cdfInv;
        }


    }
}
