﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;

namespace StatisticalDistribution
{
    public abstract class Distribution
    {
        public enum Type
        {
            Exponential,
            StandardNormal,
            Normal,
            Uniform,
            Gamma,
            ChiSquare,
            F,
            Binomial,
            Poisson,
            Geometric,
            HyperGeometric,
            Bernouilli,
            Gumbel,
            Pareto
        };
        private Type type;

        #region CONSTRUCTORS
        public Distribution(Type type)
        {
            this.type = type;
        }
        public static Distribution fromString(string distributionString)
        {
            return DStr.fromString(distributionString);
        } 
        #endregion

        #region GETTERS
        public Type getType() { return this.type; }
        public List<double> getArguments()
        {
            string insideParenthesis = Str.getInsideParenthesis(this.ToString(), Str.ParenthesisTypes.Regular);
            if (insideParenthesis == String.Empty) { return new List<double>(); }
            return Str.toDouble(Str.split(insideParenthesis, Str.Delimiter.Comma));
        } 
        #endregion

        #region OVERRIDE
        public abstract double pdf(double x);
        public abstract double cdf(double x);
        public abstract double cdfInv(double p);
        public abstract double variance();
        public abstract double mean();
        public abstract double std();
        public abstract double skewness();
        public abstract double kurtosis();
        public abstract double mode();
        public abstract double median();
        public abstract double Q1();
        public abstract double Q3(); 
        #endregion

        #region TOSTRING and CLONE
        public abstract Distribution Clone();
        public override string ToString() { return "null"; } 
        #endregion

    }
}
