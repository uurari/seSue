﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.ListOperations
{
    public class UIndexed
    {
        private int index;


        // Getters
        public int getIndex() { return this.index; }
        // Setters
        public void setIndex(int index) { this.index = index; }
        public static void setIndices(UIndexed[] array)
        {
            int n = array.Length;
            for (int i = 0; i < n; i++)
            {
                array[i].setIndex(i);
            }
        }

    }
}
