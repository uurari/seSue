﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.ListOperations
{
    public class UArrayClass<T>
    {
        private T[] array;
        private int n;

        // Constructors
        public UArrayClass(T[] array) { this.array = array; this.n = array.Length; }


        // Getters
        public T[] getArray() { return this.array; }
        public int getN() { return n; }
        public T get(int index) { return array[index]; }

        


    }
}
