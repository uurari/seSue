﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.ListOperations.ListSort
{
    class SortValue
    {
        /*
        public enum ValueType { Int, Double, Long }

        private int id;
        private ValueType valueType;
        private int valueInt;
        private int absValueInt;
        private double valueDouble;
        private double absValueDouble;
        private long valueLong;
        private long absValueLong;

        private double spearmanRank;

        public SortValue(int id, int value)
        {
            this.id = id;
            this.valueInt = value;
            this.absValueInt = Math.Abs(value);
            this.valueType = ValueType.Int;
        }
        public SortValue(int id, double value)
        {
            this.id = id;
            this.valueDouble = value;
            this.absValueDouble = Math.Abs(value);
            this.valueType = ValueType.Double;
        }
        public SortValue(int id, long value)
        {
            this.id = id;
            this.valueLong = value;
            this.absValueLong = Math.Abs(value);
            this.valueType = ValueType.Long;
        }

        // GETTERS
        public int getId() { return this.id; }
        public int getValueInt() { return this.valueInt; }
        public int getAbsValueInt() { return this.absValueInt; }
        public double getValueDouble() { return this.valueDouble; }
        public double getValue()
        {
            switch (this.valueType)
            {
                case ValueType.Int: return Convert.ToDouble(this.valueInt);
                case ValueType.Double: return this.valueDouble;
                case ValueType.Long: return Convert.ToDouble(this.valueLong);
                default: return -100000.0;
            }
        }
        public double getAbsValueDouble() { return this.absValueDouble; }
        public double getValueLong() { return this.valueLong; }
        public double getAbsValueLong() { return this.absValueLong; }
        public double getSpearmanRank() { return this.spearmanRank; }

        // SETTERS
        public void setSpearmanRank(double rank) { this.spearmanRank = rank; }//*/
    }
}
