﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.ListOperations
{
    public class UContainer<T>
    {
        private List<T> list = new List<T>();


        public UContainer() { this.list = new List<T>(); }
        public UContainer(List<T> list) { this.list = list; }
        public UContainer(T obj1) { this.list = new List<T>() { obj1 }; }
        public UContainer(T obj1, T obj2) { this.list = new List<T>() { obj1, obj2 }; }
        public UContainer(T obj1, T obj2, T obj3) { this.list = new List<T>() { obj1, obj2, obj3 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4) { this.list = new List<T>() { obj1, obj2, obj3, obj4 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5, T obj6) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5, obj6 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5, T obj6, T obj7) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5, obj6, obj7 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5, T obj6, T obj7, T obj8) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5, T obj6, T obj7, T obj8, T obj9) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8, obj9 }; }
        public UContainer(T obj1, T obj2, T obj3, T obj4, T obj5, T obj6, T obj7, T obj8, T obj9, T obj10) { this.list = new List<T>() { obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8, obj9, obj10 }; }

        // Getters
        public virtual int getN() { if (this.list == null) { return 0; } return this.list.Count; }
        public virtual T get(int id) { return this.list[id]; }
        public virtual List<T> getList() { return this.list; }
        public virtual T getLast() { return this.list[this.list.Count - 1]; }
        public virtual bool isNull() { if (this.list == null) { return true; } return this.list.Count == 0; }
        public virtual int getId(T obj) { return this.list.IndexOf(obj); }

        // Setters
        public virtual void add(T obj) { this.list.Add(obj); }
        public virtual void setList(List<T> list) { this.list = list; }
        public virtual void clear() { this.list = null; }
        
    }

}