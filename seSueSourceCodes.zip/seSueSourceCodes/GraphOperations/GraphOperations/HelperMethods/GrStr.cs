﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;
using U.StringOperations;

namespace U.Graph
{
    class GrStr
    {
        // ([0;1;2;3;4],[0-1;0-2;1-3;2-3;2-4],[0-1;0-1-3;0-2-3;0-2-4])
        internal const Str.ParenthesisTypes PAR = Str.ParenthesisTypes.Regular;
        internal const Str.Delimiter DEL = Str.Delimiter.Comma;


        internal static string toString(Graph graph)
        {
            string strN = StrArray.getArrayString(Str.toString(UList.toList(graph.getNodes())));
            string strA = StrArray.getArrayString(Str.toString(UList.toList(graph.getArcs())));
            string strP = StrArray.getArrayString(Str.toString(UList.toList(graph.getPaths())));
            return StrFunc.getFuncString(String.Empty, new List<string>() { strN, strA, strP });
        }




        internal static StrFunc getStrFunc(string str)
        {
            StrFunc sf = new StrFunc(str, PAR, DEL);
            if (sf.getNbArgs() != 3) { throw new Graph.InvalidGraphException("graph string should contain 3 argments (nodes, arcs, paths): " + sf.getFuncString()); }
            return sf;
        }
        internal static Node[] getNodes(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(0));
            List<string> lst = sa.getItems();
            Node[] arr = new Node[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Node(lst[i]); }
            return arr;
        }
        internal static Arc[] getArcs(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(1));
            List<string> lst = sa.getItems();
            Arc[] arr = new Arc[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Arc(lst[i]); }
            return arr;
        }
        internal static Path[] getPaths(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(2));
            List<string> lst = sa.getItems();
            Path[] arr = new Path[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Path(lst[i]); }
            return arr;
        }


    }
}
