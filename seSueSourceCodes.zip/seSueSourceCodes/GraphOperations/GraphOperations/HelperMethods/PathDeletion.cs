﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.Graph
{
    class PathDeletion
    {
        internal static void clearAll(Graph graph)
        {
            int N = graph.getNbNodes();
            int A = graph.getNbArcs();
            int P = graph.getNbPaths();

            // Path
            graph.setPaths(new Path[0]);

            // Node
            foreach (Node node in graph.getNodes())
            {
                //node.setEmanatingPathIndices(new int[0]);
                //node.setIncomingPathIndices(new int[0]);
                //node.setPathIndices(new int[0]);
            }

            // Arc
            foreach (Arc arc in graph.getArcs())
            {
                //arc.setPathIndices(new int[0]);
            }

        }


    }
}
