﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.Graph.HelperMethods;
using U.ListOperations;
using U.StringOperations;

namespace U.Graph
{
    public class Node
    {
        private string label;
        private int[] outArcIndices;
        private int[] inArcIndices;
        //private int[] pathIndices;
        //private int[] emanatingPathIndices;
        //private int[] incomingPathIndices;
        private string strOutArcIndices;
        private string strInArcIndices;

        //CONSTRUCTORS
        public Node(string label) { this.label = label; }
        public Node(List<string> args)
        {
            this.label = args[0];
            this.outArcIndices = GraphString.getArrInt(args[1], Str.Delimiter.Semicolon);
            this.inArcIndices = GraphString.getArrInt(args[2], Str.Delimiter.Semicolon);
            this.strOutArcIndices = args[1];
            this.strInArcIndices = args[2];
            //this.pathIndices = GraphString.getArrInt(args[3], Str.Delimiter.Semicolon);
            //this.emanatingPathIndices = GraphString.getArrInt(args[4], Str.Delimiter.Semicolon);
            //this.incomingPathIndices = GraphString.getArrInt(args[5], Str.Delimiter.Semicolon);
        }

        // SETTERS
        public void setOutArcIndices(int[] outArcIndices) { this.outArcIndices = outArcIndices; }
        public void setInArcIndices(int[] inArcIndices) { this.inArcIndices = inArcIndices; }
        //public void setPathIndices(int[] pathIndices) { this.pathIndices = pathIndices; }
        //public void setEmanatingPathIndices(int[] emanatingPathIndices) { this.emanatingPathIndices = emanatingPathIndices; }
        //public void setIncomingPathIndices(int[] incomingPathIndices) { this.incomingPathIndices = incomingPathIndices; }

        // GETTERS
        public int[] getOutArcIndices() { return this.outArcIndices; }
        public int[] getInArcIndices() { return this.inArcIndices; }
        public string getStrOutArcIndices() { return this.strOutArcIndices; }
        public string getStrInArcIndices() { return this.strInArcIndices; }
        //public int[] getPathIndices() { return this.pathIndices; }
        //public int[] getEmanatingPathIndices() { return this.emanatingPathIndices; }
        //public int[] getIncomingPathIndices() { return this.incomingPathIndices; }

        // COMMON
        public string getLabel() { return this.label; }
        public override string ToString() { return this.label; }
        public bool Equals(Node node) { return this.label == node.getLabel(); }
        public Node clone() { Node v = new Node(this.label); v.outArcIndices = outArcIndices; v.inArcIndices = inArcIndices; return v; }
        
        // INTERNAL
        //internal void setIndex(int index) { this.index = index; }

    }
}
