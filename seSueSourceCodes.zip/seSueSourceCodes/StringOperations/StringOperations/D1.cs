﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    class D1
    {
        public static bool isNumeric(List<string> row) { foreach (string cell in row) { if (!TypeOp.isNumeric(cell)) { return false; } } return true; }
        public static bool isInteger(List<string> row) { foreach (string cell in row) { if (!TypeOp.isInteger(cell)) { return false; } } return true; }
        public static List<double> toDouble(List<string> row) { List<double> dblRow = new List<double>(); foreach (string str in row) { dblRow.Add(Str.toDouble(str)); } return dblRow; }
        public static List<string> trim(List<string> row) { for (int i = 0; i < row.Count; i++) { row[i] = Str.trim(row[i]); } return row; }

        public static List<List<string>> split(List<string> vector, Str.Delimiter delimiter) { List<List<string>> table = new List<List<string>>(); foreach (string row in vector) { List<string> columns = row.Split(Delimit.getStrDelimiter(delimiter)).ToList(); table.Add(columns); } return table; }

    }
}
