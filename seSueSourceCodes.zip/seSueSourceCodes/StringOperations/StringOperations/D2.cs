﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    class D2
    {
        
        public static List<List<double>> toDouble(List<List<string>> strTable) { List<List<double>> dblTable = new List<List<double>>(); foreach (List<string> strRow in strTable) { dblTable.Add(Str.toDouble(strRow)); } return dblTable; }
        public static bool isProper(List<List<string>> table) { int nbColumns = -1; if (table == null) { return false; } foreach (List<string> row in table) { if (row == null) { return false; } if (nbColumns == -1) { nbColumns = row.Count; } else if (nbColumns != row.Count) { return false; } } return true; }
        public static bool isNumeric(List<List<string>> table) { foreach (List<string> row in table) { if (!Str.isNumeric(row)) { return false; } } return true; }
        public static bool isInteger(List<List<string>> table) { foreach (List<string> row in table) { if (!Str.isInteger(row)) { return false; } } return true; }
        public static List<List<string>> trim(List<List<string>> table) { for (int i = 0; i < table.Count; i++) { table[i] = Str.trim(table[i]); } return table; }

        public static List<List<string>> toList(string[,] matrix) { int nRow = matrix.GetLength(0); int nCol = matrix.GetLength(1); List<List<string>> table = new List<List<string>>(); for (int i = 0; i < nRow; i++) { List<string> row = new List<string>(); for (int j = 0; j < nCol; j++) { row.Add(matrix[i, j]); } table.Add(row); } return table; }
        public static string[,] toArray(List<List<string>> table) { string[,] matrix = new string[table.Count, table[0].Count]; for (int i = 0; i < table.Count; i++) { for (int j = 0; j < table[i].Count; j++) { matrix[i, j] = table[i][j]; } } return matrix; }

        public static string[,] transpose(string[,] matrix) { int nRow = matrix.GetLength(0); int nCol = matrix.GetLength(1); string[,] tmatrix = new string[nRow, nCol]; for (int i = 0; i < nRow; i++) { for (int j = 0; j < nCol; j++) { tmatrix[j, i] = matrix[i, j]; } } return tmatrix; }
        public static List<List<string>> transpose(List<List<string>> table) { List<List<string>> ttable = new List<List<string>>(); int nCol = getMaxNbOfColumns(table); for (int j = 0; j < nCol; j++) { ttable.Add(new List<string>()); } for (int i = 0; i < table.Count; i++) { for (int j = 0; j < table[i].Count; j++) { ttable[j].Add(table[i][j]); } } return ttable; }
        
        private static int getMaxNbOfColumns(List<List<string>> table) { int maxN = 0; for (int i = 0; i < table.Count; i++) { maxN = Math.Max(maxN, table[i].Count); } return maxN; }
    }
}