﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace U.StringOperations
{
    class Json
    {
        private static JavaScriptSerializer json = new JavaScriptSerializer();


        public static string toJson<T>(T obj)
        {
            return json.Serialize(obj);
        }

        public static T fromJson<T>(string strJson)
        {
            json.MaxJsonLength = Int32.MaxValue;
            return json.Deserialize<T>(strJson);
        }
    }
}
