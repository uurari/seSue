﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    class D0
    {
        public static string left(string str, int nbChars) { return str.Substring(0, nbChars); }
        public static string right(string str, int nbChars) { return str.Substring(str.Length - nbChars); }

        public static bool startsWith(string str, string startsWith) { return Str.left(str, startsWith.Length).Equals(startsWith); }
        public static bool endsWith(string str, string endsWith) { return Str.right(str, endsWith.Length).Equals(endsWith); }
        
        public static string readAfter(string str, string after) { int i = str.IndexOf(after); return str.Substring(i + after.Length); }
        public static string readUntil(string str, string until) { return Str.left(str, str.IndexOf(until)); }

        public static int findLastIndex(string str, string find) { string s = str; int indx = -1; int i = s.IndexOf(find); while (i > -1) { s = s.Substring(i + 1); indx += i + 1; i = s.IndexOf(find); } return indx; }
        public static string readUntilLast(string str, string until) { int i = Str.findLastIndex(str, until); if (i == -1) { return str; } return str.Substring(0, i); }
        

        public static bool contains(string str, string contains) { return str.IndexOf(contains) >= 0; }
        public static string trim(string str) { if (str == String.Empty || str.Length < 1 || str == "") { return str; } str = str.Trim(); bool cont = (str != String.Empty && str.Length > 0 && str != ""); while (cont) { cont = false; char[] array = str.ToCharArray(); if (array[0] == ' ') { if (array.Length == 1) { return String.Empty; } str = str.Substring(1); cont = true; } else if (array[array.Length - 1] == ' ') { if (array.Length == 1) { return String.Empty; } str = str.Substring(0, str.Length - 1); cont = true; } } return str; }

        public static string getFuncName(string str, Str.ParenthesisTypes parenthesisType)
        {
            string openParenthesis = Str.getOpenParenthesis(parenthesisType);
            string closeParenthesis = Str.getOpenParenthesis(parenthesisType);
            int oi = str.IndexOf(openParenthesis);
            int ci = Str.findLastIndex(str, closeParenthesis);
            if (oi.Equals(-1) || ci.Equals(-1) || ci < oi) { return str; }
            return Str.readUntil(str, openParenthesis);
        }
        public static string getInsideParenthesis(string str, Str.ParenthesisTypes parenthesisType)
        {
            string openParenthesis = Str.getOpenParenthesis(parenthesisType);
            string closeParenthesis = Str.getOpenParenthesis(parenthesisType);
            int oi = str.IndexOf(openParenthesis);
            int ci = Str.findLastIndex(str, closeParenthesis);
            if (oi.Equals(-1) || ci.Equals(-1) || ci < oi) { return String.Empty; }
            string s = readAfter(str, openParenthesis);
            s = Str.readUntilLast(s, closeParenthesis);
            return Str.left(s, s.Length - 1); 
        }
        public static List<string> getArguments(string str, Str.ParenthesisTypes parenthesisType, Str.Delimiter delimiter) { return Str.split(getInsideParenthesis(str, parenthesisType), delimiter); }


    }
}
