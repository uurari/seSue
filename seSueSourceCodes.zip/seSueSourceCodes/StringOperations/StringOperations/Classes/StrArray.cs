﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    public class StrArray
    {
        private const Str.ParenthesisTypes PAR = Str.ParenthesisTypes.Square;
        private const Str.Delimiter DEL = Str.Delimiter.Semicolon;


        private Str.ParenthesisTypes par;
        private Str.Delimiter del;
        private string arrayString;
        private List<string> items;

        // CONSTRUCTOR - 1
        public StrArray(string arrayString) { constructor1(arrayString, PAR, DEL); }
        public StrArray(string arrayString, Str.ParenthesisTypes parenthesisType, Str.Delimiter delimiter) { constructor1(arrayString, parenthesisType, delimiter); }
        
        // CONSTRUCTOR - 2
        public StrArray(List<string> items) { constructor2(items, PAR, DEL); }
        public StrArray(List<double> items) { constructor2(Str.toString(items), PAR, DEL); }
        public StrArray(List<int> items) { constructor2(Str.toString(items), PAR, DEL); }
        public StrArray(List<bool> items) { constructor2(Str.toString(items), PAR, DEL); }
        public StrArray(List<string> items, Str.ParenthesisTypes par, Str.Delimiter del) { constructor2(Str.toString(items), par, del); }
        public StrArray(List<double> items, Str.ParenthesisTypes par, Str.Delimiter del) { constructor2(Str.toString(items), par, del); }
        public StrArray(List<int> items, Str.ParenthesisTypes par, Str.Delimiter del) { constructor2(Str.toString(items), par, del); }
        public StrArray(List<bool> items, Str.ParenthesisTypes par, Str.Delimiter del) { constructor2(Str.toString(items), par, del); }



        // GETTERS
        public int getNbItems() { return this.arrayString.Length; }
        public string getArrayString() { return this.arrayString; }
        public List<string> getItems() { return this.items; }
        public List<double> getItemsDouble() { return Str.toDouble(this.items); }
        public List<int> getItemsInt() { return Str.toInt(this.items); }
        public string getItem(int index) { return this.items[index]; }
        public double getItemDouble(int index) { return Str.toDouble(this.items[index]); }
        public int getItemInt(int index) { return Str.toInt(this.items[index]); }



        // STATIC
        public static string getArrayString(List<string> items) { return new StrArray(items).getArrayString(); }
        public static string getArrayString(List<string> items, Str.ParenthesisTypes par, Str.Delimiter del) { return new StrArray(items, par, del).getArrayString(); }
        public static List<string> getItems(string arrayString) { return new StrArray(arrayString).getItems(); }
        public static List<string> getItems(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del) { return new StrArray(arrayString, par, del).getItems(); }
        public static List<double> getItemsDouble(string arrayString) { return new StrArray(arrayString).getItemsDouble(); }
        public static List<double> getItemsDouble(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del) { return new StrArray(arrayString, par, del).getItemsDouble(); }
        public static List<int> getItemsInt(string arrayString) { return new StrArray(arrayString).getItemsInt(); }
        public static List<int> getItemsInt(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del) { return new StrArray(arrayString, par, del).getItemsInt(); }
        public static string getItem(string arrayString, int index) { return new StrArray(arrayString).getItem(index); }
        public static string getItem(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del, int index) { return new StrArray(arrayString, par, del).getItem(index); }
        public static double getItemDouble(string arrayString, int index) { return new StrArray(arrayString).getItemDouble(index); }
        public static double getItemDouble(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del, int index) { return new StrArray(arrayString, par, del).getItemDouble(index); }
        public static int getItemInt(string arrayString, int index) { return new StrArray(arrayString).getItemInt(index); }
        public static int getItemInt(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del, int index) { return new StrArray(arrayString, par, del).getItemInt(index); }



        // Private Constructors
        private void constructor1(string arrayString, Str.ParenthesisTypes par, Str.Delimiter del)
        {
            this.par = par;
            this.del = del;
            if (Str.left(arrayString, 1) != Str.getOpenParenthesis(par)) { throw new NotImplementedException(); }
            if (Str.right(arrayString, 1) != Str.getCloseParenthesis(par)) { throw new NotImplementedException(); }
            this.arrayString = arrayString;
            this.items = StrFunc.getArgs("f" + arrayString, par, del);
        }
        private void constructor2(List<string> items, Str.ParenthesisTypes par, Str.Delimiter del)
        {
            this.par = par;
            this.del = del;
            this.items = items;
            this.arrayString = Str.inParenthesis(Str.combine(items, del), par);
        }


        

    }
}
