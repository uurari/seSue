﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations.Classes.ClassHelpers
{
    class StrFuncHelper
    {
        private static List<char> lstOpenPars = new List<char>() { '(', '[', '{' };
        private static List<char> lstClosePars = new List<char>() { ')', ']', '}' };
        private enum ParenthesisTypes { None, Regular, Squar, Braces };

        public static List<string> getArgs(string inParenthesis, Str.Delimiter delimiter)
        {
            List<string> args = new List<string>();
            char delimiterChar = Delimit.getStrDelimiter(delimiter);
            char[] arr = inParenthesis.ToCharArray();
            List<int> openParIndices = new List<int>();

            // first char check
            if (getCloseParIndex(arr[0]) != -1) { throw new NotImplementedException(); }
            if (arr[0] == delimiterChar) { throw new NotImplementedException(); }
            if (arr[arr.Length - 1] == delimiterChar) { throw new NotImplementedException(); }
            if (getOpenParIndex(arr[0]) != -1) { openParIndices.Add(getOpenParIndex(arr[0])); }

            int startIndex = 0;

            for (int i = 1; i < arr.Length; i++)
            {
                char c = arr[i];
                
                int openParInd = getOpenParIndex(c);
                int closeParInd = getCloseParIndex(c);
                if (openParIndices.Count > 0)
                {
                    if (openParInd > -1)
                    {
                        openParIndices.Add(openParInd);
                    }
                    else if (closeParInd > -1)
                    {
                        if (closeParInd != openParIndices.Last())
                        {
                            throw new NotImplementedException();
                        }
                        else // if (closeParInd == openParIndices.Last())
                        {
                            openParIndices.RemoveAt(openParIndices.Count - 1);
                        }
                    }
                }
                else // if(openParIndices.Count == 0)
                {
                    if (closeParInd > -1)
                    {
                        throw new NotImplementedException();
                    }
                    if (openParInd > -1)
                    {
                        openParIndices.Add(openParInd);
                    }
                    else
                    {
                        if (c == delimiterChar)
                        {
                            args.Add(Str.mid(inParenthesis, startIndex, i - startIndex));
                            startIndex = i + 1;
                        }
                    }
                }
            }
            args.Add(Str.mid(inParenthesis, startIndex, inParenthesis.Length - startIndex));
            return Str.trim(args);
        }


        

        private static int getOpenParIndex(char c) { return lstOpenPars.IndexOf(c); }
        private static int getCloseParIndex(char c) { return lstClosePars.IndexOf(c); }


    }
}
