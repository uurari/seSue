﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    class Time
    {
        public static string getDateTimeString(DateTime dateTime) { return getDateTimeString(dateTime, true, true, true, true, true, true); }        
        public static string getDateTimeString(DateTime dateTime, bool year, bool month, bool day, bool hour, bool minute, bool second) { return dateTime.ToString(getFormatStr(year, month, day, hour, minute, second)); }
        private static string getFormatStr(bool year, bool month, bool day, bool hour, bool minute, bool second)
        {
            string strDate = String.Empty;
            string strTime = String.Empty;
            if (year && month && day) { strDate = "yyyy-MM-dd"; }
            if (!year && month && day) { strDate = "MM-dd"; }
            if (year && !month && day) { strDate = "yyyy-dd"; }
            if (year && month && !day) { strDate = "yyyy-MM"; }
            if (!year && !month && day) { strDate = "dd"; }
            if (!year && month && !day) { strDate = "MM"; }
            if (year && !month && !day) { strDate = "yyyy"; }

            if (hour && minute && second) { strDate = "HH':'mm':'ss"; }
            if (!hour && minute && second) { strDate = "mm':'ss"; }
            if (hour && !minute && second) { strDate = "HH':'ss"; }
            if (hour && minute && !second) { strDate = "HH':'mm"; }
            if (!hour && !minute && second) { strDate = "ss"; }
            if (!hour && minute && !second) { strDate = "mm"; }
            if (hour && !minute && !second) { strDate = "HH"; }

            if (!strDate.Equals(String.Empty) && strTime.Equals(String.Empty)) { return strDate; }
            if (strDate.Equals(String.Empty) && !strTime.Equals(String.Empty)) { return strTime; }
            if (!strDate.Equals(String.Empty) && !strTime.Equals(String.Empty)) { return strDate + " " + strTime; }
            return String.Empty;
        }
    }
}
