﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.StringOperations
{
    class TypeOp
    {
        public static bool isNumeric(string str) { double number; return Double.TryParse(str, out number); }
        public static bool isInteger(string str) { int number; return Int32.TryParse(str, out number); }
        public static double toDouble(string str) { return Convert.ToDouble(str); }
        public static string toString(double dbl) { return dbl.ToString(); }
        public static string toString(double dbl, string format) { return dbl.ToString(format); }

        public static List<string> toString(List<double> lstDbl, string format)
        {
            List<string> lst = new List<string>();
            for (int i = 0; i < lstDbl.Count; i++) { lst.Add(toString(lstDbl[i], format)); }
            return lst;
        }
        public static string[] toString(double[] arrDbl, string format)
        {
            string[] arr = new string[arrDbl.Length];
            for (int i = 0; i < arrDbl.Length; i++) { arr[i] = toString(arrDbl[i], format); }
            return arr;
        }



    }
}