﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOperationsUnitTest
{
    class Instances
    {
        public static string s1 = "ugur";
        public static List<string> d1TrimT = new List<string>() { s1, " " + s1 + " ", "   " + s1 + "  " };
        public static List<string> d1TrimF = new List<string>() { "u gur", " ugu r" };

        public static List<string> d1a = new List<string>() { "12", "34.01", "56" };
        public static List<string> d1b = new List<string>() { "a", "34", "56" };
        public static List<string> d1c = new List<string>() { "12", "34" };
        public static List<string> d1d = new List<string>() { "1,2,a", "4,5" };

        public static List<List<string>> d2a = new List<List<string>>() { d1a, d1c };
        public static List<List<string>> d2b = new List<List<string>>() { d1a, d1b };
        public static List<List<string>> d2c = new List<List<string>>() { d1c, d1c };

    }
}
