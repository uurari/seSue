﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using U.StringOperations;

namespace StringOperationsUnitTest
{
    [TestClass]
    public class D1Test
    {
        [TestMethod]
        public void TestIsNumeric()
        {
            bool c = Str.isNumeric(Instances.d1a) && !Str.isNumeric(Instances.d1b);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestIsInteger()
        {
            bool c = Str.isInteger(Instances.d1c) && !Str.isInteger(Instances.d1a);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestStrToDouble1()
        {
            List<double> dblVector = Str.toDouble(Instances.d1a);
            bool c = true;
            for (int i = 0; i < dblVector.Count; i++) { c = c && dblVector[i].Equals(Convert.ToDouble(Instances.d1a[i])); }
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestStrTrim()
        {
            bool c = true;
            List<string> trimmedT = Str.trim(Instances.d1TrimT);
            List<string> trimmedF = Str.trim(Instances.d1TrimF);
            foreach (string str in trimmedT) { c = c && str.Equals(Instances.s1); }
            foreach (string str in trimmedF) { c = c && !str.Equals(Instances.s1); }
            Assert.IsTrue(c);
        }
    }
}
