﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using U.StringOperations;

namespace StringOperationsUnitTest
{
    [TestClass]
    public class D2Test
    {
        [TestMethod]
        public void TestIsNumeric()
        {
            bool c = Str.isNumeric(Instances.d2a) && !Str.isNumeric(Instances.d2b);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestIsInteger()
        {
            bool c = Str.isInteger(Instances.d2c) && !Str.isInteger(Instances.d2a) && !Str.isInteger(Instances.d2b);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestIsProper()
        {
            bool c = !Str.isProper(Instances.d2a) && Str.isProper(Instances.d2b) && Str.isProper(Instances.d2c);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestStrToDouble()
        {
            List<List<double>> d2Dbl = Str.toDouble(Instances.d2a);
            bool c = d2Dbl[0][0].Equals(Convert.ToDouble(Instances.d1a[0])) && d2Dbl[0][1].Equals(Convert.ToDouble(Instances.d1a[1])) && d2Dbl[1][1].Equals(Convert.ToDouble(Instances.d1c[1]));
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestVectorToTable1()
        {
            List<List<string>> d2 = Str.split(Instances.d1d, Str.Delimiter.Comma);
            bool c = (d2.Count == 2) && (d2[0].Count == 3) && (d2[1].Count == 2) && (d2[0][2] == "a") && (d2[1][0] == "4");
            Assert.IsTrue(c);
        }

    }
}
