﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using U.StringOperations;

namespace StringOperationsUnitTest
{
    [TestClass]
    public class D0Test
    {
        [TestMethod]
        public void TestStartsWith()
        {
            bool c = Str.startsWith(Instances.s1, "u") && Str.startsWith(Instances.s1, "ug") && !Str.startsWith(Instances.s1, "zg") && !Str.startsWith(Instances.s1, "g");
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestReadAfter()
        {
            bool c = Str.readAfter(Instances.s1, "u").Equals("gur") && Str.readAfter(Instances.s1, "ug").Equals("ur") && Str.readAfter(Instances.s1, "g").Equals("ur") && Str.readAfter(Instances.s1, "z").Equals(Instances.s1);
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestContains()
        {
            bool c = Str.contains(Instances.s1, "u") && Str.contains(Instances.s1, "ug") && Str.contains(Instances.s1, "g") && !Str.contains(Instances.s1, "z");
            Assert.IsTrue(c);
        }
        [TestMethod]
        public void TestTrim()
        {
            bool c = true;
            foreach (string s in Instances.d1TrimT) { c = c && Str.trim(s).Equals(Instances.s1); }
            foreach (string s in Instances.d1TrimF) { c = c && !Str.trim(s).Equals(Instances.s1); }
            Assert.IsTrue(c);
        }
    }
}
