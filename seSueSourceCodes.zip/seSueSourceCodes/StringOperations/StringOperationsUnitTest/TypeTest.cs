﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using U.StringOperations;

namespace StringOperationsUnitTest
{
    [TestClass]
    public class TypeTest
    {
        [TestMethod]
        public void TestIsNumeric1()
        {
            string str = "12.3456";
            bool actual = Str.isNumeric(str);
            const bool expected = true;
            Assert.AreEqual(expected, actual, "12.3456 should be numeric.");
        }
        [TestMethod]
        public void TestIsNumeric2()
        {
            string str = "123456";
            bool actual = Str.isNumeric(str);
            const bool expected = true;
            Assert.AreEqual(expected, actual, "123456 should be numeric.");
        }
        [TestMethod]
        public void TestIsNumeric3()
        {
            string str = "123ad6";
            bool actual = Str.isNumeric(str);
            const bool expected = false;
            Assert.AreEqual(expected, actual, "123ad6 should not be numeric.");
        }
        [TestMethod]
        public void TestIsInteger1()
        {
            string str = "12.3456";
            bool actual = Str.isInteger(str);
            const bool expected = false;
            Assert.AreEqual(expected, actual, "12.3456 should not be integer.");
        }
        [TestMethod]
        public void TestIsInteger2()
        {
            string str = "123456";
            bool actual = Str.isInteger(str);
            const bool expected = true;
            Assert.AreEqual(expected, actual, "123456 should be integer.");
        }
        [TestMethod]
        public void TestIsInteger3()
        {
            string str = "123ad6";
            bool actual = Str.isInteger(str);
            const bool expected = false;
            Assert.AreEqual(expected, actual, "123ad6 should not be integer.");
        }
    }
}
