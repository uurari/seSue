﻿using DiscreteChoiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;

namespace U.SUE.StandardModels
{
    class MNW
    {
        public static void unscaled(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ct = UArray.sameValues<double>(1.0, od.getPathIndices().Length);
                Weibit weibit = new Weibit(StaSUE.xi, StaSUE.beta, ct);
                od.setChoiceModel(weibit);
            }
        }
    }
}
