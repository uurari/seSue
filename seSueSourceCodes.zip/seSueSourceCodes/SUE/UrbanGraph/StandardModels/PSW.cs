﻿using DiscreteChoiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.StandardModels
{
    class PSW
    {
        public static void unscaled(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ct = od.calcPathSize(graph);
                Weibit weibit = new Weibit(StaSUE.xi, StaSUE.beta, ct);
                od.setChoiceModel(weibit);
            }
        }

    }
}
