﻿using DiscreteChoiceModel;
using StatisticalDistribution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.StandardModels
{
    class MDMExpP
    {
        public static void unscaled(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ps = od.calcPathSize(graph);
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new ExponentialDist(Math.Log(ps[k]) / StaSUE.theta, 1.0 / StaSUE.theta);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }


        public static void scaledScalingFactor(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ps = od.calcPathSize(graph);
                double spFftt = od.calcSpFFTT(graph);
                double theta = StaSUE.theta * Math.PI / Math.Sqrt(6 * StaSUE.eta * spFftt);
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new ExponentialDist(Math.Log(ps[k]) / theta, 1.0 / theta);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }
        public static void scaledScalingFactorPath(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ps = od.calcPathSize(graph);
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    Path path = graph.getPath(od.getPathIndices()[k]);
                    double theta = StaSUE.theta * Math.PI / Math.Sqrt(6 * StaSUE.eta * path.calcFFTT(graph));
                    mds[k] = new ExponentialDist(Math.Log(ps[k]) / theta, 1.0 / theta);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }


        public static void scaledCoefOfVariation(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ps = od.calcPathSize(graph);
                double spFftt = od.calcSpFFTT(graph);
                double theta = Math.PI / Math.Sqrt(6) / StaSUE.nu / spFftt;
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new ExponentialDist(Math.Log(ps[k]) / theta, 1.0 / theta);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }
        public static void scaledCoefOfVariationPath(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ps = od.calcPathSize(graph);
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    Path path = graph.getPath(od.getPathIndices()[k]);
                    double theta = Math.PI / Math.Sqrt(6) / StaSUE.nu / path.calcFFTT(graph);
                    mds[k] = new ExponentialDist(Math.Log(ps[k]) / theta, 1.0 / theta);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }




    }
}
