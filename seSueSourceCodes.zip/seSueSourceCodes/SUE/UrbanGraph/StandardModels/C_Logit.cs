﻿using DiscreteChoiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;

namespace U.SUE.StandardModels
{
    class C_Logit
    {
        public static void unscaled(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double[] ct = od.calcCommonalityFactors(graph, StaSUE.beta0, StaSUE.gamma);
                for (int k = 0; k < ct.Length; k++) { ct[k] = Math.Exp(-StaSUE.theta * ct[k]); }
                Logit logit = new Logit(StaSUE.theta, ct);
                od.setChoiceModel(logit);
            }
        }


        public static void scaledScalingFactor(Graph graph)
        {
            double[] thetas = new double[graph.getNbOdPairs()];
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                double spFftt = graph.getOdPair(w).calcSpFFTT(graph);
                thetas[w] = StaSUE.theta * Math.PI / Math.Sqrt(6 * StaSUE.eta * spFftt);
            }
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                OdPair od = graph.getOdPair(w);
                double[] ct = od.calcCommonalityFactors(graph, StaSUE.beta0, StaSUE.gamma);
                for (int k = 0; k < ct.Length; k++) { ct[k] = Math.Exp(-thetas[w] * ct[k]); }
                Logit logit = new Logit(thetas[w], ct);
                od.setChoiceModel(logit);
            }
        }


        public static void scaledCoefOfVariation(Graph graph)
        {
            double[] thetas = new double[graph.getNbOdPairs()];
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                double spFftt = graph.getOdPair(w).calcSpFFTT(graph);
                thetas[w] = Math.PI / Math.Sqrt(6) / StaSUE.nu / spFftt;
            }
            for (int w = 0; w < graph.getNbOdPairs(); w++)
            {
                OdPair od = graph.getOdPair(w);
                double[] ct = od.calcCommonalityFactors(graph, StaSUE.beta0, StaSUE.gamma);
                for (int k = 0; k < ct.Length; k++) { ct[k] = Math.Exp(-thetas[w] * ct[k]); }
                Logit logit = new Logit(thetas[w], ct);
                od.setChoiceModel(logit);
            }
        }


    }
}
