﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.StandardModels
{
    public class StaSUE
    {
        public static double theta = 0.1;
        public static double eta = 1.0;//proportionality
        public static double nu = 0.3;//coef of var
        public static double beta0 = 1.0;//commonality factor
        public static double gamma = 1.0;//commonality factor
        public static double beta = 3.7;//weibull shape
        public static double xi = 0.0; //weibull location
        public static double varEpsilon = 0.0001;//mdm precision


        public static void setMnl(Graph graph) { MNL.unscaled(graph); }
        public static void setMnlSf(Graph graph) { MNL.scaledScalingFactor(graph); }
        public static void setMnlCv(Graph graph) { MNL.scaledCoefOfVariation(graph); }
        public static void setPsl(Graph graph) { PSL.unscaled(graph); }
        public static void setPslSf(Graph graph) { PSL.scaledScalingFactor(graph); }
        public static void setPslCv(Graph graph) { PSL.scaledCoefOfVariation(graph); }
        public static void setCl(Graph graph) { C_Logit.unscaled(graph); }
        public static void setClSf(Graph graph) { C_Logit.scaledScalingFactor(graph); }
        public static void setClCv(Graph graph) { C_Logit.scaledCoefOfVariation(graph); }


        public static void setMnw(Graph graph) { MNW.unscaled(graph); }
        public static void setPsw(Graph graph) { PSW.unscaled(graph); }



        public static void setMdmExp(Graph graph) { MDMExp.unscaled(graph); }
        public static void setMdmExpSf(Graph graph) { MDMExp.scaledScalingFactor(graph); }
        public static void setMdmExpCv(Graph graph) { MDMExp.scaledCoefOfVariation(graph); }
        public static void setMdmExpSf2(Graph graph) { MDMExp.scaledScalingFactorPath(graph); }
        public static void setMdmExpCv2(Graph graph) { MDMExp.scaledCoefOfVariationPath(graph); }
        public static void setMdmExpC(Graph graph) { MDMExpC.unscaled(graph); }
        public static void setMdmExpCSf(Graph graph) { MDMExpC.scaledScalingFactor(graph); }
        public static void setMdmExpCCv(Graph graph) { MDMExpC.scaledCoefOfVariation(graph); }
        public static void setMdmExpCSf2(Graph graph) { MDMExpC.scaledScalingFactorPath(graph); }
        public static void setMdmExpCCv2(Graph graph) { MDMExpC.scaledCoefOfVariationPath(graph); }
        public static void setMdmExpP(Graph graph) { MDMExpP.unscaled(graph); }
        public static void setMdmExpPSf(Graph graph) { MDMExpP.scaledScalingFactor(graph); }
        public static void setMdmExpPCv(Graph graph) { MDMExpP.scaledCoefOfVariation(graph); }
        public static void setMdmExpPSf2(Graph graph) { MDMExpP.scaledScalingFactorPath(graph); }
        public static void setMdmExpPCv2(Graph graph) { MDMExpP.scaledCoefOfVariationPath(graph); }


        public static void setMdmNor(Graph graph) { MDMNor.unscaled(graph); }
        public static void setMdmNorSf(Graph graph) { MDMNor.scaledScalingFactor(graph); }
        public static void setMdmNorCv(Graph graph) { MDMNor.scaledCoefOfVariation(graph); }
        public static void setMdmNorSf2(Graph graph) { MDMNor.scaledScalingFactorPath(graph); }
        public static void setMdmNorCv2(Graph graph) { MDMNor.scaledCoefOfVariationPath(graph); }
        public static void setMdmNorP(Graph graph) { MDMNorP.unscaled(graph); }
        public static void setMdmNorPSf(Graph graph) { MDMNorP.scaledScalingFactor(graph); }
        public static void setMdmNorPCv(Graph graph) { MDMNorP.scaledCoefOfVariation(graph); }
        public static void setMdmNorPSf2(Graph graph) { MDMNorP.scaledScalingFactorPath(graph); }
        public static void setMdmNorPCv2(Graph graph) { MDMNorP.scaledCoefOfVariationPath(graph); }

    }
}
