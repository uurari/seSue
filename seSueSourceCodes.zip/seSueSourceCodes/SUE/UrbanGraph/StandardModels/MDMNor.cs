﻿using DiscreteChoiceModel;
using StatisticalDistribution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.StandardModels
{
    class MDMNor
    {
        public static void unscaled(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                double sigma = Math.PI / Math.Sqrt(6) / StaSUE.theta;
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new NormalDist(0.0, sigma);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }


        public static void scaledScalingFactor(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double spFftt = od.calcSpFFTT(graph);
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                double sigma = Math.Sqrt(StaSUE.eta * spFftt) / StaSUE.theta;
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new NormalDist(0.0, sigma);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }
        public static void scaledScalingFactorPath(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    Path path = graph.getPath(od.getPathIndices()[k]);
                    double sigma = Math.Sqrt(StaSUE.eta * path.calcFFTT(graph)) / StaSUE.theta;
                    mds[k] = new NormalDist(0.0, sigma);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }


        public static void scaledCoefOfVariation(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                double spFftt = od.calcSpFFTT(graph);
                double sigma = StaSUE.nu * spFftt;
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    mds[k] = new NormalDist(0.0, sigma);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }
        public static void scaledCoefOfVariationPath(Graph graph)
        {
            foreach (OdPair od in graph.getOdPairs())
            {
                Distribution[] mds = new Distribution[od.getPathIndices().Length];
                for (int k = 0; k < od.getPathIndices().Length; k++)
                {
                    Path path = graph.getPath(od.getPathIndices()[k]);
                    double sigma = StaSUE.nu * path.calcFFTT(graph);
                    mds[k] = new NormalDist(0.0, sigma);
                }
                MDM mdm = new MDM(mds, MDM.UtilityFunctionType.Additive, StaSUE.varEpsilon);
                od.setChoiceModel(mdm);
            }
        }




    }
}
