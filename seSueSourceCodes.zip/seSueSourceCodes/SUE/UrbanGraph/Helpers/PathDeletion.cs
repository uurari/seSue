﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Helpers
{
    class PathDeletion
    {
        internal static void clearAll(Graph graph)
        {
            int N = graph.getNbNodes();
            int A = graph.getNbArcs();
            int P = graph.getNbPaths();

            // Path
            graph.setPaths(new Path[0]);

            // Node
            /*
            foreach (Node node in graph.getNodes())
            {
                node.setEmanatingPathIndices(new int[0]);
                node.setIncomingPathIndices(new int[0]);
                node.setPathIndices(new int[0]);
            }//*/

            // Arc
            foreach (U.Graph.Arc arc in graph.getArcs())
            {
                //arc.setPathIndices(new int[0]);
            }

            // OD
            foreach (OdPair od in graph.getOdPairs())
            {
                od.setPathIndices(new int[0]);
            }
        }
    }
}
