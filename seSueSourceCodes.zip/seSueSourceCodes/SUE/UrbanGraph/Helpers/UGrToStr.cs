﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Helpers
{
    class UGrToStr
    {
        internal static string graphToString(Graph graph)
        {
            return nodesStr(graph) + linksStr(graph) + pathsStr(graph) + odsStr(graph);
        }

        private static string nodesStr(Graph graph)
        {
            string str = "nodes";
            for (int i = 0; i < graph.getNbNodes(); i++) { str = str + Environment.NewLine + graph.getNode(i).ToString(); }
            return str + ":" + Environment.NewLine;
        }
        private static string linksStr(Graph graph)
        {
            string str = "arcs";
            for (int i = 0; i < graph.getNbArcs(); i++) { str = str + Environment.NewLine + graph.getLink(i).ToString(); }
            return str + ":" + Environment.NewLine;
        }
        private static string pathsStr(Graph graph)
        {
            string str = "paths";
            for (int i = 0; i < graph.getNbPaths(); i++) { str = str + Environment.NewLine + graph.getPath(i).ToString(); }
            return str + ":" + Environment.NewLine;
        }
        private static string odsStr(Graph graph)
        {
            string str = "odpairs";
            for (int i = 0; i < graph.getNbOdPairs(); i++) { str = str + Environment.NewLine + graph.getOdPair(i).ToString(); }
            return str;
        }


    }
}
