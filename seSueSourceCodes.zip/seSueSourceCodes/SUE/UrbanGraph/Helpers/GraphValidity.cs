﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;

namespace U.SUE.Helpers
{
    class GraphValidity
    {
        private static List<string> odPairLabels;
        private static List<string> nodeLabels;

        public static void check(Graph graph)
        {
            initializeLists(graph);
            if (odPairLabels.Count != UList.distinct(odPairLabels).Count) { throw new Graph.InvalidGraphException("at least one OD pair is inserted more than once"); }
            foreach (OdPair odPair in graph.getOdPairs())
            {
                int oriIndex = nodeLabels.IndexOf(odPair.getOriLabel());
                int desIndex = nodeLabels.IndexOf(odPair.getDesLabel());
                if (oriIndex == -1) { throw new Graph.InvalidGraphException("origin node of the OD pair '" + odPair.getLabel() + "' does not exist in the graph"); }
                if (desIndex == -1) { throw new Graph.InvalidGraphException("destination node of the OD pair '" + odPair.getLabel() + "' does not exist in the graph"); }
            }
            clearLists();
        }


        private static void initializeLists(Graph graph)
        {
            odPairLabels = new List<string>(); foreach (OdPair odPair in graph.getOdPairs()) { odPairLabels.Add(odPair.getLabel()); }
            nodeLabels = new List<string>(); foreach (Node node in graph.getNodes()) { nodeLabels.Add(node.getLabel()); }
        }
        private static void clearLists()
        {
            nodeLabels.Clear(); nodeLabels = null;
            odPairLabels.Clear(); odPairLabels = null;
        }
    }
}
