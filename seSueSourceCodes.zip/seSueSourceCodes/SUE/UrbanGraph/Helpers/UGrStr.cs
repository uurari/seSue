﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;
using U.StringOperations;

namespace U.SUE.Helpers
{
    class UGrStr
    {
        // (
        // [0;1;2;3;4],
        // [0-1(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);0-2(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);1-3(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);2-3(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);2-4(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0)],
        // [0-1;0-1-3;0-2-3;0-2-4],
        // [0-1(10);0-3(20.0);2-3(20.5)]
        // )
        // ([0;1;2;3;4],[0-1(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);0-2(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);1-3(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);2-3(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0);2-4(2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0)],[0-1;0-1-3;0-2-3;0-2-4],[0-1(10);0-3(20.0);2-3(20.5)])
        internal const Str.ParenthesisTypes PAR = Str.ParenthesisTypes.Regular;
        internal const Str.Delimiter DEL = Str.Delimiter.Comma;


        internal static string toString(Graph graph)
        {
            string strN = StrArray.getArrayString(Str.toString(UList.toList(graph.getNodes())));
            string strA = StrArray.getArrayString(Str.toString(UList.toList(graph.getArcs())));
            string strP = StrArray.getArrayString(Str.toString(UList.toList(graph.getPaths())));
            string strO = StrArray.getArrayString(Str.toString(UList.toList(graph.getOdPairs())));
            return StrFunc.getFuncString(String.Empty, new List<string>() { strN, strA, strP, strO });
        }

        internal static StrFunc getStrFunc(string str)
        {
            StrFunc sf = new StrFunc(str, PAR, DEL);
            if (sf.getNbArgs() != 4) { throw new Graph.InvalidGraphException("graph string should contain 4 argments (nodes, arcs, paths, odpairs): " + sf.getFuncString()); }
            return sf;
        }
        internal static Node[] getNodes(string strNodes)
        {
            List<string> lst = Str.split(strNodes, Str.Delimiter.NewLine);
            Node[] arr = new Node[lst.Count - 1];
            for (int i = 1; i < lst.Count; i++) { arr[i - 1] = new Node(lst[i]); }
            return arr;
        }
        internal static Link[] getLinks(string strLinks)
        {
            List<string> lst = Str.split(strLinks, Str.Delimiter.NewLine);
            Link[] arr = new Link[lst.Count - 1];
            for (int i = 1; i < lst.Count; i++) { arr[i - 1] = new Link(lst[i]); }
            return arr;
        }
        internal static Path[] getPaths(string strPaths)
        {
            List<string> lst = Str.split(strPaths, Str.Delimiter.NewLine);
            Path[] arr = new Path[lst.Count - 1];
            for (int i = 1; i < lst.Count; i++) { arr[i - 1] = new Path(lst[i]); }
            return arr;
        }
        internal static OdPair[] getOdPairs(string strOdpairs)
        {
            List<string> lst = Str.split(strOdpairs, Str.Delimiter.NewLine);
            OdPair[] arr = new OdPair[lst.Count - 1];
            for (int i = 1; i < lst.Count; i++) { arr[i - 1] = new OdPair(lst[i]); }
            return arr;
        }




        internal static Node[] getNodes(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(0));
            List<string> lst = sa.getItems();
            Node[] arr = new Node[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Node(lst[i]); }
            return arr;
        }
        internal static Link[] getLinks(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(1));
            List<string> lst = sa.getItems();
            Link[] arr = new Link[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Link(lst[i]); }
            return arr;
        }
        internal static Path[] getPaths(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(2));
            List<string> lst = sa.getItems();
            Path[] arr = new Path[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new Path(lst[i]); }
            return arr;
        }
        internal static OdPair[] getOdPairs(StrFunc sf)
        {
            StrArray sa = new StrArray(sf.getArg(3));
            List<string> lst = sa.getItems();
            OdPair[] arr = new OdPair[lst.Count];
            for (int i = 0; i < lst.Count; i++) { arr[i] = new OdPair(lst[i]); }
            return arr;
        }

    }
}
