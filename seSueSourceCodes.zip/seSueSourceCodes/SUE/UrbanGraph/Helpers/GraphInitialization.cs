﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.ListOperations;
using U.StringOperations;

namespace U.SUE.Helpers
{
    class GraphInitialization
    {
        private static int O;
        private static int P;
        private static List<List<int>> odPathIndices;
        private static List<string> odPairLabels;
        private static List<string> nodeLabels;

        public static void initialize(Graph graph)
        {
            initializeLists(graph);
            for (int p = 0; p < graph.getPaths().Length; p++)
            {
                Path path = graph.getPath(p);
                //string odLabel = Str.combine(path.getOriLabel(), path.getDesLabel(), Str.Delimiter.Dash);
                //int odIndex = odPairLabels.IndexOf(odLabel);
                //path.setOdPairIndex(odIndex);
                //if (odIndex != -1) { odPathIndices[odIndex].Add(p); }
            }
            for (int o = 0; o < graph.getOdPairs().Length; o++)
            {
                OdPair odPair = graph.getOdPair(o);
                odPair.setOriIndex(nodeLabels.IndexOf(odPair.getOriLabel()));
                odPair.setDesIndex(nodeLabels.IndexOf(odPair.getDesLabel()));
                odPair.setPathIndices(UArray.toArray(odPathIndices[o]));
            }
            clearLists();
        }



        private static void initializeLists(Graph graph)
        {
            O = graph.getOdPairs().Length;
            P = graph.getPaths().Length;

            odPathIndices = new List<List<int>>(); for (int i = 0; i < O; i++) { odPathIndices.Add(new List<int>()); }
            odPairLabels = new List<string>(); foreach (OdPair odPair in graph.getOdPairs()) { odPairLabels.Add(odPair.getLabel()); }
            nodeLabels = new List<string>(); foreach (Node node in graph.getNodes()) { nodeLabels.Add(node.getLabel()); }
        }
        private static void clearLists()
        {
            odPathIndices.Clear(); odPathIndices = null;
            odPairLabels.Clear(); odPairLabels = null;
            nodeLabels.Clear(); nodeLabels = null;
        }
    }
}
