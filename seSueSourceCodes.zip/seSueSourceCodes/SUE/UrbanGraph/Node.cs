﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE
{
    public class Node : U.Graph.Node
    {
        // CONSTRUCTORS
        public Node(string label) : base(label)
        {
        }
        public Node(List<string> args) : base(args)
        {

        }

    }
}
