﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;

namespace U.SUE
{
    public class Path : U.Graph.Path
    {
        private int odPairIndex;
        private double prob;


        #region CONSTRUCTORS
        //public Path(string[] nodeLabels) : base(nodeLabels) { }
        public Path(List<string> args)
            : base(args)
        {
            this.odPairIndex = Str.toInt(args[3]);
            this.prob = Str.toDouble(args[4]);
        }
        public Path(Graph graph, int[] nodeIndices, double flow, double cost, int odPairIndex, double prob)
            : base(graph, nodeIndices, flow, cost)
        {
            this.odPairIndex = odPairIndex;
            this.prob = prob;
        } 
        #endregion



        // todelete
        public Path(string strPath) : base(strPath)
        {
            StrFunc sf = new StrFunc(strPath);
            if (sf.getArgs().Count < 3) { throw new InvalidPathException(strPath); }
            this.prob = sf.getArgDouble(2);
        }



        // SETTERS
        public void setProb(double prob) { this.prob = prob; }

        // INTERNAL
        internal void setOdPairIndex(int odPairIndex) { this.odPairIndex = odPairIndex; }


        // GETTERS
        public int getOdPairIndex() { return this.odPairIndex; }
        public double getProb() { return this.prob; }


        // COMMON
        public override string ToString()
        {
            List<double> args = new List<double>() { base.getFlow(), base.getCost(), this.prob };
            return StrFunc.getFuncString(getLabel(), args);
        }
        public bool Equals(Path path) { return base.getLabel() == path.getLabel(); }


        // CALCULATORS
        public double calcFFTT(Graph graph)
        {
            double c = 0.0;
            foreach (int a in this.getArcIndices())
            {
                Link link = graph.getLink(a);
                c += link.getLinkCost().getBPRCost(0.0);
            }
            return c;
        }

    }
}
