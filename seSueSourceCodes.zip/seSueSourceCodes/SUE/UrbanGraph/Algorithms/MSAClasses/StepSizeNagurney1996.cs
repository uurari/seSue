﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Algorithms
{
    public class StepSizeNagurney1996 : StepSize
    {
        private int currDenominator;
        private int currDenominatorIndex;

        public StepSizeNagurney1996()
        {
            currDenominator = 0;
            currDenominatorIndex = 0;
        }



        // OVERRIDE
        public override double getAlpha(int k)
        {
            if (currDenominator == currDenominatorIndex)
            {
                currDenominator += 1;
                currDenominatorIndex = 1;
            }
            else
            {
                currDenominatorIndex += 1;
            }
            return 1.0 / currDenominator;
        }
        public override void reset() { currDenominator = 0; currDenominatorIndex = 0; }
        public override string ToString() { return "Nagurney1996"; }

    }
}
