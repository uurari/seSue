﻿using DiscreteChoiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Algorithms
{
    public class PathCost
    {
        public enum Type { ADD, MUL, NONE };


        public static Type getType(ChoiceModel choiceModel)
        {
            if (choiceModel == null) { return Type.NONE; }
            switch (choiceModel.getType())
            {
                case ChoiceModel.Type.Deterministic: return Type.ADD;
                case ChoiceModel.Type.Logit: return Type.ADD;
                case ChoiceModel.Type.Weibit: return Type.MUL;
                case ChoiceModel.Type.MDM:
                    MDM mdm = (MDM)choiceModel;
                    if (mdm.getUtiityFunctionType() == MDM.UtilityFunctionType.Additive) { return Type.ADD; }
                    if (mdm.getUtiityFunctionType() == MDM.UtilityFunctionType.Multiplicative) { return Type.MUL; }
                    throw new NotImplementedException();
            }
            throw new NotImplementedException();
        }
    }

}
