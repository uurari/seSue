﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using U.StringOperations;

namespace U.SUE.Algorithms
{
    public abstract class StepSize
    {

        public static StepSize fromString(string strStepSize)
        {
            StrFunc sf = new StrFunc(strStepSize);
            string type = sf.getFuncName().ToLower();
            if (type == "standard")
            {
                if (sf.getNbArgs() != 2) { throw new NotImplementedException(); }
                if (!Str.isNumeric(sf.getArgs())) { throw new NotImplementedException(); }
                double k1 = sf.getArgDouble(0);
                double k2 = sf.getArgDouble(1);
                return new StepSizeStandard(k1, k2);
            }
            else if (type == "liu2009")
            {
                if (sf.getNbArgs() != 1) { throw new NotImplementedException(); }
                if (!Str.isNumeric(sf.getArgs())) { throw new NotImplementedException(); }
                double d = sf.getArgDouble(0);
                return new StepSizeLiu2009(d);
            }
            else if (type == "nagurney1996")
            {
                if (sf.getNbArgs() != 0) { throw new NotImplementedException(); }
                return new StepSizeNagurney1996();
            }
            else if (type == "polyak1990")
            {
                if (sf.getNbArgs() != 0) { throw new NotImplementedException(); }
                return new StepSizePolyak1990();
            }
            throw new NotImplementedException();
        }


        public abstract double getAlpha(int k);

        public abstract void reset();

        

    }


}
