﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Algorithms
{
    public class StepSizePolyak1990 : StepSize
    {



        // OVERRIDE
        public override double getAlpha(int k)
        {
            return Math.Pow(k, -2.0 / 3.0);
        }
        public override void reset() { }
        public override string ToString() { return "Polyak1990"; }
    }
}
