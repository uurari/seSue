﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Algorithms
{
    public class StepSizeLiu2009 : StepSize
    {
        private double denominator;
        private double d;

        public StepSizeLiu2009(double d)
        {
            this.denominator = 0.0;
            this.d = d;
        }


        // OVERRIDE
        public override double getAlpha(int k)
        {
            denominator += Math.Pow(k, d);
            return 1.0 / denominator;
        }
        public override void reset() { denominator = 0.0; }
        public override string ToString() { return "Liu2009(" + d + ")"; }


        public double getD() { return this.d; }
        
    }
}
