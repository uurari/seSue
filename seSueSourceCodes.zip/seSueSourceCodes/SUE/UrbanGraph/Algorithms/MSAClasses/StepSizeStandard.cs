﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace U.SUE.Algorithms
{
    public class StepSizeStandard : StepSize
    {
        private double k1;
        private double k2;

        public StepSizeStandard(double k1, double k2)
        {
            this.k1 = k1;
            this.k2 = k2;
        }




        // OVERRIDE
        public override double getAlpha(int k)
        {
            return k1 / (k2 + k);
        }
        public override void reset() { }
        public override string ToString() { return "Standard(" + k1 + "," + k2 + ")"; }


        public double getK1() { return this.k1; }
        public double getK2() { return this.k2; }

    }


}
